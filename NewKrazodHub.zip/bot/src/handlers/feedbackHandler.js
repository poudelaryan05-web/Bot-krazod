'use strict';
/**
 * feedbackHandler.js
 *
 * Handles all button, channel-select, and modal interactions for the feedback system.
 * Routes:
 *   setup:feedback:channel       — Button → show ChannelSelectMenu (BOT OWNER ONLY)
 *   setup:feedback:select_channel — ChannelSelectMenu → save channelId (BOT OWNER ONLY)
 *   setup:feedback:save          — enable & save config (BOT OWNER ONLY)
 *   feedback:submit              — modal submission → forward to global feedback channel
 *
 * The feedback channel is a global (bot-owner) setting stored under guild_id = 'GLOBAL'.
 * Only the bot owner (BOT_OWNER_ID) can configure or change the feedback channel.
 */

const {
  ActionRowBuilder, ChannelSelectMenuBuilder, ChannelType,
  ButtonBuilder, ButtonStyle, EmbedBuilder,
} = require('discord.js');
const { getConfig, setConfig } = require('../database/db');
const { successEmbed, errorEmbed, infoEmbed, COLORS } = require('../utils/embeds');
const logger = require('../utils/logger');

// ─── Bot owner ────────────────────────────────────────────────────────────────
const BOT_OWNER_ID = '1477244673595805726';

// Global config key — feedback channel is set once by the bot owner
const GLOBAL_KEY = 'GLOBAL';

async function handleFeedback(interaction) {
  const { customId } = interaction;

  // ── "Set Channel" button → show channel select menu ──────────────────────
  if (interaction.isButton() && customId === 'setup:feedback:channel') {
    if (interaction.user.id !== BOT_OWNER_ID) {
      return interaction.reply({
        embeds: [errorEmbed('Only the **bot owner** can configure the feedback channel.')],
        flags: 1 << 6,
      });
    }

    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('setup:feedback:select_channel')
        .setPlaceholder('Select the feedback channel...')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    );

    return interaction.reply({
      embeds: [infoEmbed('Select the channel where submitted feedback should be sent.')],
      components: [row],
      flags: 1 << 6,
    });
  }

  // ── Channel selected → save and confirm ──────────────────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'setup:feedback:select_channel') {
    if (interaction.user.id !== BOT_OWNER_ID) {
      return interaction.reply({
        embeds: [errorEmbed('Only the **bot owner** can configure the feedback channel.')],
        flags: 1 << 6,
      });
    }

    const channel = interaction.channels.first();
    if (!channel) {
      return interaction.reply({ embeds: [errorEmbed('No channel selected.')], flags: 1 << 6 });
    }

    const current = getConfig(GLOBAL_KEY, 'feedback') ?? {};
    setConfig(GLOBAL_KEY, 'feedback', { ...current, channelId: channel.id, enabled: true });

    return interaction.reply({
      embeds: [successEmbed(`Global feedback channel set to <#${channel.id}>! The feedback system is now **enabled**.`)],
      flags: 1 << 6,
    });
  }

  // ── "Save" button → enable the system (channelId must be set first) ──────
  if (interaction.isButton() && customId === 'setup:feedback:save') {
    if (interaction.user.id !== BOT_OWNER_ID) {
      return interaction.reply({
        embeds: [errorEmbed('Only the **bot owner** can configure the feedback channel.')],
        flags: 1 << 6,
      });
    }

    const current = getConfig(GLOBAL_KEY, 'feedback') ?? {};
    if (!current.channelId) {
      return interaction.reply({
        embeds: [errorEmbed('Please set a feedback channel first using the **Set Channel** button.')],
        flags: 1 << 6,
      });
    }

    setConfig(GLOBAL_KEY, 'feedback', { ...current, enabled: true });
    return interaction.reply({
      embeds: [successEmbed(`Feedback system saved and enabled! Submissions will be sent to <#${current.channelId}>.`)],
      flags: 1 << 6,
    });
  }

  // ── Modal submission: feedback:submit ─────────────────────────────────────
  // Looks up the globally configured feedback channel (set by the bot owner).
  if (interaction.isModalSubmit() && customId === 'feedback:submit') {
    const config = getConfig(GLOBAL_KEY, 'feedback');
    if (!config?.enabled || !config?.channelId) {
      return interaction.reply({
        embeds: [errorEmbed('The feedback system has not been configured yet. Please ask the bot owner to set up a feedback channel using `/feedback setup`.')],
        flags: 1 << 6,
      });
    }

    const ratingRaw = interaction.fields.getTextInputValue('rating').trim();
    const message   = interaction.fields.getTextInputValue('message').trim();

    const rating = parseInt(ratingRaw, 10);
    if (isNaN(rating) || rating < 1 || rating > 5) {
      return interaction.reply({
        embeds: [errorEmbed('Rating must be a number from **1** to **5**.')],
        flags: 1 << 6,
      });
    }

    const stars = '⭐'.repeat(rating) + '☆'.repeat(5 - rating);

    const channel = interaction.guild?.channels.cache.get(config.channelId)
      ?? interaction.client.channels.cache.get(config.channelId);

    if (!channel || !channel.isTextBased()) {
      return interaction.reply({
        embeds: [errorEmbed('The configured feedback channel no longer exists or is inaccessible. Please ask the bot owner to re-run `/feedback setup`.')],
        flags: 1 << 6,
      });
    }

    const feedbackEmbed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('New Server Feedback')
      .setAuthor({
        name: interaction.user.tag,
        iconURL: interaction.user.displayAvatarURL(),
      })
      .addFields(
        { name: 'Rating',   value: `${stars} (${rating}/5)`,                                                                                      inline: true },
        { name: 'User',     value: `<@${interaction.user.id}>`,                                                                                    inline: true },
        { name: 'Server',   value: interaction.guild ? `${interaction.guild.name} (\`${interaction.guild.id}\`)` : 'Direct Message',              inline: true },
        { name: 'Feedback', value: message },
      )
      .setFooter({ text: `User ID: ${interaction.user.id}` })
      .setTimestamp();

    try {
      await channel.send({ embeds: [feedbackEmbed] });
    } catch (err) {
      logger.error('feedbackHandler: failed to send to feedback channel:', err.message);
      return interaction.reply({
        embeds: [errorEmbed('Could not send feedback to the configured channel. Please check my permissions.')],
        flags: 1 << 6,
      });
    }

    return interaction.reply({
      embeds: [successEmbed('Your feedback has been submitted. Thank you!')],
      flags: 1 << 6,
    });
  }
}

module.exports = { handleFeedback };
