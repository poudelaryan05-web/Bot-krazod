'use strict';
/**
 * ticketsHandler.js
 *
 * Handles button/channel-select/modal interactions for the ticket system:
 *   setup:tickets:*   — admin setup buttons & selects
 *   ticket:open       — user opens a ticket
 *   ticket:claim      — staff claims a ticket
 *   ticket:close      — closes and archives a ticket
 */

const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder,
  PermissionFlagsBits, ChannelType,
  ChannelSelectMenuBuilder, RoleSelectMenuBuilder,
} = require('discord.js');
const { getConfig, setConfig, getDB } = require('../database/db');
const { successEmbed, errorEmbed, COLORS } = require('../utils/embeds');

// ─── Main handler ─────────────────────────────────────────────────────────────
async function handleTickets(interaction) {
  const { customId } = interaction;
  const guildId      = interaction.guild.id;

  // ── User opens a ticket ───────────────────────────────────────────────────
  if (customId === 'ticket:open') {
    const config = getConfig(guildId, 'tickets');
    if (!config?.categoryId) {
      return interaction.reply({ embeds: [errorEmbed('The ticket system is not fully configured.')], flags: 1 << 6 });
    }

    const db = getDB();
    const existing = db.prepare(
      "SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND status = 'open'"
    ).get(guildId, interaction.user.id);

    if (existing) {
      return interaction.reply({
        embeds: [errorEmbed(`You already have an open ticket: <#${existing.channel_id}>`)],
        flags: 1 << 6,
      });
    }

    await interaction.deferReply({ flags: 1 << 6 });

    try {
      const category = interaction.guild.channels.cache.get(config.categoryId);
      const overwrites = [
        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: interaction.guild.members.me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] },
      ];

      if (config.supportRoleId) {
        overwrites.push({
          id: config.supportRoleId,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
        });
      }

      const channel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username.replace(/[^a-zA-Z0-9]/g, '').toLowerCase().slice(0, 20)}`,
        type: ChannelType.GuildText,
        parent: category ?? undefined,
        permissionOverwrites: overwrites,
        topic: `Ticket opened by ${interaction.user.tag} (${interaction.user.id})`,
      });

      db.prepare(
        'INSERT INTO tickets (guild_id, user_id, channel_id, status, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run(guildId, interaction.user.id, channel.id, 'open', Date.now());

      const ticketEmbed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle('🎫 Ticket Opened')
        .setDescription(
          `Hello ${interaction.user}! Support will be with you shortly.\n\n` +
          `Please describe your issue in detail.`
        )
        .setFooter({ text: 'Krazod Hub Tickets' })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket:claim').setLabel('Claim').setStyle(ButtonStyle.Primary).setEmoji('🙋'),
        new ButtonBuilder().setCustomId('ticket:close').setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
      );

      await channel.send({ content: `${interaction.user}`, embeds: [ticketEmbed], components: [row] });
      return interaction.editReply({ embeds: [successEmbed(`Your ticket has been created: <#${channel.id}>!`)] });
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed(`Failed to create ticket: ${err.message}`)] });
    }
  }

  // ── Staff claims a ticket ─────────────────────────────────────────────────
  if (customId === 'ticket:claim') {
    const config = getConfig(guildId, 'tickets');
    const hasSupportRole = config?.supportRoleId
      ? interaction.member.roles.cache.has(config.supportRoleId)
      : interaction.member.permissions.has(PermissionFlagsBits.ManageChannels);

    if (!hasSupportRole) {
      return interaction.reply({ embeds: [errorEmbed('You do not have permission to claim tickets.')], flags: 1 << 6 });
    }

    await interaction.reply({
      embeds: [successEmbed(`Ticket claimed by ${interaction.user}.`)],
    });
  }

  // ── Close ticket ──────────────────────────────────────────────────────────
  if (customId === 'ticket:close') {
    const db = getDB();
    const ticket = db.prepare(
      "SELECT * FROM tickets WHERE guild_id = ? AND channel_id = ? AND status = 'open'"
    ).get(guildId, interaction.channel.id);

    if (!ticket) {
      return interaction.reply({ embeds: [errorEmbed('This is not an open ticket channel.')], flags: 1 << 6 });
    }

    const config = getConfig(guildId, 'tickets');
    const canClose = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)
      || (config?.supportRoleId && interaction.member.roles.cache.has(config.supportRoleId))
      || ticket.user_id === interaction.user.id;

    if (!canClose) {
      return interaction.reply({ embeds: [errorEmbed('You do not have permission to close this ticket.')], flags: 1 << 6 });
    }

    await interaction.reply({ embeds: [successEmbed('Closing ticket in 5 seconds...')] });
    db.prepare("UPDATE tickets SET status = 'closed' WHERE id = ?").run(ticket.id);

    setTimeout(async () => {
      await interaction.channel.delete().catch(() => {});
    }, 5000);
  }

  // ── Admin permission check for setup interactions ─────────────────────────
  const isSetup = customId.startsWith('setup:tickets:');
  if (isSetup && !interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
    return interaction.reply({ embeds: [errorEmbed('You need the **Manage Server** permission.')], flags: 1 << 6 });
  }

  // ── Setup: Panel Channel button → show ChannelSelectMenu ─────────────────
  if (interaction.isButton() && customId === 'setup:tickets:panel_channel') {
    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('setup:tickets:select_panel_channel')
        .setPlaceholder('Select the channel to post the ticket panel in...')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    );
    return interaction.reply({ embeds: [{ description: '📌 Select a text channel for the ticket panel.' }], components: [row], flags: 1 << 6 });
  }

  // ── Setup: Category button → show ChannelSelectMenu (categories) ─────────
  if (interaction.isButton() && customId === 'setup:tickets:category') {
    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('setup:tickets:select_category')
        .setPlaceholder('Select the category for new ticket channels...')
        .addChannelTypes(ChannelType.GuildCategory),
    );
    return interaction.reply({ embeds: [{ description: '📂 Select a category where ticket channels will be created.' }], components: [row], flags: 1 << 6 });
  }

  // ── Setup: Support Role button → show RoleSelectMenu ─────────────────────
  if (interaction.isButton() && customId === 'setup:tickets:support_role') {
    const row = new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder()
        .setCustomId('setup:tickets:select_support_role')
        .setPlaceholder('Select the support staff role...'),
    );
    return interaction.reply({ embeds: [{ description: '🛡️ Select the role that can view and manage tickets.' }], components: [row], flags: 1 << 6 });
  }

  // ── ChannelSelectMenu: panel_channel ─────────────────────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'setup:tickets:select_panel_channel') {
    const channel = interaction.channels.first();
    if (!channel) return interaction.reply({ embeds: [errorEmbed('No channel selected.')], flags: 1 << 6 });
    const current = getConfig(guildId, 'tickets') ?? {};
    setConfig(guildId, 'tickets', { ...current, panelChannelId: channel.id });
    return interaction.reply({ embeds: [successEmbed(`Panel channel set to <#${channel.id}>!`)], flags: 1 << 6 });
  }

  // ── ChannelSelectMenu: category ───────────────────────────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'setup:tickets:select_category') {
    const channel = interaction.channels.first();
    if (!channel) return interaction.reply({ embeds: [errorEmbed('No category selected.')], flags: 1 << 6 });
    const current = getConfig(guildId, 'tickets') ?? {};
    setConfig(guildId, 'tickets', { ...current, categoryId: channel.id });
    return interaction.reply({ embeds: [successEmbed(`Ticket category set to **${channel.name}**!`)], flags: 1 << 6 });
  }

  // ── RoleSelectMenu: support_role ─────────────────────────────────────────
  if (interaction.isRoleSelectMenu() && customId === 'setup:tickets:select_support_role') {
    const role = interaction.roles.first();
    if (!role) return interaction.reply({ embeds: [errorEmbed('No role selected.')], flags: 1 << 6 });
    const current = getConfig(guildId, 'tickets') ?? {};
    setConfig(guildId, 'tickets', { ...current, supportRoleId: role.id });
    return interaction.reply({ embeds: [successEmbed(`Support role set to **${role.name}**!`)], flags: 1 << 6 });
  }

  // ── Send Panel button ─────────────────────────────────────────────────────
  if (interaction.isButton() && customId === 'setup:tickets:send_panel') {
    const current = getConfig(guildId, 'tickets') ?? {};
    if (!current.panelChannelId) {
      return interaction.reply({ embeds: [errorEmbed('Please set a panel channel first.')], flags: 1 << 6 });
    }
    const ch = interaction.guild.channels.cache.get(current.panelChannelId);
    if (!ch || !ch.isTextBased()) {
      return interaction.reply({ embeds: [errorEmbed('Panel channel not found or is not a text channel.')], flags: 1 << 6 });
    }

    const panelEmbed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('🎫 Support Tickets')
      .setDescription(
        `Need help? Click the button below to open a private support ticket.\n\n` +
        `A staff member will assist you as soon as possible.`,
      )
      .setFooter({ text: 'Krazod Hub Tickets' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket:open').setLabel('Open Ticket').setStyle(ButtonStyle.Primary).setEmoji('🎫'),
    );

    await ch.send({ embeds: [panelEmbed], components: [row] });
    return interaction.reply({ embeds: [successEmbed(`Ticket panel sent to <#${ch.id}>!`)], flags: 1 << 6 });
  }
}

module.exports = { handleTickets };
