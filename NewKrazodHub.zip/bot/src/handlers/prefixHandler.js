'use strict';
/**
 * prefixHandler.js — Prefix command support
 *
 * Default prefix: ,
 * Mirrors the key slash commands as prefix variants.
 * Does NOT remove or modify any slash commands.
 *
 * Supported prefix commands:
 *   ,help  ,ping  ,about  ,botinfo  ,serverinfo  ,userinfo  ,avatar  ,banner
 *   ,poll  ,remind  ,afk  ,ban  ,unban  ,kick  ,timeout  ,untimeout
 *   ,warn  ,warnings  ,clear  ,ticket  ,feedback  ,lock  ,spam
 *
 * Implementation note:
 *   Rather than duplicating full command logic here, we proxy the arguments
 *   onto the existing slash command modules where they accept a plain message
 *   context. For commands that require interactions (modals, select menus),
 *   we show a clean "use /command" redirect for the interactive portion only.
 */

const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { COLORS } = require('../utils/embeds');
const logger = require('../utils/logger');

const PREFIX = ',';

// ── Helpers ───────────────────────────────────────────────────────────────────
function reply(message, embed) {
  return message.reply({ embeds: [embed] }).catch(() => {});
}

function infoEmbed(desc, title) {
  const e = new EmbedBuilder().setColor(COLORS.primary).setDescription(desc).setTimestamp();
  if (title) e.setTitle(title);
  return e;
}

function successEmbed(desc) {
  return new EmbedBuilder().setColor(COLORS.success).setDescription(desc).setTimestamp();
}

function errorEmbed(desc) {
  return new EmbedBuilder().setColor(COLORS.error).setDescription(desc).setTimestamp();
}

function warningEmbed(desc) {
  return new EmbedBuilder().setColor(COLORS.warning).setDescription(desc).setTimestamp();
}

function requirePerm(message, flag, label) {
  if (!message.member?.permissions?.has(flag)) {
    reply(message, errorEmbed(`You need the **${label}** permission to use this command.`));
    return false;
  }
  return true;
}

function requireBotPerm(message, flag, label) {
  if (!message.guild?.members?.me?.permissions?.has(flag)) {
    reply(message, errorEmbed(`I need the **${label}** permission to execute this command.`));
    return false;
  }
  return true;
}

// ── Main handler ──────────────────────────────────────────────────────────────
async function handlePrefix(message, client) {
  if (!message.content.startsWith(PREFIX)) return;
  if (message.author.bot) return;

  const args    = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const command = args.shift()?.toLowerCase();

  if (!command) return;

  try {
    switch (command) {

      // ── help ────────────────────────────────────────────────────────────────
      case 'help': {
        const { CATEGORIES } = require('../commands/utility/help');
        const totalCommands  = Object.values(CATEGORIES).reduce(
          (acc, c) => acc + c.commands.filter(l => l.startsWith('`/')).length, 0,
        );

        const embed = new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle('Krazod Hub — Help')
          .setDescription(
            `Use \`/help\` for the full interactive help menu, or browse categories below.\n\n` +
            `**Categories:** ${Object.keys(CATEGORIES).length}   **Total Commands:** ${totalCommands}\n\n` +
            Object.values(CATEGORIES).map(c => `**${c.label}** — ${c.description}`).join('\n'),
          )
          .setFooter({ text: `Prefix: ${PREFIX}  •  Krazod Hub` })
          .setTimestamp();

        return reply(message, embed);
      }

      // ── ping ────────────────────────────────────────────────────────────────
      case 'ping': {
        const ws   = client.ws.ping;
        const sent = await message.reply({ embeds: [infoEmbed('Measuring latency…', 'Ping')] });
        const trip = sent.createdTimestamp - message.createdTimestamp;
        return sent.edit({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('Ping')
            .addFields(
              { name: 'Roundtrip',  value: `${trip} ms`,  inline: true },
              { name: 'WebSocket',  value: `${ws} ms`,    inline: true },
            )
            .setTimestamp()],
        }).catch(() => {});
      }

      // ── about / botinfo ─────────────────────────────────────────────────────
      case 'about':
      case 'botinfo': {
        const totalGuilds = client.guilds.cache.size;
        const totalUsers  = client.guilds.cache.reduce((a, g) => a + (g.memberCount ?? 0), 0);
        const uptime      = process.uptime();
        const hours       = Math.floor(uptime / 3600);
        const minutes     = Math.floor((uptime % 3600) / 60);
        const seconds     = Math.floor(uptime % 60);

        const embed = new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle('Krazod Hub — Bot Info')
          .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
          .addFields(
            { name: 'Bot Name',   value: client.user.tag,                              inline: true },
            { name: 'Servers',    value: `${totalGuilds}`,                             inline: true },
            { name: 'Users',      value: `${totalUsers}`,                              inline: true },
            { name: 'Uptime',     value: `${hours}h ${minutes}m ${seconds}s`,          inline: true },
            { name: 'Library',    value: 'discord.js v14',                             inline: true },
            { name: 'Prefix',     value: `\`${PREFIX}\``,                              inline: true },
          )
          .setFooter({ text: 'Krazod Hub' })
          .setTimestamp();

        return reply(message, embed);
      }

      // ── serverinfo ──────────────────────────────────────────────────────────
      case 'serverinfo': {
        const guild = message.guild;
        await guild.fetch().catch(() => {});

        const embed = new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle(guild.name)
          .setThumbnail(guild.iconURL({ size: 256 }) ?? '')
          .addFields(
            { name: 'Owner',          value: `<@${guild.ownerId}>`,                                inline: true },
            { name: 'Members',        value: `${guild.memberCount}`,                               inline: true },
            { name: 'Channels',       value: `${guild.channels.cache.size}`,                       inline: true },
            { name: 'Roles',          value: `${guild.roles.cache.size}`,                          inline: true },
            { name: 'Boost Level',    value: `${guild.premiumTier}`,                               inline: true },
            { name: 'Boosts',         value: `${guild.premiumSubscriptionCount ?? 0}`,             inline: true },
            { name: 'Created',        value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: false },
          )
          .setFooter({ text: `ID: ${guild.id}` })
          .setTimestamp();

        return reply(message, embed);
      }

      // ── userinfo ────────────────────────────────────────────────────────────
      case 'userinfo': {
        const target = message.mentions.members?.first() ?? message.member;
        const user   = target.user;

        const embed = new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle(`${user.tag}`)
          .setThumbnail(user.displayAvatarURL({ size: 256 }))
          .addFields(
            { name: 'ID',         value: `\`${user.id}\``,                                             inline: true },
            { name: 'Nickname',   value: target.nickname ?? '_None_',                                  inline: true },
            { name: 'Bot',        value: user.bot ? 'Yes' : 'No',                                      inline: true },
            { name: 'Joined',     value: `<t:${Math.floor(target.joinedTimestamp / 1000)}:F>`,         inline: true },
            { name: 'Registered', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>`,          inline: true },
          )
          .setFooter({ text: `Requested by ${message.author.tag}` })
          .setTimestamp();

        return reply(message, embed);
      }

      // ── avatar ──────────────────────────────────────────────────────────────
      case 'avatar': {
        const target = message.mentions.users.first() ?? message.author;
        const url    = target.displayAvatarURL({ size: 1024, extension: 'png' });

        const embed = new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle(`${target.username}'s Avatar`)
          .setImage(url)
          .setFooter({ text: `ID: ${target.id}` })
          .setTimestamp();

        return reply(message, embed);
      }

      // ── banner ──────────────────────────────────────────────────────────────
      case 'banner': {
        const target = message.mentions.users.first() ?? message.author;
        const fetched = await target.fetch().catch(() => target);
        const bannerUrl = fetched.bannerURL?.({ size: 1024 });

        if (!bannerUrl) {
          return reply(message, infoEmbed(`**${target.username}** does not have a banner.`));
        }

        const embed = new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle(`${target.username}'s Banner`)
          .setImage(bannerUrl)
          .setFooter({ text: `ID: ${target.id}` })
          .setTimestamp();

        return reply(message, embed);
      }

      // ── ban ─────────────────────────────────────────────────────────────────
      case 'ban': {
        if (!requirePerm(message, PermissionFlagsBits.BanMembers, 'Ban Members')) return;
        if (!requireBotPerm(message, PermissionFlagsBits.BanMembers, 'Ban Members')) return;

        const target = message.mentions.members?.first();
        if (!target) return reply(message, errorEmbed('Please mention a member to ban.\nUsage: `,ban @user [reason]`'));

        const reason = args.slice(1).join(' ') || 'No reason provided';

        if (!target.bannable) return reply(message, errorEmbed('I cannot ban this member. Check role hierarchy.'));

        await target.ban({ reason: `${message.author.tag}: ${reason}` });
        return reply(message, successEmbed(`**${target.user.tag}** has been banned. Reason: ${reason}`));
      }

      // ── kick ────────────────────────────────────────────────────────────────
      case 'kick': {
        if (!requirePerm(message, PermissionFlagsBits.KickMembers, 'Kick Members')) return;
        if (!requireBotPerm(message, PermissionFlagsBits.KickMembers, 'Kick Members')) return;

        const target = message.mentions.members?.first();
        if (!target) return reply(message, errorEmbed('Please mention a member to kick.\nUsage: `,kick @user [reason]`'));

        const reason = args.slice(1).join(' ') || 'No reason provided';

        if (!target.kickable) return reply(message, errorEmbed('I cannot kick this member. Check role hierarchy.'));

        await target.kick(`${message.author.tag}: ${reason}`);
        return reply(message, successEmbed(`**${target.user.tag}** has been kicked. Reason: ${reason}`));
      }

      // ── unban ───────────────────────────────────────────────────────────────
      case 'unban': {
        if (!requirePerm(message, PermissionFlagsBits.BanMembers, 'Ban Members')) return;
        if (!requireBotPerm(message, PermissionFlagsBits.BanMembers, 'Ban Members')) return;

        const userId = args[0];
        if (!userId) return reply(message, errorEmbed('Please provide a user ID to unban.\nUsage: `,unban <user-id>`'));

        try {
          await message.guild.members.unban(userId);
          return reply(message, successEmbed(`User \`${userId}\` has been unbanned.`));
        } catch {
          return reply(message, errorEmbed(`Could not unban \`${userId}\`. Make sure the ID is correct.`));
        }
      }

      // ── warn ────────────────────────────────────────────────────────────────
      case 'warn': {
        if (!requirePerm(message, PermissionFlagsBits.ModerateMembers, 'Moderate Members')) return;

        const target = message.mentions.members?.first();
        if (!target) return reply(message, errorEmbed('Please mention a member to warn.\nUsage: `,warn @user <reason>`'));

        const reason = args.slice(1).join(' ');
        if (!reason) return reply(message, errorEmbed('Please provide a reason.\nUsage: `,warn @user <reason>`'));

        const { getDB } = require('../database/db');
        getDB().prepare(
          'INSERT INTO warnings (guild_id, user_id, moderator_id, reason, timestamp) VALUES (?, ?, ?, ?, ?)',
        ).run(message.guild.id, target.id, message.author.id, reason, Date.now());

        return reply(message, successEmbed(`**${target.user.tag}** has been warned. Reason: ${reason}`));
      }

      // ── warnings ────────────────────────────────────────────────────────────
      case 'warnings': {
        const target = message.mentions.users.first() ?? message.author;
        const { getDB } = require('../database/db');
        const warns = getDB().prepare('SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY timestamp DESC').all(message.guild.id, target.id);

        if (!warns.length) {
          return reply(message, infoEmbed(`**${target.tag}** has no warnings on this server.`));
        }

        const lines = warns.map((w, i) => {
          const mod = `<@${w.moderator_id}>`;
          const ts  = `<t:${Math.floor(w.timestamp / 1000)}:R>`;
          return `**${i + 1}.** ${w.reason} — by ${mod} ${ts}`;
        }).slice(0, 10);

        const embed = new EmbedBuilder()
          .setColor(COLORS.warning)
          .setTitle(`Warnings — ${target.tag}`)
          .setDescription(lines.join('\n'))
          .setFooter({ text: `${warns.length} total warning${warns.length !== 1 ? 's' : ''}` })
          .setTimestamp();

        return reply(message, embed);
      }

      // ── timeout ─────────────────────────────────────────────────────────────
      case 'timeout': {
        if (!requirePerm(message, PermissionFlagsBits.ModerateMembers, 'Moderate Members')) return;
        if (!requireBotPerm(message, PermissionFlagsBits.ModerateMembers, 'Moderate Members')) return;

        const target = message.mentions.members?.first();
        if (!target) return reply(message, errorEmbed('Please mention a member to timeout.\nUsage: `,timeout @user <duration> [reason]`\nDurations: 60s, 10m, 1h, 1d'));

        const durationStr = args[1];
        if (!durationStr) return reply(message, errorEmbed('Please provide a duration (e.g. `60s`, `10m`, `1h`, `1d`).'));

        const ms = require('ms')(durationStr);
        if (!ms || ms > 28 * 24 * 60 * 60 * 1000) {
          return reply(message, errorEmbed('Invalid duration. Max timeout is 28 days.'));
        }

        const reason = args.slice(2).join(' ') || 'No reason provided';

        if (!target.moderatable) return reply(message, errorEmbed('I cannot timeout this member.'));

        await target.timeout(ms, reason);
        return reply(message, successEmbed(`**${target.user.tag}** has been timed out for \`${durationStr}\`. Reason: ${reason}`));
      }

      // ── untimeout ───────────────────────────────────────────────────────────
      case 'untimeout': {
        if (!requirePerm(message, PermissionFlagsBits.ModerateMembers, 'Moderate Members')) return;
        if (!requireBotPerm(message, PermissionFlagsBits.ModerateMembers, 'Moderate Members')) return;

        const target = message.mentions.members?.first();
        if (!target) return reply(message, errorEmbed('Please mention a member to remove timeout.\nUsage: `,untimeout @user`'));

        await target.timeout(null);
        return reply(message, successEmbed(`Timeout removed from **${target.user.tag}**.`));
      }

      // ── clear ───────────────────────────────────────────────────────────────
      case 'clear':
      case 'purge': {
        if (!requirePerm(message, PermissionFlagsBits.ManageMessages, 'Manage Messages')) return;
        if (!requireBotPerm(message, PermissionFlagsBits.ManageMessages, 'Manage Messages')) return;

        const amount = parseInt(args[0], 10);
        if (isNaN(amount) || amount < 1 || amount > 100) {
          return reply(message, errorEmbed('Please provide a number between 1 and 100.\nUsage: `,clear <amount>`'));
        }

        // Delete the command message too
        await message.delete().catch(() => {});
        const deleted = await message.channel.bulkDelete(amount, true).catch(() => null);
        const count   = deleted?.size ?? 0;

        const notice = await message.channel.send({
          embeds: [successEmbed(`Deleted **${count}** message${count !== 1 ? 's' : ''}.`)],
        }).catch(() => null);
        if (notice) setTimeout(() => notice.delete().catch(() => {}), 5000);
        return;
      }

      // ── afk ─────────────────────────────────────────────────────────────────
      case 'afk': {
        const reason = args.join(' ') || 'AFK';
        const { getDB } = require('../database/db');
        getDB().prepare(`
          INSERT INTO afk (guild_id, user_id, reason, timestamp)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(guild_id, user_id) DO UPDATE SET reason = excluded.reason, timestamp = excluded.timestamp
        `).run(message.guild.id, message.author.id, reason, Date.now());

        return reply(message, successEmbed(`You are now AFK: **${reason}**`));
      }

      // ── lock ────────────────────────────────────────────────────────────────
      case 'lock': {
        return reply(message, infoEmbed(
          'Use the interactive `/lock` command to select and lock a channel.\n\n' +
          'The interactive version lets you choose the channel with a selector and provides an Unlock button.',
          'Lock Channel',
        ));
      }

      // ── spam ────────────────────────────────────────────────────────────────
      case 'spam': {
        return reply(message, infoEmbed(
          'Use the interactive `/spam` command to configure spam protection with a full management panel.',
          'Spam Protection',
        ));
      }

      // ── ticket ──────────────────────────────────────────────────────────────
      case 'ticket': {
        return reply(message, infoEmbed(
          'Use `/ticket setup` to configure the ticket system, or open a ticket through the panel set up in your server.',
          'Ticket System',
        ));
      }

      // ── feedback ────────────────────────────────────────────────────────────
      case 'feedback': {
        return reply(message, infoEmbed(
          'Use `/feedback submit` to submit feedback, or `/feedback setup` to configure the feedback system.',
          'Feedback',
        ));
      }

      // ── Unknown prefix command ───────────────────────────────────────────────
      default:
        // Silently ignore unknown prefix commands to avoid spam
        break;
    }
  } catch (err) {
    logger.error(`Prefix command error (${command}):`, err.message);
    reply(message, errorEmbed(`An error occurred while running \`,${command}\`.`)).catch(() => {});
  }
}

module.exports = { handlePrefix, PREFIX };
