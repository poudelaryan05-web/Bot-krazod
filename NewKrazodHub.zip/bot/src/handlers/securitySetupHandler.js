'use strict';
/**
 * securitySetupHandler.js
 *
 * Handles all button, select-menu, channel-select, and modal interactions that begin with
 * "setup:security:".
 */

const {
  ModalBuilder, TextInputBuilder, TextInputStyle,
  ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder,
  ChannelSelectMenuBuilder, ChannelType,
} = require('discord.js');
const { getConfig, setConfig } = require('../database/db');
const { successEmbed, errorEmbed, COLORS } = require('../utils/embeds');

// ─── Option lists ─────────────────────────────────────────────────────────────
const LEVEL_OPTIONS = [
  { label: 'Low — Log only, no automatic actions',         value: 'low'     },
  { label: 'Medium — Strip roles + alerts (recommended)',  value: 'medium'  },
  { label: 'High — Kick / ban + lockdown on detection',    value: 'high'    },
  { label: 'Extreme — Instant ban + lockdown',             value: 'extreme' },
];

const NUKE_OPTIONS = [
  { label: 'Log — Alert only, no action',     value: 'log'        },
  { label: 'Strip Roles — Remove all roles',  value: 'stripRoles' },
  { label: 'Kick — Remove from server',       value: 'kick'       },
  { label: 'Ban — Permanent ban',             value: 'ban'        },
  { label: 'Lockdown — Lock all channels',    value: 'lockdown'   },
];

const RAID_OPTIONS = [
  { label: 'Log — Alert only',           value: 'log'      },
  { label: 'Kick — Remove joiners',      value: 'kick'     },
  { label: 'Ban — Ban all raid joiners', value: 'ban'      },
  { label: 'Lockdown — Lock server',     value: 'lockdown' },
];

const PHISHING_OPTIONS = [
  { label: 'Delete — Remove message only',            value: 'delete'  },
  { label: 'Timeout — Mute for 10 minutes',           value: 'timeout' },
  { label: 'Kick',                                    value: 'kick'    },
  { label: 'Ban — Recommended (account takeovers)',   value: 'ban'     },
];

const ALT_OPTIONS = [
  { label: 'Log — Alert only',       value: 'log'  },
  { label: 'Kick — Remove account',  value: 'kick' },
  { label: 'Ban',                    value: 'ban'  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────
function selectMenu(customId, placeholder, options) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder(placeholder)
      .addOptions(options),
  );
}

// ─── Main handler ─────────────────────────────────────────────────────────────
async function handleSecuritySetup(interaction) {
  const { customId } = interaction;
  const guildId      = interaction.guild.id;

  // ── Button interactions ───────────────────────────────────────────────────
  if (interaction.isButton()) {
    const current = getConfig(guildId, 'security') ?? {};

    switch (customId) {

      case 'setup:security:toggle_enable': {
        const newVal = !(current.enabled ?? false);
        setConfig(guildId, 'security', { ...current, enabled: newVal });
        return interaction.update({
          embeds: [new EmbedBuilder()
            .setColor(newVal ? COLORS.success : COLORS.muted)
            .setTitle('Security System')
            .setDescription(newVal
              ? 'Security **enabled**.'
              : 'Security **disabled**.')
            .setFooter({ text: 'Krazod Hub Security' })],
          components: [],
        });
      }

      case 'setup:security:toggle_safemode': {
        const newVal = !(current.safeMode !== false);
        setConfig(guildId, 'security', { ...current, safeMode: newVal });
        return interaction.update({
          embeds: [new EmbedBuilder()
            .setColor(newVal ? COLORS.success : COLORS.warning)
            .setTitle('Safe Mode')
            .setDescription(newVal
              ? 'Safe mode **enabled**.'
              : 'Safe mode **disabled**.')
            .setFooter({ text: 'Krazod Hub Security' })],
          components: [],
        });
      }

      case 'setup:security:reset': {
        setConfig(guildId, 'security', { enabled: false });
        return interaction.update({
          embeds: [successEmbed('Security configuration has been **reset to defaults**.')],
          components: [],
        });
      }

      case 'setup:security:set_level':
        return interaction.update({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('Security Level')
            .setDescription(
              '**Low** — Logs events only. No automatic punishments. Best for monitoring.\n\n' +
              '**Medium** — Strips dangerous roles from the offender. Recommended for most servers.\n\n' +
              '**High** — Kicks or bans the offender and activates lockdown if needed.\n\n' +
              '**Extreme** — Instant ban + full server lockdown on any detected threat.',
            )
            .setFooter({ text: 'Krazod Hub Security' })],
          components: [selectMenu('setup:security:select_level', 'Choose security level…', LEVEL_OPTIONS)],
        });

      case 'setup:security:set_nuke_action':
        return interaction.update({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('Anti-Nuke Response')
            .setDescription(
              'What should the bot do when a nuke attempt is detected?\n\n' +
              'A **nuke attempt** is when someone rapidly deletes channels, roles, mass-bans members, or mass-modifies permissions in a short window.',
            )
            .setFooter({ text: 'Krazod Hub Security' })],
          components: [selectMenu('setup:security:select_nuke_action', 'Choose nuke response…', NUKE_OPTIONS)],
        });

      case 'setup:security:set_raid_action':
        return interaction.update({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('Anti-Raid Response')
            .setDescription(
              'What should the bot do when a raid is detected?\n\n' +
              'A **raid** is when many users join in a very short period. Configure the join threshold with `/security threshold antiRaidJoins <count>`.',
            )
            .setFooter({ text: 'Krazod Hub Security' })],
          components: [selectMenu('setup:security:select_raid_action', 'Choose raid response…', RAID_OPTIONS)],
        });

      case 'setup:security:set_phishing_action':
        return interaction.update({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('Anti-Phishing Response')
            .setDescription(
              'What should the bot do when a phishing link is detected?\n\n' +
              'Phishing links are typically sent by **compromised accounts** to steal Discord tokens.\n' +
              '**Ban is strongly recommended** — a legitimate user will never send a phishing link.',
            )
            .setFooter({ text: 'Krazod Hub Security' })],
          components: [selectMenu('setup:security:select_phishing_action', 'Choose phishing response…', PHISHING_OPTIONS)],
        });

      case 'setup:security:set_alt_action':
        return interaction.update({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('Anti-Alt Response')
            .setDescription(
              'What should the bot do when a new/suspicious account joins?\n\n' +
              'Set the minimum account age with `/security threshold minAccountAgeDays <days>`.',
            )
            .setFooter({ text: 'Krazod Hub Security' })],
          components: [selectMenu('setup:security:select_alt_action', 'Choose alt response…', ALT_OPTIONS)],
        });

      // ── Alert Channel — now uses a ChannelSelectMenu instead of a modal ───
      case 'setup:security:set_alert_channel': {
        const row = new ActionRowBuilder().addComponents(
          new ChannelSelectMenuBuilder()
            .setCustomId('setup:security:select_alert_channel')
            .setPlaceholder('Select the security alert channel...')
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
        );
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('🛡️ Security Alert Channel')
            .setDescription('Select the text channel where security alerts will be posted.')
            .setFooter({ text: 'Krazod Hub Security' })],
          components: [row],
          flags: 1 << 6,
        });
      }

      case 'setup:security:set_window': {
        const modal = new ModalBuilder()
          .setCustomId('setup:security:modal_window')
          .setTitle('Set Detection Time Window');
        modal.addComponents(new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('window_seconds')
            .setLabel('Window in seconds (5 – 60)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('10')
            .setValue(String((current.windowMs ?? 10_000) / 1000))
            .setRequired(true),
        ));
        return interaction.showModal(modal);
      }

      default:
        return;
    }
  }

  // ── ChannelSelectMenu: alert channel ──────────────────────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'setup:security:select_alert_channel') {
    const channel = interaction.channels.first();
    if (!channel) {
      return interaction.reply({ embeds: [errorEmbed('No channel selected.')], flags: 1 << 6 });
    }
    const current = getConfig(guildId, 'security') ?? {};
    setConfig(guildId, 'security', { ...current, alertChannelId: channel.id });
    return interaction.reply({
      embeds: [successEmbed(`Alert channel set to <#${channel.id}>.`)],
      flags: 1 << 6,
    });
  }

  // ── StringSelectMenu interactions ─────────────────────────────────────────
  if (interaction.isStringSelectMenu()) {
    const current = getConfig(guildId, 'security') ?? {};
    const value   = interaction.values[0];

    switch (customId) {
      case 'setup:security:select_level':
        setConfig(guildId, 'security', { ...current, level: value });
        return interaction.update({ embeds: [successEmbed(`Security level set to **${value}**.`)], components: [] });

      case 'setup:security:select_nuke_action':
        setConfig(guildId, 'security', { ...current, nukeAction: value });
        return interaction.update({ embeds: [successEmbed(`Anti-nuke response set to **${value}**.`)], components: [] });

      case 'setup:security:select_raid_action':
        setConfig(guildId, 'security', { ...current, raidAction: value });
        return interaction.update({ embeds: [successEmbed(`Anti-raid response set to **${value}**.`)], components: [] });

      case 'setup:security:select_phishing_action':
        setConfig(guildId, 'security', { ...current, phishingAction: value });
        return interaction.update({ embeds: [successEmbed(`Anti-phishing response set to **${value}**.`)], components: [] });

      case 'setup:security:select_alt_action':
        setConfig(guildId, 'security', { ...current, altAction: value });
        return interaction.update({ embeds: [successEmbed(`Alt/new account response set to **${value}**.`)], components: [] });

      default:
        return;
    }
  }

  // ── Modal submissions ─────────────────────────────────────────────────────
  if (interaction.isModalSubmit()) {
    const current = getConfig(guildId, 'security') ?? {};

    switch (customId) {

      case 'setup:security:modal_window': {
        const raw     = interaction.fields.getTextInputValue('window_seconds').trim();
        const seconds = parseInt(raw, 10);
        if (isNaN(seconds) || seconds < 5 || seconds > 60) {
          return interaction.reply({
            embeds: [errorEmbed('Please enter a number between **5** and **60** seconds.')],
            flags: 1 << 6,
          });
        }
        setConfig(guildId, 'security', { ...current, windowMs: seconds * 1000 });
        return interaction.reply({
          embeds: [successEmbed(`Detection window set to **${seconds} seconds**.`)],
          flags: 1 << 6,
        });
      }

      default:
        return;
    }
  }
}

module.exports = { handleSecuritySetup };
