'use strict';
/**
 * loggingSetupHandler.js
 *
 * Handles interactions for the improved logging setup flow:
 *   1. StringSelectMenu: user picks categories (or "Log All")
 *   2. ChannelSelectMenu: user picks channel(s) for the selected categories
 */

const {
  ActionRowBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
  EmbedBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { getConfig, setConfig } = require('../database/db');
const { successEmbed, infoEmbed, COLORS } = require('../utils/embeds');
const { LOG_CATEGORIES } = require('../commands/utility/logging');

// ── Legacy button support (still works alongside new flow) ───────────────────
const LEGACY_CHANNEL_BUTTONS = {
  members:    { configKey: 'memberChannelId',     label: 'Members Log Channel' },
  moderation: { configKey: 'moderationChannelId', label: 'Moderation Log Channel' },
  messages:   { configKey: 'messageChannelId',    label: 'Messages Log Channel' },
  server:     { configKey: 'serverChannelId',     label: 'Server Log Channel' },
  tickets:    { configKey: 'ticketsChannelId',    label: 'Tickets Log Channel' },
  giveaways:  { configKey: 'giveawaysChannelId',  label: 'Giveaways Log Channel' },
  security:   { configKey: 'securityChannelId',   label: 'Security Log Channel' },
};

// Pending multi-category selections: Map<userId, string[]>
const pendingSelections = new Map();

async function handleLoggingSetup(interaction) {
  const { customId } = interaction;
  const guildId      = interaction.guild.id;

  // ── Legacy button: enable/disable toggle ────────────────────────────────────
  if (interaction.isButton() && customId === 'setup:logging:enable') {
    const current = getConfig(guildId, 'logging') ?? {};
    const newVal  = !current.enabled;
    setConfig(guildId, 'logging', { ...current, enabled: newVal });
    return interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(newVal ? COLORS.success : COLORS.muted)
        .setTitle('Logging System')
        .setDescription(newVal ? 'Logging **enabled**.' : 'Logging **disabled**.')
        .setFooter({ text: 'Krazod Hub Logging' })
        .setTimestamp()],
      flags: 1 << 6,
    });
  }

  // ── Legacy buttons: open channel select for specific category ────────────────
  if (interaction.isButton()) {
    const current = getConfig(guildId, 'logging') ?? {};
    const suffix  = customId.replace('setup:logging:', '');
    const meta    = LEGACY_CHANNEL_BUTTONS[suffix];
    if (!meta) return;

    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId(`setup:logging:select_${suffix}`)
        .setPlaceholder(`Select the ${meta.label}...`)
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    );

    return interaction.reply({
      embeds: [infoEmbed(`Select a channel for **${meta.label}**.`, meta.label)],
      components: [row],
      flags: 1 << 6,
    });
  }

  // ── New flow — Step 1: category select menu ──────────────────────────────────
  if (interaction.isStringSelectMenu() && customId === 'setup:logging:categories') {
    const selected = interaction.values;

    // "Log All" — ask for a single channel for everything
    if (selected.includes('log_all')) {
      pendingSelections.set(interaction.user.id, ['log_all']);

      const row = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('setup:logging:channel_for_all')
          .setPlaceholder('Select the channel for ALL log categories…')
          .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
      );

      return interaction.reply({
        embeds: [infoEmbed(
          'Choose one channel that will receive **all log categories**.',
          'Logging Setup — Step 2 of 2',
        )],
        components: [row],
        flags: 1 << 6,
      });
    }

    // Individual categories — if only one selected, go straight to channel select
    if (selected.length === 1) {
      const cat = LOG_CATEGORIES.find(c => c.value === selected[0]);
      if (!cat) return;

      pendingSelections.set(interaction.user.id, [selected[0]]);

      const row = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('setup:logging:channel_for_category')
          .setPlaceholder(`Select the channel for ${cat.label}…`)
          .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
      );

      return interaction.reply({
        embeds: [infoEmbed(
          `Select a channel for **${cat.label}** (${cat.description}).`,
          'Logging Setup — Step 2 of 2',
        )],
        components: [row],
        flags: 1 << 6,
      });
    }

    // Multiple categories selected — ask if they want one shared channel or separate
    pendingSelections.set(interaction.user.id, selected);

    const catLabels = selected.map(v => LOG_CATEGORIES.find(c => c.value === v)?.label ?? v).join(', ');

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('setup:logging:one_channel')
        .setLabel('One channel for all selected')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('setup:logging:separate_channels')
        .setLabel('Separate channels')
        .setStyle(ButtonStyle.Secondary),
    );

    return interaction.reply({
      embeds: [infoEmbed(
        `You selected: **${catLabels}**\n\nDo you want to use **one channel** for all of these, or configure **separate channels** for each?`,
        'Logging Setup — Channel Assignment',
      )],
      components: [row],
      flags: 1 << 6,
    });
  }

  // ── New flow — "One channel for all selected" button ─────────────────────────
  if (interaction.isButton() && customId === 'setup:logging:one_channel') {
    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('setup:logging:channel_for_category')
        .setPlaceholder('Select the channel for the selected categories…')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    );

    return interaction.reply({
      embeds: [infoEmbed('Select one channel for all the selected log categories.', 'Logging Setup — Step 2 of 2')],
      components: [row],
      flags: 1 << 6,
    });
  }

  // ── New flow — "Separate channels" button ────────────────────────────────────
  if (interaction.isButton() && customId === 'setup:logging:separate_channels') {
    const cats = pendingSelections.get(interaction.user.id) ?? [];
    if (!cats.length) {
      return interaction.reply({ embeds: [infoEmbed('Session expired. Run `/logging setup` again.')], flags: 1 << 6 });
    }

    // Start with the first category
    const firstCat = LOG_CATEGORIES.find(c => c.value === cats[0]);
    if (!firstCat) return;

    // Store remaining categories to handle one at a time
    pendingSelections.set(interaction.user.id, cats);

    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId(`setup:logging:channel_separate:${cats[0]}`)
        .setPlaceholder(`Channel for: ${firstCat.label}`)
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    );

    return interaction.reply({
      embeds: [infoEmbed(
        `Select the channel for **${firstCat.label}** (${firstCat.description}).\n\n_${cats.length} categor${cats.length !== 1 ? 'ies' : 'y'} remaining._`,
        'Logging Setup — Separate Channels',
      )],
      components: [row],
      flags: 1 << 6,
    });
  }

  // ── New flow — ChannelSelectMenu: "channel for all" ───────────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'setup:logging:channel_for_all') {
    const channel = interaction.channels.first();
    if (!channel) return interaction.reply({ embeds: [infoEmbed('No channel selected.')], flags: 1 << 6 });

    const current = getConfig(guildId, 'logging') ?? {};
    const update  = { ...current, enabled: true };

    for (const cat of LOG_CATEGORIES) {
      update[cat.configKey] = channel.id;
    }

    setConfig(guildId, 'logging', update);
    pendingSelections.delete(interaction.user.id);

    return interaction.reply({
      embeds: [successEmbed(
        `All ${LOG_CATEGORIES.length} log categories are now sending to ${channel}. Logging is **enabled**.`
      )],
      flags: 1 << 6,
    });
  }

  // ── New flow — ChannelSelectMenu: "channel for selected categories" ────────────
  if (interaction.isChannelSelectMenu() && customId === 'setup:logging:channel_for_category') {
    const channel = interaction.channels.first();
    if (!channel) return interaction.reply({ embeds: [infoEmbed('No channel selected.')], flags: 1 << 6 });

    const cats    = pendingSelections.get(interaction.user.id) ?? [];
    const current = getConfig(guildId, 'logging') ?? {};
    const update  = { ...current, enabled: true };

    for (const catValue of cats) {
      const cat = LOG_CATEGORIES.find(c => c.value === catValue);
      if (cat) update[cat.configKey] = channel.id;
    }

    setConfig(guildId, 'logging', update);
    pendingSelections.delete(interaction.user.id);

    const catLabels = cats.map(v => LOG_CATEGORIES.find(c => c.value === v)?.label ?? v).join(', ');

    return interaction.reply({
      embeds: [successEmbed(`${catLabels} → ${channel}. Logging is **enabled**.`)],
      flags: 1 << 6,
    });
  }

  // ── New flow — ChannelSelectMenu: separate channel per category ───────────────
  if (interaction.isChannelSelectMenu() && customId.startsWith('setup:logging:channel_separate:')) {
    const channel   = interaction.channels.first();
    if (!channel) return interaction.reply({ embeds: [infoEmbed('No channel selected.')], flags: 1 << 6 });

    const catValue  = customId.replace('setup:logging:channel_separate:', '');
    const cat       = LOG_CATEGORIES.find(c => c.value === catValue);
    if (!cat) return;

    const current   = getConfig(guildId, 'logging') ?? {};
    const update    = { ...current, enabled: true, [cat.configKey]: channel.id };
    setConfig(guildId, 'logging', update);

    // Find remaining categories for this user's session
    const allCats   = pendingSelections.get(interaction.user.id) ?? [];
    const remaining = allCats.slice(allCats.indexOf(catValue) + 1);

    if (remaining.length === 0) {
      pendingSelections.delete(interaction.user.id);
      return interaction.reply({
        embeds: [successEmbed('All selected log categories have been configured. Logging is **enabled**.')],
        flags: 1 << 6,
      });
    }

    const nextCat = LOG_CATEGORIES.find(c => c.value === remaining[0]);
    if (!nextCat) {
      pendingSelections.delete(interaction.user.id);
      return interaction.reply({ embeds: [successEmbed('Logging configuration saved.')], flags: 1 << 6 });
    }

    pendingSelections.set(interaction.user.id, allCats);

    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId(`setup:logging:channel_separate:${remaining[0]}`)
        .setPlaceholder(`Channel for: ${nextCat.label}`)
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    );

    return interaction.reply({
      embeds: [successEmbed(
        `**${cat.label}** → ${channel}.\n\nNow select the channel for **${nextCat.label}** (${nextCat.description}).\n\n_${remaining.length} categor${remaining.length !== 1 ? 'ies' : 'y'} remaining._`
      )],
      components: [row],
      flags: 1 << 6,
    });
  }

  // ── Legacy ChannelSelectMenu ──────────────────────────────────────────────────
  if (interaction.isChannelSelectMenu() && customId.startsWith('setup:logging:select_')) {
    const suffix = customId.replace('setup:logging:select_', '');
    const meta   = LEGACY_CHANNEL_BUTTONS[suffix];
    if (!meta) return;

    const channel = interaction.channels.first();
    if (!channel) return interaction.reply({ embeds: [infoEmbed('No channel selected.')], flags: 1 << 6 });

    const current = getConfig(guildId, 'logging') ?? {};
    setConfig(guildId, 'logging', { ...current, [meta.configKey]: channel.id, enabled: true });

    return interaction.reply({
      embeds: [successEmbed(`${meta.label} set to ${channel}. Logging is now **enabled**.`)],
      flags: 1 << 6,
    });
  }
}

module.exports = { handleLoggingSetup };
