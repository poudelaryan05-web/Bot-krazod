'use strict';
/**
 * verificationHandler.js
 *
 * Handles button/channel-select/role-select/modal interactions for setup:verification:* and verify:*
 */

const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ChannelType,
  ChannelSelectMenuBuilder, RoleSelectMenuBuilder,
} = require('discord.js');
const { getConfig, setConfig } = require('../database/db');
const { successEmbed, errorEmbed, COLORS } = require('../utils/embeds');

async function handleVerificationSetup(interaction) {
  const { customId } = interaction;
  const guildId      = interaction.guild.id;

  // ── Panel action: user clicking "Verify Me" ───────────────────────────────
  if (customId === 'verify:verify_me') {
    const config = getConfig(guildId, 'verification');
    if (!config?.verifiedRoleId) {
      return interaction.reply({ embeds: [errorEmbed('Verification system is not fully configured.')], flags: 1 << 6 });
    }

    const member = interaction.member;

    if (config.verifiedRoleId) {
      const vRole = interaction.guild.roles.cache.get(config.verifiedRoleId);
      if (vRole) await member.roles.add(vRole).catch(() => {});
    }

    if (config.unverifiedRoleId) {
      const uvRole = interaction.guild.roles.cache.get(config.unverifiedRoleId);
      if (uvRole) await member.roles.remove(uvRole).catch(() => {});
    }

    return interaction.reply({ embeds: [successEmbed('You have been verified! Welcome to the server.')], flags: 1 << 6 });
  }

  // ── Admin permission check for all setup interactions ─────────────────────
  if (!interaction.member.permissions.has(0x20n /* ManageGuild */)) {
    return interaction.reply({ embeds: [errorEmbed('You need **Manage Server** permission.')], flags: 1 << 6 });
  }

  // ── Setup buttons ─────────────────────────────────────────────────────────
  if (interaction.isButton()) {
    if (customId === 'setup:verification:panel_channel') {
      const row = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('setup:verification:select_panel_channel')
          .setPlaceholder('Select the verification panel channel...')
          .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
      );
      return interaction.reply({
        embeds: [{ description: 'Select the text channel where the verification panel will be posted.' }],
        components: [row],
        flags: 1 << 6,
      });
    }

    if (customId === 'setup:verification:verified_role') {
      const row = new ActionRowBuilder().addComponents(
        new RoleSelectMenuBuilder()
          .setCustomId('setup:verification:select_verified_role')
          .setPlaceholder('Select the role to give verified members...'),
      );
      return interaction.reply({
        embeds: [{ description: 'Select the role that verified members will receive.' }],
        components: [row],
        flags: 1 << 6,
      });
    }

    if (customId === 'setup:verification:unverified_role') {
      const row = new ActionRowBuilder().addComponents(
        new RoleSelectMenuBuilder()
          .setCustomId('setup:verification:select_unverified_role')
          .setPlaceholder('Select the role for unverified members (given on join)...'),
      );
      return interaction.reply({
        embeds: [{ description: 'Select the role given to new members before they verify. It will be removed after verification.' }],
        components: [row],
        flags: 1 << 6,
      });
    }

    if (customId === 'setup:verification:send_panel') {
      const current = getConfig(guildId, 'verification') ?? {};
      if (!current.panelChannelId) {
        return interaction.reply({ embeds: [errorEmbed('Please set a panel channel first.')], flags: 1 << 6 });
      }
      const ch = interaction.guild.channels.cache.get(current.panelChannelId);
      if (!ch || !ch.isTextBased()) {
        return interaction.reply({ embeds: [errorEmbed('Panel channel not found or is not a text channel.')], flags: 1 << 6 });
      }

      const panelEmbed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle('✅ Server Verification')
        .setDescription(
          `Welcome to **${interaction.guild.name}**!\n\n` +
          `To gain full access to the server, click the **Verify Me** button below.\n\n` +
          `By verifying, you agree to follow the server rules.`,
        )
        .setFooter({ text: 'Krazod Hub Verification' })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('verify:verify_me')
          .setLabel('Verify Me')
          .setStyle(ButtonStyle.Success)
          .setEmoji('✅'),
      );

      await ch.send({ embeds: [panelEmbed], components: [row] });
      return interaction.reply({ embeds: [successEmbed(`Verification panel sent to <#${ch.id}>!`)], flags: 1 << 6 });
    }
  }

  // ── ChannelSelectMenu: panel_channel ──────────────────────────────────────
  if (interaction.isChannelSelectMenu() && customId === 'setup:verification:select_panel_channel') {
    const channel = interaction.channels.first();
    if (!channel) return interaction.reply({ embeds: [errorEmbed('No channel selected.')], flags: 1 << 6 });
    const current = getConfig(guildId, 'verification') ?? {};
    setConfig(guildId, 'verification', { ...current, panelChannelId: channel.id });
    return interaction.reply({ embeds: [successEmbed(`Panel channel set to <#${channel.id}>!`)], flags: 1 << 6 });
  }

  // ── RoleSelectMenu: verified_role ─────────────────────────────────────────
  if (interaction.isRoleSelectMenu() && customId === 'setup:verification:select_verified_role') {
    const role = interaction.roles.first();
    if (!role) return interaction.reply({ embeds: [errorEmbed('No role selected.')], flags: 1 << 6 });
    const current = getConfig(guildId, 'verification') ?? {};
    setConfig(guildId, 'verification', { ...current, verifiedRoleId: role.id });
    return interaction.reply({ embeds: [successEmbed(`Verified role set to **${role.name}**!`)], flags: 1 << 6 });
  }

  // ── RoleSelectMenu: unverified_role ───────────────────────────────────────
  if (interaction.isRoleSelectMenu() && customId === 'setup:verification:select_unverified_role') {
    const role = interaction.roles.first();
    if (!role) return interaction.reply({ embeds: [errorEmbed('No role selected.')], flags: 1 << 6 });
    const current = getConfig(guildId, 'verification') ?? {};
    setConfig(guildId, 'verification', { ...current, unverifiedRoleId: role.id });
    return interaction.reply({ embeds: [successEmbed(`Unverified role set to **${role.name}**!`)], flags: 1 << 6 });
  }
}

module.exports = { handleVerificationSetup };
