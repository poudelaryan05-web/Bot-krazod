'use strict';
/**
 * automodSetupHandler.js
 *
 * Handles all button and select-menu interactions for the AutoMod setup system.
 * Routes: automod:toggle:*, automod:action:*
 */

const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { getConfig, setConfig } = require('../database/db');
const { successEmbed, COLORS } = require('../utils/embeds');

const ACTION_OPTIONS = [
  { label: 'Delete — Remove the message only',   value: 'delete'  },
  { label: 'Warn — Add a warning to the member', value: 'warn'    },
  { label: 'Timeout — Mute for 5 minutes',       value: 'timeout' },
  { label: 'Kick — Remove from the server',      value: 'kick'    },
  { label: 'Ban — Permanent ban',               value: 'ban'     },
];

// Toggle key → { label, actionKey }
const TOGGLES = {
  antiSpam:        { label: 'Anti-Spam',         actionKey: 'antiSpamAction'        },
  antiMentionSpam: { label: 'Anti-Mention Spam', actionKey: 'antiMentionSpamAction' },
  antiCaps:        { label: 'Anti-Caps',          actionKey: 'antiCapsAction'        },
  antiInvites:     { label: 'Anti-Invites',       actionKey: 'antiInvitesAction'     },
  antiLinks:       { label: 'Anti-Links',         actionKey: 'antiLinksAction'       },
  badWords:        { label: 'Bad Words Filter',   actionKey: 'badWordsAction'        },
};

async function handleAutomodSetup(interaction) {
  const { customId } = interaction;
  const guildId      = interaction.guild.id;

  // ── Toggle buttons ────────────────────────────────────────────────────────
  if (interaction.isButton() && customId.startsWith('automod:toggle:')) {
    const key    = customId.replace('automod:toggle:', '');
    const config = getConfig(guildId, 'automod') ?? {};

    // Enable/Disable the whole system
    if (key === 'enabled') {
      const newVal = !config.enabled;
      setConfig(guildId, 'automod', { ...config, enabled: newVal });
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(newVal ? COLORS.success : COLORS.muted)
          .setTitle('AutoMod')
          .setDescription(newVal ? 'AutoMod **enabled**.' : 'AutoMod **disabled**.')
          .setFooter({ text: 'Krazod Hub AutoMod' })
          .setTimestamp()],
        flags: 1 << 6,
      });
    }

    const meta = TOGGLES[key];
    if (!meta) return;

    const currentlyOn = !!config[key];

    if (currentlyOn) {
      // Turn off — no action select needed
      setConfig(guildId, 'automod', { ...config, [key]: false });
      return interaction.reply({
        embeds: [successEmbed(`**${meta.label}** has been **disabled**.`)],
        flags: 1 << 6,
      });
    }

    // Turn on — ask for action
    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`automod:action:${key}`)
        .setPlaceholder('Choose an action to take when triggered...')
        .addOptions(ACTION_OPTIONS),
    );

    return interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle(meta.label)
        .setDescription(`Choose what action to take when **${meta.label}** is triggered.`)
        .setFooter({ text: 'Krazod Hub AutoMod' })],
      components: [row],
      flags: 1 << 6,
    });
  }

  // ── Action select menus ───────────────────────────────────────────────────
  if (interaction.isStringSelectMenu() && customId.startsWith('automod:action:')) {
    const key    = customId.replace('automod:action:', '');
    const meta   = TOGGLES[key];
    if (!meta) return;

    const value  = interaction.values[0];
    const config = getConfig(guildId, 'automod') ?? {};

    setConfig(guildId, 'automod', {
      ...config,
      [key]: true,
      [meta.actionKey]: value,
      enabled: true,
    });

    return interaction.update({
      embeds: [successEmbed(`**${meta.label}** enabled with action \`${value}\`. AutoMod is now active.`)],
      components: [],
    });
  }
}

module.exports = { handleAutomodSetup };
