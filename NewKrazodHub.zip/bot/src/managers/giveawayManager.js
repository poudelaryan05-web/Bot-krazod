const { getDB } = require('../database/db');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { COLORS } = require('../utils/embeds');
const logger = require('../utils/logger');

function buildGiveawayEmbed(giveaway) {
  const entries = JSON.parse(giveaway.entries || '[]');
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(giveaway.prize)
    .setDescription(
      `Click the button below to enter!\n\n` +
      `**Ends:** <t:${Math.floor(giveaway.end_time / 1000)}:R>\n` +
      `**Winners:** ${giveaway.winner_count}\n` +
      `**Entries:** ${entries.length}` +
      (giveaway.required_role ? `\n**Required Role:** <@&${giveaway.required_role}>` : '')
    )
    .setFooter({ text: `Giveaway ID: ${giveaway.id} • Krazod Hub` })
    .setTimestamp();
  return embed;
}

function buildGiveawayRow(ended = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('giveaway:enter')
      .setLabel(ended ? 'Ended' : 'Enter Giveaway')
      .setStyle(ended ? ButtonStyle.Secondary : ButtonStyle.Primary)
      .setDisabled(ended),
  );
}

async function startGiveawayScheduler(client) {
  setInterval(() => checkGiveaways(client), 10_000);
  logger.info('Giveaway scheduler started.');
}

async function checkGiveaways(client) {
  const db = getDB();
  const now = Date.now();
  const ended = db.prepare('SELECT * FROM giveaways WHERE ended = 0 AND end_time <= ?').all(now);

  for (const g of ended) {
    await endGiveaway(client, g.id);
  }
}

async function endGiveaway(client, giveawayId) {
  const db = getDB();
  const giveaway = db.prepare('SELECT * FROM giveaways WHERE id = ?').get(giveawayId);
  if (!giveaway || giveaway.ended) return;

  db.prepare('UPDATE giveaways SET ended = 1 WHERE id = ?').run(giveawayId);

  const guild = client.guilds.cache.get(giveaway.guild_id);
  if (!guild) return;
  const channel = guild.channels.cache.get(giveaway.channel_id);
  if (!channel) return;

  const message = await channel.messages.fetch(giveaway.message_id).catch(() => null);
  const entries = JSON.parse(giveaway.entries || '[]');

  const winners = pickWinners(entries, giveaway.winner_count);
  db.prepare('UPDATE giveaways SET winners = ? WHERE id = ?').run(JSON.stringify(winners), giveawayId);

  const embed = new EmbedBuilder()
    .setColor(COLORS.success)
    .setTitle(`${giveaway.prize} — Ended`)
    .setDescription(
      winners.length > 0
        ? `**Winners:** ${winners.map(id => `<@${id}>`).join(', ')}\n**Entries:** ${entries.length}`
        : `No valid entries. No winner selected.\n**Entries:** ${entries.length}`
    )
    .setFooter({ text: `Giveaway ID: ${giveaway.id} • Krazod Hub` })
    .setTimestamp();

  if (message) {
    await message.edit({ embeds: [embed], components: [buildGiveawayRow(true)] }).catch(() => {});
  }

  if (winners.length > 0) {
    await channel.send({
      content: `Congratulations ${winners.map(id => `<@${id}>`).join(', ')}! You won **${giveaway.prize}**!`,
    }).catch(() => {});
  }
}

function pickWinners(entries, count) {
  if (entries.length === 0) return [];
  const shuffled = [...entries].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

module.exports = { startGiveawayScheduler, endGiveaway, buildGiveawayEmbed, buildGiveawayRow };
