'use strict';
const { AttachmentBuilder } = require('discord.js');
const { getDB, getConfig, getLevelReward, isDiskFull, handleDiskFull } = require('../database/db');
const { buildLevelCard } = require('../utils/levelCard');

/**
 * Returns the XP required to advance one level (i.e. to go from `level - 1` to `level`).
 *
 * Design goals
 * ─────────────
 *  Levels  1– 5  : very fast  — 1-3 messages each (30 / 45 / 60 / 75 / 90 XP)
 *  Levels  6–15  : easy       — 3-6 messages each (120 … 345 XP)
 *  Levels 16–30  : moderate   — gradually steeper  (405 … 1,305 XP)
 *  Levels   31+  : hard       — long-term grind     (1,365+ XP)
 *
 * Boundaries are smooth — no sudden cliff between any two adjacent bands.
 */
function xpForLevel(level) {
  if (level <= 5) {
    return 30 + (level - 1) * 15;
  } else if (level <= 15) {
    return 120 + (level - 5) * 25;
  } else if (level <= 30) {
    return 395 + (level - 15) * 60;
  } else if (level <= 60) {
    return 1355 + (level - 30) * 150;
  } else {
    return 5955 + (level - 60) * 400;
  }
}

function getUserLevel(guildId, userId) {
  return getDB().prepare('SELECT * FROM levels WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
}

async function handleXP(message) {
  if (!message.guild || message.author.bot) return;

  const config = getConfig(message.guild.id, 'levels');
  if (!config?.enabled) return;

  const db  = getDB();
  const now = Date.now();
  const cooldown = 60_000;

  try {
    db.prepare(`
      INSERT INTO levels (guild_id, user_id, xp, level, last_message)
      VALUES (?, ?, 0, 0, 0)
      ON CONFLICT(guild_id, user_id) DO NOTHING
    `).run(message.guild.id, message.author.id);
  } catch (err) {
    if (isDiskFull(err)) {
      handleDiskFull(err);
      return;
    }
    throw err;
  }

  const data = db.prepare('SELECT * FROM levels WHERE guild_id = ? AND user_id = ?')
    .get(message.guild.id, message.author.id);

  if (!data) return;

  if (now - data.last_message < cooldown) return;

  const gained = Math.floor(Math.random() * 10) + 15;
  let newXP    = data.xp + gained;
  let newLevel = data.level;

  const previousLevel = data.level;

  // ── Level-up loop — advance levels while XP exceeds the next threshold ──
  while (newXP >= xpForLevel(newLevel + 1)) {
    newXP -= xpForLevel(newLevel + 1);
    newLevel++;

    // ── Level reward (role assignment) — silent, no announcement embed ──────
    const reward = getLevelReward(message.guild.id, newLevel);
    if (reward) {
      const role = message.guild.roles.cache.get(reward.role_id);
      if (role && !message.member.roles.cache.has(role.id)) {
        await message.member.roles.add(role).catch(() => {});
        // Role is assigned silently — no embed or announcement is sent
      }
    }
  }

  // ── Persist FIRST — before sending any message ────────────────────────────
  try {
    db.prepare('UPDATE levels SET xp = ?, level = ?, last_message = ? WHERE guild_id = ? AND user_id = ?')
      .run(newXP, newLevel, now, message.guild.id, message.author.id);
  } catch (err) {
    if (isDiskFull(err)) {
      handleDiskFull(err);
      return;
    }
    throw err;
  }

  // ── Level-up announcement — only fires when the level actually increased ──
  if (newLevel > previousLevel) {
    const announceCh = config.levelUpChannelId
      ? message.guild.channels.cache.get(config.levelUpChannelId)
      : message.channel;

    if (announceCh) {
      const nextLevelXP = xpForLevel(newLevel + 1);
      const msgText =
        `${message.author} has reached **Level ${newLevel}**!\n` +
        `You need **${nextLevelXP}** XP to reach the next level. Keep going! ✨`;

      try {
        const cardBuffer = await buildLevelCard({
          username:   message.member?.displayName ?? message.author.username,
          avatarURL:  message.author.displayAvatarURL({ extension: 'png', size: 256 }),
          level:      newLevel,
          currentXP:  newXP,
          requiredXP: nextLevelXP,
        });
        const attachment = new AttachmentBuilder(cardBuffer, { name: 'levelup.png' });
        announceCh.send({ content: msgText, files: [attachment] }).catch(() => {});
      } catch {
        announceCh.send({ content: msgText }).catch(() => {});
      }
    }
  }
}

module.exports = { handleXP, getUserLevel, xpForLevel };
