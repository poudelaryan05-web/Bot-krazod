const { AttachmentBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const logger = require('../utils/logger');

// ─── Card dimensions ─────────────────────────────────────────────────────────
const W = 520;
const H = 460;

// ─── Ordinal suffix ───────────────────────────────────────────────────────────
function ordinal(n) {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return s[(v - 20) % 10] || s[v] || s[0];
}

// ─── Rounded rectangle helper ─────────────────────────────────────────────────
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.arcTo(x + w, y,     x + w, y + r,     r);
  ctx.lineTo(x + w, y + h - r);
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h);
  ctx.arcTo(x,     y + h, x,     y + h - r, r);
  ctx.lineTo(x,     y + r);
  ctx.arcTo(x,     y,     x + r, y,         r);
  ctx.closePath();
}

// ─── Truncate text ────────────────────────────────────────────────────────────
function truncate(ctx, text, maxWidth) {
  if (ctx.measureText(text).width <= maxWidth) return text;
  while (text.length > 2 && ctx.measureText(text + '…').width > maxWidth) {
    text = text.slice(0, -1);
  }
  return text + '…';
}

// ─── Card generator ───────────────────────────────────────────────────────────
/**
 * @param {'welcome'|'leave'} type
 * @param {{ username: string, memberCount: number, serverName: string, avatarURL?: string }} opts
 */
async function generateCard(type, { username, memberCount, serverName, avatarURL }) {
  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext('2d');

  // Colours
  const accent  = type === 'welcome' ? '#1ac6d4' : '#e05060'; // teal : pink-red
  const badgeText = type === 'welcome'
    ? `Member #${memberCount.toLocaleString()}${ordinal(memberCount)}`
    : 'Sad to see you go!';

  // ── Canvas background (transparent outer) ────────────────────────────────
  ctx.clearRect(0, 0, W, H);

  // ── Accent shadow card (offset behind main card) ─────────────────────────
  // Offset to bottom-left for welcome, bottom-right for leave (matches reference)
  const offsetX = type === 'welcome' ? -22 : 22;
  const offsetY = 22;
  ctx.save();
  ctx.globalAlpha = 0.85;
  ctx.fillStyle = accent;
  roundRect(ctx, 40 + offsetX, 40 + offsetY, W - 80, H - 80, 24);
  ctx.fill();
  ctx.restore();

  // ── Main dark card ───────────────────────────────────────────────────────
  ctx.save();
  ctx.fillStyle = '#1e1f26';
  roundRect(ctx, 40, 40, W - 80, H - 80, 24);
  ctx.fill();
  ctx.restore();

  // ── Pill badge ───────────────────────────────────────────────────────────
  const pillW  = Math.min(ctx.measureText(badgeText).width + 60, W - 100);
  const pillH  = 34;
  const pillX  = (W - pillW) / 2;
  const pillY  = 64;

  // measure after setting font
  ctx.font = 'bold 14px Sans';
  const textMW = ctx.measureText(badgeText).width;
  const actualPillW = textMW + 48;
  const actualPillX = (W - actualPillW) / 2;

  ctx.save();
  ctx.fillStyle = '#2c2d36';
  roundRect(ctx, actualPillX, pillY, actualPillW, pillH, pillH / 2);
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = '#ffffff';
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = 'bold 14px Sans';
  ctx.fillText(badgeText, W / 2, pillY + pillH / 2);

  // ── Avatar ───────────────────────────────────────────────────────────────
  const avatarCY = 210;
  const avatarR  = 72;
  const cx       = W / 2;

  // White ring
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, avatarCY, avatarR + 5, 0, Math.PI * 2);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.restore();

  // Avatar image or initial fallback
  if (avatarURL) {
    try {
      const img = await loadImage(avatarURL);
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, avatarCY, avatarR, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(img, cx - avatarR, avatarCY - avatarR, avatarR * 2, avatarR * 2);
      ctx.restore();
    } catch {
      // fallback initial
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, avatarCY, avatarR, 0, Math.PI * 2);
      ctx.fillStyle = accent;
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold 54px Sans`;
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(username.charAt(0).toUpperCase(), cx, avatarCY);
      ctx.restore();
    }
  } else {
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, avatarCY, avatarR, 0, Math.PI * 2);
    ctx.fillStyle = accent;
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold 54px Sans`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(username.charAt(0).toUpperCase(), cx, avatarCY);
    ctx.restore();
  }

  // ── Text block ────────────────────────────────────────────────────────────
  const maxTW = W - 100;

  // "Welcome / Goodbye"
  const actionWord = type === 'welcome' ? 'Welcome' : 'Goodbye';
  ctx.font = `bold 32px Sans`;
  const nameDisplay = truncate(ctx, `${actionWord} ${username}`, maxTW);

  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle    = '#ffffff';
  ctx.shadowColor  = 'rgba(0,0,0,0.5)';
  ctx.shadowBlur   = 4;
  ctx.fillText(nameDisplay, cx, 312);
  ctx.shadowBlur = 0;

  // "to" / "from" (small italic)
  ctx.font      = 'italic 18px Sans';
  ctx.fillStyle = '#a0a0b0';
  ctx.fillText(type === 'welcome' ? 'to' : 'from', cx, 345);

  // Server name
  ctx.font = '20px Sans';
  ctx.fillStyle = '#d0d0e0';
  const serverDisplay = truncate(ctx, serverName, maxTW);
  ctx.fillText(serverDisplay, cx, 375);

  return canvas.toBuffer('image/png');
}

// ─── Text message builders ────────────────────────────────────────────────────

function buildWelcomeMessage(member) {
  const user   = member.user.toString();
  const server = member.guild.name;
  const count  = member.guild.memberCount;
  return `Welcome ${user} to **${server}** you're member **#${count.toLocaleString()}${ordinal(count)}**!`;
}

function buildLeaveMessage(member) {
  const username = member.user.username;
  const server   = member.guild.name;
  return `User @${username} left from **${server}**`;
}

function replacePlaceholders(text, member) {
  return text
    .replace(/{user}/gi,        member.user.toString())
    .replace(/{username}/gi,    member.user.username)
    .replace(/{server}/gi,      member.guild.name)
    .replace(/{servername}/gi,  member.guild.name)
    .replace(/{membercount}/gi, member.guild.memberCount.toLocaleString());
}

// ─── Send helpers ─────────────────────────────────────────────────────────────

async function sendWelcomeMessage(member, config, _client) {
  const channel = member.guild.channels.cache.get(config.channelId);
  if (!channel || !channel.isTextBased()) return;

  try {
    const content  = config.message
      ? replacePlaceholders(config.message, member)
      : buildWelcomeMessage(member);

    const avatarURL = member.user.displayAvatarURL({ extension: 'png', size: 256 });

    const imgBuffer = await generateCard('welcome', {
      username:    member.user.displayName || member.user.username,
      memberCount: member.guild.memberCount,
      serverName:  member.guild.name,
      avatarURL,
    });

    const attachment = new AttachmentBuilder(imgBuffer, { name: 'welcome-card.png' });
    await channel.send({ content, files: [attachment] });
  } catch (err) {
    logger.error('sendWelcomeMessage error:', err);
  }
}

async function sendLeaveMessage(member, config, _client) {
  const channel = member.guild.channels.cache.get(config.channelId);
  if (!channel || !channel.isTextBased()) return;

  try {
    const content  = config.message
      ? replacePlaceholders(config.message, member)
      : buildLeaveMessage(member);

    const avatarURL = member.user.displayAvatarURL({ extension: 'png', size: 256 });

    const imgBuffer = await generateCard('leave', {
      username:    member.user.displayName || member.user.username,
      memberCount: member.guild.memberCount,
      serverName:  member.guild.name,
      avatarURL,
    });

    const attachment = new AttachmentBuilder(imgBuffer, { name: 'farewell-card.png' });
    await channel.send({ content, files: [attachment] });
  } catch (err) {
    logger.error('sendLeaveMessage error:', err);
  }
}

module.exports = { sendWelcomeMessage, sendLeaveMessage };
