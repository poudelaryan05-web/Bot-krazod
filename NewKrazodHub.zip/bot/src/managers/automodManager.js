'use strict';
const { getDB } = require('../database/db');
const { logEvent } = require('./loggingManager');
const ms = require('ms');

// Per-guild spam tracking: Map<guildId, Map<userId, { count, timestamp }>>
const spamMap = new Map();

async function applyAutoMod(message, config, client) {
  // ── Guard: config must be a valid object with at least one rule enabled ──
  if (!config || typeof config !== 'object') return false;

  const { guild, author, channel, content, mentions } = message;

  // --- Spam detection ---
  if (config.antiSpam) {
    const gMap = spamMap.get(guild.id) ?? new Map();
    spamMap.set(guild.id, gMap);
    const uData = gMap.get(author.id) ?? { count: 0, timestamp: Date.now() };

    if (Date.now() - uData.timestamp > 5000) {
      uData.count = 1;
      uData.timestamp = Date.now();
    } else {
      uData.count++;
    }
    gMap.set(author.id, uData);

    if (uData.count >= 5) {
      uData.count = 0;
      await punish(message, config.antiSpamAction ?? 'delete', 'Auto-Mod: Spam', config);
      return true;
    }
  }

  // --- Mention spam ---
  if (config.antiMentionSpam && mentions.users.size + mentions.roles.size > (config.maxMentions ?? 5)) {
    await punish(message, config.antiMentionSpamAction ?? 'delete', 'Auto-Mod: Mention Spam', config);
    return true;
  }

  // --- Caps lock ---
  if (config.antiCaps && content.length > 8) {
    const caps = content.replace(/[^A-Za-z]/g, '');
    if (caps.length > 4 && caps.toUpperCase() === caps && caps.length / content.length > 0.7) {
      await punish(message, config.antiCapsAction ?? 'delete', 'Auto-Mod: Excessive Caps', config);
      return true;
    }
  }

  // --- Invite links ---
  if (config.antiInvites && /(discord\.gg|discord\.com\/invite)\//i.test(content)) {
    await punish(message, config.antiInvitesAction ?? 'delete', 'Auto-Mod: Invite Link', config);
    return true;
  }

  // --- Suspicious links ---
  if (config.antiLinks && /https?:\/\//i.test(content)) {
    const whitelist = JSON.parse(config.linkWhitelist ?? '[]');
    const hasAllowed = whitelist.some(d => content.includes(d));
    if (!hasAllowed) {
      await punish(message, config.antiLinksAction ?? 'delete', 'Auto-Mod: Suspicious Link', config);
      return true;
    }
  }

  // --- Bad words ---
  if (config.badWords) {
    const words = JSON.parse(config.badWordsList ?? '[]');
    const lower = content.toLowerCase();
    if (words.some(w => lower.includes(w.toLowerCase()))) {
      await punish(message, config.badWordsAction ?? 'delete', 'Auto-Mod: Bad Word', config);
      return true;
    }
  }

  return false;
}

async function punish(message, action, reason, config) {
  try {
    await message.delete().catch(() => {});

    const member = message.member;
    if (!member) return;

    switch (action) {
      case 'warn': {
        const db = getDB();
        db.prepare('INSERT INTO warnings (guild_id, user_id, moderator_id, reason, timestamp) VALUES (?, ?, ?, ?, ?)')
          .run(message.guild.id, member.id, message.client.user.id, reason, Date.now());
        break;
      }
      case 'timeout':
        await member.timeout(ms('5m'), reason).catch(() => {});
        break;
      case 'kick':
        await member.kick(reason).catch(() => {});
        break;
      case 'ban':
        await message.guild.members.ban(member.id, { reason }).catch(() => {});
        break;
      default:
        break; // delete only
    }

    const notice = await message.channel.send({
      content: `<@${member.id}>, your message was removed. **Reason:** ${reason}`,
    }).catch(() => null);
    if (notice) setTimeout(() => notice.delete().catch(() => {}), 5000);

    await logEvent(message.guild, 'automod', {
      user: message.author,
      description: `Auto-Mod action applied: **${action}**`,
      fields: [
        { name: '⚙️ Reason', value: reason, inline: true },
        { name: '📍 Channel', value: `${message.channel}`, inline: true },
        { name: '📋 Action', value: `\`${action}\``, inline: true },
      ],
    });
  } catch {
    // Silent — automod must never crash the bot
  }
}

module.exports = { applyAutoMod };
