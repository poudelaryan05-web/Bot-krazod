'use strict';
/**
 * spamManager.js — In-memory anti-spam detection
 *
 * Tracks messages per user per guild within a sliding time window.
 * When the count exceeds the configured limit:
 *   1. Delete all spam messages from that user within the window
 *   2. Issue an automatic warning
 *   3. Send a clean warning message in the channel
 *   4. Log the spam event if Spam Logs are enabled
 *
 * Performance notes:
 *   - Uses a plain Map for per-guild, per-user tracking — O(1) lookups
 *   - Stale entries are pruned on each event (lazy cleanup)
 *   - No database writes for tracking — only for warnings
 *   - Bots are always ignored
 */

const logger = require('../utils/logger');
const { getConfig, getDB } = require('../database/db');
const { logEvent } = require('./loggingManager');
const { EmbedBuilder } = require('discord.js');
const { COLORS } = require('../utils/embeds');

// ── Per-guild message tracking ─────────────────────────────────────────────────
// Structure: Map<guildId, Map<userId, { messages: [{ id, timestamp }] }>>
const tracker = new Map();

function getGuildTracker(guildId) {
  if (!tracker.has(guildId)) tracker.set(guildId, new Map());
  return tracker.get(guildId);
}

function pruneOldMessages(msgs, windowMs) {
  const cutoff = Date.now() - windowMs;
  while (msgs.length > 0 && msgs[0].timestamp < cutoff) {
    msgs.shift();
  }
}

/**
 * Called from MessageCreate for every non-bot message.
 * Returns true if spam was detected (so the caller can skip other processing).
 */
async function checkSpam(message) {
  if (!message.guild || message.author.bot) return false;

  const config = getConfig(message.guild.id, 'spam');
  if (!config?.enabled) return false;

  const limit        = config.limit  ?? 5;
  const windowSec    = config.window ?? 5;
  const windowMs     = windowSec * 1000;
  const ignoreAdmins = config.ignoreAdmins !== false;

  // Ignore users with Administrator permission if configured (default: yes)
  if (ignoreAdmins && message.member?.permissions?.has(8n /* Administrator */)) return false;

  // Ignore users with Manage Messages or Manage Guild permissions (moderators)
  if (message.member?.permissions?.has(0x2000n /* ManageMessages */)) return false;

  const guildTracker = getGuildTracker(message.guild.id);

  if (!guildTracker.has(message.author.id)) {
    guildTracker.set(message.author.id, { messages: [] });
  }

  const userData = guildTracker.get(message.author.id);
  pruneOldMessages(userData.messages, windowMs);

  // Record this message
  userData.messages.push({ id: message.id, timestamp: Date.now(), channelId: message.channel.id });

  // Check if spam threshold exceeded
  if (userData.messages.length < limit) return false;

  // ── Spam detected ────────────────────────────────────────────────────────────
  const spamMessages = [...userData.messages];
  userData.messages = []; // Reset immediately to prevent repeated triggers

  // Delete all spam messages
  for (const sm of spamMessages) {
    try {
      const channel = message.guild.channels.cache.get(sm.channelId);
      if (channel) {
        const msg = await channel.messages.fetch(sm.id).catch(() => null);
        if (msg) await msg.delete().catch(() => {});
      }
    } catch { /* silent — message may already be gone */ }
  }

  // Issue an automatic warning (stored in DB)
  try {
    const db = getDB();
    db.prepare(`
      INSERT INTO warnings (guild_id, user_id, moderator_id, reason, timestamp)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      message.guild.id,
      message.author.id,
      message.client.user.id,
      `Automatic spam detection: sent ${spamMessages.length} messages within ${windowSec}s`,
      Date.now(),
    );
  } catch (err) {
    logger.error('spamManager: failed to save auto-warning:', err.message);
  }

  // Send a clean warning message in the channel
  try {
    const warningEmbed = new EmbedBuilder()
      .setColor(COLORS.warning)
      .setTitle('Spam Detected')
      .setDescription(
        `${message.author}, please slow down. Your messages have been removed.\n\n` +
        `Sending more than **${limit} messages** within **${windowSec} seconds** is not allowed.`
      )
      .addFields(
        { name: 'User',     value: `${message.author} (\`${message.author.id}\`)`, inline: true },
        { name: 'Channel',  value: `${message.channel}`,                           inline: true },
        { name: 'Messages', value: `${spamMessages.length} deleted`,               inline: true },
      )
      .setTimestamp()
      .setFooter({ text: 'Krazod Hub Spam Protection' });

    const warning = await message.channel.send({ embeds: [warningEmbed] }).catch(() => null);

    // Auto-delete warning after 10 seconds to keep the channel clean
    if (warning) setTimeout(() => warning.delete().catch(() => {}), 10_000);
  } catch { /* silent */ }

  // Log the spam event if logging is configured
  try {
    await logEvent(message.guild, 'spam', {
      user: message.author,
      description: `Spam detected: ${spamMessages.length} messages in ${windowSec}s`,
      fields: [
        { name: 'User',          value: `${message.author} (\`${message.author.id}\`)`, inline: true },
        { name: 'Channel',       value: `${message.channel}`,                           inline: true },
        { name: 'Messages Sent', value: `${spamMessages.length}`,                       inline: true },
        { name: 'Time Window',   value: `${windowSec} seconds`,                        inline: true },
        { name: 'Limit',         value: `${limit} messages`,                           inline: true },
      ],
    });
  } catch { /* logging must never crash the bot */ }

  return true;
}

module.exports = { checkSpam };
