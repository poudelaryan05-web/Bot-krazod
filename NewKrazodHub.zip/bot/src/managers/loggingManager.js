'use strict';
/**
 * loggingManager.js  —  Professional Logging System
 *
 * Provides:
 *   logEvent(guild, type, options)     — called from commands/handlers
 *   initLoggingManager(client)         — registers passive event listeners
 */

const { EmbedBuilder, AuditLogEvent, ChannelType } = require('discord.js');
const { getConfig } = require('../database/db');
const { COLORS } = require('../utils/embeds');
const logger = require('../utils/logger');

// ─── Channel routing ───────────────────────────────────────────────────────────
// Each event type maps to a primary config key, with an optional fallback key.
const LOG_CHANNEL_MAP = {
  // Members
  join:              { key: 'memberChannelId' },
  leave:             { key: 'memberChannelId' },
  memberUpdate:      { key: 'memberChannelId' },
  nicknameChange:    { key: 'memberChannelId' },
  avatarChange:      { key: 'memberChannelId' },
  roleAdd:           { key: 'roleChannelId',    fallback: 'memberChannelId' },
  roleRemove:        { key: 'roleChannelId',    fallback: 'memberChannelId' },
  usernameChange:    { key: 'memberChannelId' },
  voiceJoin:         { key: 'voiceChannelId',   fallback: 'memberChannelId' },
  voiceLeave:        { key: 'voiceChannelId',   fallback: 'memberChannelId' },
  voiceMove:         { key: 'voiceChannelId',   fallback: 'memberChannelId' },

  // Moderation
  ban:               { key: 'moderationChannelId' },
  unban:             { key: 'moderationChannelId' },
  kick:              { key: 'moderationChannelId' },
  timeout:           { key: 'moderationChannelId' },
  untimeout:         { key: 'moderationChannelId' },
  warn:              { key: 'moderationChannelId' },
  automod:           { key: 'automodChannelId',   fallback: 'moderationChannelId' },
  spam:              { key: 'moderationChannelId' },

  // Messages
  messageEdit:       { key: 'messageChannelId' },
  messageDelete:     { key: 'messageChannelId' },
  messageBulkDelete: { key: 'messageChannelId' },

  // Server
  channelCreate:     { key: 'channelLogsId',    fallback: 'serverChannelId' },
  channelDelete:     { key: 'channelLogsId',    fallback: 'serverChannelId' },
  channelUpdate:     { key: 'channelLogsId',    fallback: 'serverChannelId' },
  roleCreate:        { key: 'roleChannelId',    fallback: 'serverChannelId' },
  roleDelete:        { key: 'roleChannelId',    fallback: 'serverChannelId' },
  roleUpdate:        { key: 'roleChannelId',    fallback: 'serverChannelId' },
  guildUpdate:       { key: 'serverChannelId' },
  emojiCreate:       { key: 'emojiChannelId',   fallback: 'serverChannelId' },
  emojiDelete:       { key: 'emojiChannelId',   fallback: 'serverChannelId' },
  stickerCreate:     { key: 'stickerChannelId', fallback: 'serverChannelId' },
  stickerDelete:     { key: 'stickerChannelId', fallback: 'serverChannelId' },
  inviteCreate:      { key: 'inviteChannelId',  fallback: 'serverChannelId' },
  inviteDelete:      { key: 'inviteChannelId',  fallback: 'serverChannelId' },
  webhookCreate:     { key: 'webhookChannelId', fallback: 'serverChannelId' },
  webhookDelete:     { key: 'webhookChannelId', fallback: 'serverChannelId' },
  threadCreate:      { key: 'threadChannelId',  fallback: 'serverChannelId' },
  threadDelete:      { key: 'threadChannelId',  fallback: 'serverChannelId' },
  boostStart:        { key: 'boostChannelId',   fallback: 'serverChannelId' },

  // Tickets / Giveaways / Levels
  ticketOpen:        { key: 'ticketsChannelId' },
  ticketClose:       { key: 'ticketsChannelId' },
  giveawayStart:     { key: 'giveawaysChannelId' },
  giveawayEnd:       { key: 'giveawaysChannelId' },
  levelUp:           { key: 'levelChannelId' },

  // Security
  security:          { key: 'securityChannelId' },
};

// ─── Colors per event ─────────────────────────────────────────────────────────
const EVENT_COLOR = {
  join:              0x57F287,
  leave:             0x99AAB5,
  memberUpdate:      0x5865F2,
  nicknameChange:    0x5865F2,
  avatarChange:      0x5865F2,
  usernameChange:    0x5865F2,
  roleAdd:           0x3498DB,
  roleRemove:        0xE67E22,
  voiceJoin:         0x57F287,
  voiceLeave:        0x99AAB5,
  voiceMove:         0xFEE75C,

  ban:               0xED4245,
  unban:             0xFEE75C,
  kick:              0xED4245,
  timeout:           0xE67E22,
  untimeout:         0x57F287,
  warn:              0xFEE75C,
  automod:           0xE67E22,
  spam:              0xFEE75C,

  messageEdit:       0xFEE75C,
  messageDelete:     0xED4245,
  messageBulkDelete: 0xED4245,

  channelCreate:     0x57F287,
  channelDelete:     0xED4245,
  channelUpdate:     0xFEE75C,
  roleCreate:        0x57F287,
  roleDelete:        0xED4245,
  roleUpdate:        0xFEE75C,
  guildUpdate:       0x5865F2,
  emojiCreate:       0x57F287,
  emojiDelete:       0xED4245,
  stickerCreate:     0x57F287,
  stickerDelete:     0xED4245,
  inviteCreate:      0x57F287,
  inviteDelete:      0xED4245,
  webhookCreate:     0xFEE75C,
  webhookDelete:     0xED4245,
  threadCreate:      0x57F287,
  threadDelete:      0xED4245,
  boostStart:        0xFF73FA,

  ticketOpen:        0x57F287,
  ticketClose:       0x99AAB5,
  giveawayStart:     0xFF73FA,
  giveawayEnd:       0x57F287,
  levelUp:           0x5865F2,
  security:          0xED4245,
};

// ─── Event titles (no emojis — professional appearance) ───────────────────────
const EVENT_TITLE = {
  join:              'Member Joined',
  leave:             'Member Left',
  memberUpdate:      'Member Updated',
  nicknameChange:    'Nickname Changed',
  avatarChange:      'Avatar Changed',
  usernameChange:    'Username Changed',
  roleAdd:           'Role Added',
  roleRemove:        'Role Removed',
  voiceJoin:         'Joined Voice Channel',
  voiceLeave:        'Left Voice Channel',
  voiceMove:         'Moved Voice Channel',

  ban:               'Member Banned',
  unban:             'Member Unbanned',
  kick:              'Member Kicked',
  timeout:           'Member Timed Out',
  untimeout:         'Timeout Removed',
  warn:              'Member Warned',
  automod:           'AutoMod Action',
  spam:              'Spam Detected',

  messageEdit:       'Message Edited',
  messageDelete:     'Message Deleted',
  messageBulkDelete: 'Messages Bulk Deleted',

  channelCreate:     'Channel Created',
  channelDelete:     'Channel Deleted',
  channelUpdate:     'Channel Updated',
  roleCreate:        'Role Created',
  roleDelete:        'Role Deleted',
  roleUpdate:        'Role Updated',
  guildUpdate:       'Server Updated',
  emojiCreate:       'Emoji Added',
  emojiDelete:       'Emoji Deleted',
  stickerCreate:     'Sticker Added',
  stickerDelete:     'Sticker Deleted',
  inviteCreate:      'Invite Created',
  inviteDelete:      'Invite Deleted',
  webhookCreate:     'Webhook Created',
  webhookDelete:     'Webhook Deleted',
  threadCreate:      'Thread Created',
  threadDelete:      'Thread Deleted',
  boostStart:        'Server Boosted',

  ticketOpen:        'Ticket Opened',
  ticketClose:       'Ticket Closed',
  giveawayStart:     'Giveaway Started',
  giveawayEnd:       'Giveaway Ended',
  levelUp:           'Level Up',
  security:          'Security Alert',
};

// ─── Channel type label ───────────────────────────────────────────────────────
function channelTypeLabel(type) {
  const map = {
    [ChannelType.GuildText]:          'Text Channel',
    [ChannelType.GuildVoice]:         'Voice Channel',
    [ChannelType.GuildCategory]:      'Category',
    [ChannelType.GuildAnnouncement]:  'Announcement Channel',
    [ChannelType.GuildStageVoice]:    'Stage Channel',
    [ChannelType.GuildForum]:         'Forum Channel',
    [ChannelType.GuildThread]:        'Thread',
    [ChannelType.PublicThread]:       'Public Thread',
    [ChannelType.PrivateThread]:      'Private Thread',
  };
  return map[type] ?? 'Channel';
}

// ─── Truncate long strings for embed fields ───────────────────────────────────
function trunc(str, max = 1020) {
  if (!str) return '_None_';
  const s = String(str);
  return s.length > max ? s.slice(0, max - 3) + '…' : s;
}

// ─── Core send function ───────────────────────────────────────────────────────
async function sendLog(guild, type, embed) {
  try {
    const config = getConfig(guild.id, 'logging');
    if (!config?.enabled) return;

    const mapping = LOG_CHANNEL_MAP[type];
    if (!mapping) return;

    // Try primary key, then fallback key
    const channelId = config[mapping.key] ?? (mapping.fallback ? config[mapping.fallback] : null);
    if (!channelId) return;

    const channel = guild.channels.cache.get(channelId);
    if (!channel || !channel.isTextBased()) return;

    await channel.send({ embeds: [embed] });
  } catch {
    // Logging must never crash the bot
  }
}

// ─── logEvent — public API called from commands/handlers ─────────────────────
/**
 * @param {import('discord.js').Guild} guild
 * @param {string} type  — one of the keys in LOG_CHANNEL_MAP
 * @param {{ user?: import('discord.js').User, description?: string, fields?: {name:string,value:string,inline?:boolean}[], image?: string, thumbnail?: string }} opts
 */
async function logEvent(guild, type, { user, description, fields = [], image, thumbnail } = {}) {
  const embed = new EmbedBuilder()
    .setColor(EVENT_COLOR[type] ?? COLORS.muted)
    .setTitle(EVENT_TITLE[type] ?? type)
    .setDescription(trunc(description ?? 'No description', 4000))
    .setTimestamp()
    .setFooter({ text: 'Krazod Hub Logs' });

  if (user) embed.setAuthor({ name: `${user.tag ?? user.username}`, iconURL: user.displayAvatarURL?.() });
  if (thumbnail) embed.setThumbnail(thumbnail);
  if (image) embed.setImage(image);
  if (fields.length) embed.addFields(fields.slice(0, 25));

  await sendLog(guild, type, embed);
}

// ─── initLoggingManager — passive event listeners ─────────────────────────────
function initLoggingManager(client) {

  // ── Message Edit ─────────────────────────────────────────────────────────
  client.on('messageUpdate', async (oldMsg, newMsg) => {
    try {
      if (!newMsg.guild) return;
      if (newMsg.author?.bot) return;
      if (oldMsg.content === newMsg.content) return;

      const before = trunc(oldMsg.content || '_empty_', 1020);
      const after  = trunc(newMsg.content || '_empty_', 1020);

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.messageEdit)
        .setTitle(EVENT_TITLE.messageEdit)
        .setAuthor({ name: newMsg.author?.tag ?? 'Unknown', iconURL: newMsg.author?.displayAvatarURL() })
        .addFields(
          { name: 'Channel',    value: `${newMsg.channel}`, inline: true },
          { name: 'Message',    value: `[Jump to message](${newMsg.url})`, inline: true },
          { name: 'User ID',    value: `\`${newMsg.author?.id}\``, inline: true },
          { name: 'Before',     value: before },
          { name: 'After',      value: after  },
        )
        .setTimestamp()
        .setFooter({ text: `Message ID: ${newMsg.id}` });

      await sendLog(newMsg.guild, 'messageEdit', embed);
    } catch { /* silent */ }
  });

  // ── Message Delete ────────────────────────────────────────────────────────
  client.on('messageDelete', async (msg) => {
    try {
      if (!msg.guild) return;
      if (msg.author?.bot) return;

      let executor = null;
      try {
        const logs  = await msg.guild.fetchAuditLogs({ type: AuditLogEvent.MessageDelete, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === msg.author?.id) {
          executor = entry.executor;
        }
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.messageDelete)
        .setTitle(EVENT_TITLE.messageDelete)
        .setAuthor({ name: msg.author?.tag ?? 'Unknown User', iconURL: msg.author?.displayAvatarURL() })
        .addFields(
          { name: 'Channel',    value: `${msg.channel}`, inline: true },
          { name: 'Author ID',  value: `\`${msg.author?.id ?? 'Unknown'}\``, inline: true },
          { name: 'Deleted By', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          { name: 'Content',    value: trunc(msg.content || '_empty / attachment_', 1020) },
        )
        .setTimestamp()
        .setFooter({ text: `Message ID: ${msg.id}` });

      if (msg.attachments?.size) {
        embed.addFields({ name: 'Attachments', value: [...msg.attachments.values()].map(a => `[${a.name}](${a.url})`).join('\n'), inline: false });
      }

      await sendLog(msg.guild, 'messageDelete', embed);
    } catch { /* silent */ }
  });

  // ── Bulk Message Delete ───────────────────────────────────────────────────
  client.on('messageDeleteBulk', async (messages, channel) => {
    try {
      const guild = channel.guild;
      if (!guild) return;

      let executor = null;
      try {
        const logs  = await guild.fetchAuditLogs({ type: AuditLogEvent.MessageBulkDelete, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.messageBulkDelete)
        .setTitle(EVENT_TITLE.messageBulkDelete)
        .setDescription(`**${messages.size}** messages were bulk deleted in ${channel}.`)
        .addFields(
          { name: 'Channel',  value: `${channel}`, inline: true },
          { name: 'Count',    value: `${messages.size}`, inline: true },
          { name: 'Executor', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: 'Krazod Hub Logs' });

      await sendLog(guild, 'messageBulkDelete', embed);
    } catch { /* silent */ }
  });

  // ── Member Join ───────────────────────────────────────────────────────────
  client.on('guildMemberAdd', async (member) => {
    try {
      const createdAt      = `<t:${Math.floor(member.user.createdTimestamp / 1000)}:F>`;
      const accountAgeDays = Math.floor((Date.now() - member.user.createdTimestamp) / 86400000);

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.join)
        .setTitle(EVENT_TITLE.join)
        .setThumbnail(member.user.displayAvatarURL({ size: 128 }))
        .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
        .addFields(
          { name: 'User',            value: `${member} (\`${member.id}\`)`, inline: true },
          { name: 'Account Created', value: createdAt, inline: true },
          { name: 'Account Age',     value: `${accountAgeDays} day${accountAgeDays !== 1 ? 's' : ''}`, inline: true },
          { name: 'Member Count',    value: `${member.guild.memberCount}`, inline: true },
          { name: 'Bot',             value: member.user.bot ? 'Yes' : 'No', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `User ID: ${member.id}` });

      if (accountAgeDays < 7) embed.addFields({ name: 'New Account', value: 'This account is less than 7 days old.', inline: false });

      await sendLog(member.guild, 'join', embed);
    } catch { /* silent */ }
  });

  // ── Member Leave ──────────────────────────────────────────────────────────
  client.on('guildMemberRemove', async (member) => {
    try {
      const joinedAt = member.joinedAt ? `<t:${Math.floor(member.joinedAt.getTime() / 1000)}:F>` : '_Unknown_';
      const roles    = [...member.roles.cache.values()].filter(r => r.id !== member.guild.id).map(r => r.toString()).join(', ') || '_None_';

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.leave)
        .setTitle(EVENT_TITLE.leave)
        .setThumbnail(member.user.displayAvatarURL({ size: 128 }))
        .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
        .addFields(
          { name: 'User',         value: `${member} (\`${member.id}\`)`, inline: true },
          { name: 'Joined At',    value: joinedAt, inline: true },
          { name: 'Member Count', value: `${member.guild.memberCount}`, inline: true },
          { name: 'Roles',        value: trunc(roles, 1020) },
        )
        .setTimestamp()
        .setFooter({ text: `User ID: ${member.id}` });

      await sendLog(member.guild, 'leave', embed);
    } catch { /* silent */ }
  });

  // ── Member Update (nickname, roles, avatar, username) ────────────────────
  client.on('guildMemberUpdate', async (oldMember, newMember) => {
    try {
      const guild = newMember.guild;

      // Nickname change
      if (oldMember.nickname !== newMember.nickname) {
        const embed = new EmbedBuilder()
          .setColor(EVENT_COLOR.nicknameChange)
          .setTitle(EVENT_TITLE.nicknameChange)
          .setAuthor({ name: newMember.user.tag, iconURL: newMember.user.displayAvatarURL() })
          .addFields(
            { name: 'Member',       value: `${newMember} (\`${newMember.id}\`)`, inline: true },
            { name: 'Old Nickname', value: trunc(oldMember.nickname ?? '_None_'), inline: true },
            { name: 'New Nickname', value: trunc(newMember.nickname ?? '_None_'), inline: true },
          )
          .setTimestamp()
          .setFooter({ text: `User ID: ${newMember.id}` });
        await sendLog(guild, 'nicknameChange', embed);
      }

      // Role changes
      const addedRoles   = [...newMember.roles.cache.values()].filter(r => !oldMember.roles.cache.has(r.id) && r.id !== guild.id);
      const removedRoles = [...oldMember.roles.cache.values()].filter(r => !newMember.roles.cache.has(r.id) && r.id !== guild.id);

      if (addedRoles.length) {
        let executor = null;
        try {
          const logs  = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberRoleUpdate, limit: 1 });
          const entry = logs.entries.first();
          if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === newMember.id) executor = entry.executor;
        } catch { /* no audit access */ }

        const embed = new EmbedBuilder()
          .setColor(EVENT_COLOR.roleAdd)
          .setTitle(EVENT_TITLE.roleAdd)
          .setAuthor({ name: newMember.user.tag, iconURL: newMember.user.displayAvatarURL() })
          .addFields(
            { name: 'Member',       value: `${newMember} (\`${newMember.id}\`)`, inline: true },
            { name: 'Role(s) Added', value: addedRoles.map(r => r.toString()).join(', '), inline: true },
            { name: 'Executor',     value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          )
          .setTimestamp()
          .setFooter({ text: `User ID: ${newMember.id}` });
        await sendLog(guild, 'roleAdd', embed);
      }

      if (removedRoles.length) {
        let executor = null;
        try {
          const logs  = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberRoleUpdate, limit: 1 });
          const entry = logs.entries.first();
          if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === newMember.id) executor = entry.executor;
        } catch { /* no audit access */ }

        const embed = new EmbedBuilder()
          .setColor(EVENT_COLOR.roleRemove)
          .setTitle(EVENT_TITLE.roleRemove)
          .setAuthor({ name: newMember.user.tag, iconURL: newMember.user.displayAvatarURL() })
          .addFields(
            { name: 'Member',         value: `${newMember} (\`${newMember.id}\`)`, inline: true },
            { name: 'Role(s) Removed', value: removedRoles.map(r => r.toString()).join(', '), inline: true },
            { name: 'Executor',       value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          )
          .setTimestamp()
          .setFooter({ text: `User ID: ${newMember.id}` });
        await sendLog(guild, 'roleRemove', embed);
      }
    } catch { /* silent */ }
  });

  // ── User Update (global username / avatar change) ─────────────────────────
  client.on('userUpdate', async (oldUser, newUser) => {
    try {
      const guilds = [...client.guilds.cache.values()].filter(g => g.members.cache.has(newUser.id));

      for (const guild of guilds) {
        if (oldUser.username !== newUser.username) {
          const embed = new EmbedBuilder()
            .setColor(EVENT_COLOR.usernameChange)
            .setTitle(EVENT_TITLE.usernameChange)
            .setAuthor({ name: newUser.tag, iconURL: newUser.displayAvatarURL() })
            .addFields(
              { name: 'Old Username', value: trunc(oldUser.tag), inline: true },
              { name: 'New Username', value: trunc(newUser.tag), inline: true },
              { name: 'User ID',      value: `\`${newUser.id}\``, inline: true },
            )
            .setTimestamp()
            .setFooter({ text: `User ID: ${newUser.id}` });
          await sendLog(guild, 'usernameChange', embed);
        }

        if (oldUser.avatar !== newUser.avatar) {
          const embed = new EmbedBuilder()
            .setColor(EVENT_COLOR.avatarChange)
            .setTitle(EVENT_TITLE.avatarChange)
            .setAuthor({ name: newUser.tag, iconURL: newUser.displayAvatarURL() })
            .setThumbnail(newUser.displayAvatarURL({ size: 256 }))
            .addFields(
              { name: 'User',       value: `${newUser} (\`${newUser.id}\`)`, inline: true },
              { name: 'Old Avatar', value: oldUser.displayAvatarURL() ? `[View](${oldUser.displayAvatarURL({ size: 256 })})` : '_None_', inline: true },
            )
            .setTimestamp()
            .setFooter({ text: `User ID: ${newUser.id}` });
          await sendLog(guild, 'avatarChange', embed);
        }
      }
    } catch { /* silent */ }
  });

  // ── Ban Add ───────────────────────────────────────────────────────────────
  client.on('guildBanAdd', async (ban) => {
    try {
      let executor = null, reason = ban.reason;
      try {
        const logs  = await ban.guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanAdd, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === ban.user.id) {
          executor = entry.executor;
          reason   = reason ?? entry.reason;
        }
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.ban)
        .setTitle(EVENT_TITLE.ban)
        .setThumbnail(ban.user.displayAvatarURL({ size: 128 }))
        .addFields(
          { name: 'User',     value: `${ban.user} (\`${ban.user.id}\`)`, inline: true },
          { name: 'Executor', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          { name: 'Reason',   value: trunc(reason ?? '_No reason provided_') },
        )
        .setTimestamp()
        .setFooter({ text: `User ID: ${ban.user.id}` });
      await sendLog(ban.guild, 'ban', embed);
    } catch { /* silent */ }
  });

  // ── Ban Remove ────────────────────────────────────────────────────────────
  client.on('guildBanRemove', async (ban) => {
    try {
      let executor = null;
      try {
        const logs  = await ban.guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanRemove, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === ban.user.id) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.unban)
        .setTitle(EVENT_TITLE.unban)
        .setThumbnail(ban.user.displayAvatarURL({ size: 128 }))
        .addFields(
          { name: 'User',     value: `${ban.user} (\`${ban.user.id}\`)`, inline: true },
          { name: 'Executor', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `User ID: ${ban.user.id}` });
      await sendLog(ban.guild, 'unban', embed);
    } catch { /* silent */ }
  });

  // ── Channel Create ────────────────────────────────────────────────────────
  client.on('channelCreate', async (channel) => {
    try {
      if (!channel.guild) return;

      let executor = null;
      try {
        const logs  = await channel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelCreate, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === channel.id) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.channelCreate)
        .setTitle(EVENT_TITLE.channelCreate)
        .addFields(
          { name: 'Channel',  value: `${channel} (\`${channel.name}\`)`, inline: true },
          { name: 'Type',     value: channelTypeLabel(channel.type), inline: true },
          { name: 'Creator',  value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          { name: 'Category', value: channel.parent?.name ?? '_None_', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `Channel ID: ${channel.id}` });
      await sendLog(channel.guild, 'channelCreate', embed);
    } catch { /* silent */ }
  });

  // ── Channel Delete ────────────────────────────────────────────────────────
  client.on('channelDelete', async (channel) => {
    try {
      if (!channel.guild) return;

      let executor = null;
      try {
        const logs  = await channel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelDelete, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.channelDelete)
        .setTitle(EVENT_TITLE.channelDelete)
        .addFields(
          { name: 'Channel',  value: `\`${channel.name}\``, inline: true },
          { name: 'Type',     value: channelTypeLabel(channel.type), inline: true },
          { name: 'Executor', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          { name: 'Category', value: channel.parent?.name ?? '_None_', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `Channel ID: ${channel.id}` });
      await sendLog(channel.guild, 'channelDelete', embed);
    } catch { /* silent */ }
  });

  // ── Channel Update ────────────────────────────────────────────────────────
  client.on('channelUpdate', async (oldChannel, newChannel) => {
    try {
      if (!newChannel.guild) return;

      const changes = [];
      if (oldChannel.name !== newChannel.name) changes.push({ name: 'Name', value: `\`${oldChannel.name}\` → \`${newChannel.name}\``, inline: false });
      if (oldChannel.topic !== newChannel.topic) changes.push({ name: 'Topic', value: `**Before:** ${trunc(oldChannel.topic ?? '_None_', 400)}\n**After:** ${trunc(newChannel.topic ?? '_None_', 400)}`, inline: false });
      if (oldChannel.nsfw !== newChannel.nsfw) changes.push({ name: 'NSFW', value: `${oldChannel.nsfw} → ${newChannel.nsfw}`, inline: true });
      if (oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser) changes.push({ name: 'Slowmode', value: `${oldChannel.rateLimitPerUser}s → ${newChannel.rateLimitPerUser}s`, inline: true });
      if (oldChannel.bitrate !== newChannel.bitrate) changes.push({ name: 'Bitrate', value: `${oldChannel.bitrate} → ${newChannel.bitrate}`, inline: true });
      if (oldChannel.userLimit !== newChannel.userLimit) changes.push({ name: 'User Limit', value: `${oldChannel.userLimit} → ${newChannel.userLimit}`, inline: true });

      if (!changes.length) return;

      let executor = null;
      try {
        const logs  = await newChannel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelUpdate, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === newChannel.id) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.channelUpdate)
        .setTitle(EVENT_TITLE.channelUpdate)
        .addFields(
          { name: 'Channel',  value: `${newChannel} (\`${newChannel.name}\`)`, inline: true },
          { name: 'Executor', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          ...changes,
        )
        .setTimestamp()
        .setFooter({ text: `Channel ID: ${newChannel.id}` });
      await sendLog(newChannel.guild, 'channelUpdate', embed);
    } catch { /* silent */ }
  });

  // ── Role Create ───────────────────────────────────────────────────────────
  client.on('roleCreate', async (role) => {
    try {
      let executor = null;
      try {
        const logs  = await role.guild.fetchAuditLogs({ type: AuditLogEvent.RoleCreate, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === role.id) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.roleCreate)
        .setTitle(EVENT_TITLE.roleCreate)
        .addFields(
          { name: 'Role',    value: `${role} (\`${role.name}\`)`, inline: true },
          { name: 'Color',   value: role.hexColor, inline: true },
          { name: 'Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
          { name: 'Creator', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `Role ID: ${role.id}` });
      await sendLog(role.guild, 'roleCreate', embed);
    } catch { /* silent */ }
  });

  // ── Role Delete ───────────────────────────────────────────────────────────
  client.on('roleDelete', async (role) => {
    try {
      let executor = null;
      try {
        const logs  = await role.guild.fetchAuditLogs({ type: AuditLogEvent.RoleDelete, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.roleDelete)
        .setTitle(EVENT_TITLE.roleDelete)
        .addFields(
          { name: 'Role',             value: `\`${role.name}\``, inline: true },
          { name: 'Color',            value: role.hexColor, inline: true },
          { name: 'Executor',         value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          { name: 'Members Had Role', value: `${role.members?.size ?? '?'}`, inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `Role ID: ${role.id}` });
      await sendLog(role.guild, 'roleDelete', embed);
    } catch { /* silent */ }
  });

  // ── Role Update ───────────────────────────────────────────────────────────
  client.on('roleUpdate', async (oldRole, newRole) => {
    try {
      const changes = [];
      if (oldRole.name !== newRole.name) changes.push({ name: 'Name', value: `\`${oldRole.name}\` → \`${newRole.name}\``, inline: true });
      if (oldRole.color !== newRole.color) changes.push({ name: 'Color', value: `${oldRole.hexColor} → ${newRole.hexColor}`, inline: true });
      if (oldRole.hoist !== newRole.hoist) changes.push({ name: 'Hoisted', value: `${oldRole.hoist} → ${newRole.hoist}`, inline: true });
      if (oldRole.mentionable !== newRole.mentionable) changes.push({ name: 'Mentionable', value: `${oldRole.mentionable} → ${newRole.mentionable}`, inline: true });
      if (oldRole.permissions.bitfield !== newRole.permissions.bitfield) {
        const added   = newRole.permissions.toArray().filter(p => !oldRole.permissions.has(p));
        const removed = oldRole.permissions.toArray().filter(p => !newRole.permissions.has(p));
        if (added.length)   changes.push({ name: 'Permissions Added',   value: added.join(', '),   inline: false });
        if (removed.length) changes.push({ name: 'Permissions Removed', value: removed.join(', '), inline: false });
      }

      if (!changes.length) return;

      let executor = null;
      try {
        const logs  = await newRole.guild.fetchAuditLogs({ type: AuditLogEvent.RoleUpdate, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000 && entry.target?.id === newRole.id) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.roleUpdate)
        .setTitle(EVENT_TITLE.roleUpdate)
        .addFields(
          { name: 'Role',     value: `${newRole} (\`${newRole.name}\`)`, inline: true },
          { name: 'Executor', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          ...changes,
        )
        .setTimestamp()
        .setFooter({ text: `Role ID: ${newRole.id}` });
      await sendLog(newRole.guild, 'roleUpdate', embed);
    } catch { /* silent */ }
  });

  // ── Guild Update (server settings) ───────────────────────────────────────
  client.on('guildUpdate', async (oldGuild, newGuild) => {
    try {
      const changes = [];
      if (oldGuild.name !== newGuild.name) changes.push({ name: 'Server Name', value: `\`${oldGuild.name}\` → \`${newGuild.name}\``, inline: true });
      if (oldGuild.icon !== newGuild.icon) changes.push({ name: 'Server Icon', value: newGuild.iconURL() ? `[New Icon](${newGuild.iconURL({ size: 256 })})` : 'Removed', inline: true });
      if (oldGuild.verificationLevel !== newGuild.verificationLevel) changes.push({ name: 'Verification Level', value: `${oldGuild.verificationLevel} → ${newGuild.verificationLevel}`, inline: true });
      if (oldGuild.explicitContentFilter !== newGuild.explicitContentFilter) changes.push({ name: 'Content Filter', value: `${oldGuild.explicitContentFilter} → ${newGuild.explicitContentFilter}`, inline: true });
      if (oldGuild.afkChannelId !== newGuild.afkChannelId) changes.push({ name: 'AFK Channel', value: `${oldGuild.afkChannel ?? '_None_'} → ${newGuild.afkChannel ?? '_None_'}`, inline: true });

      if (!changes.length) return;

      let executor = null;
      try {
        const logs  = await newGuild.fetchAuditLogs({ type: AuditLogEvent.GuildUpdate, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000) executor = entry.executor;
      } catch { /* no audit access */ }

      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.guildUpdate)
        .setTitle(EVENT_TITLE.guildUpdate)
        .addFields(
          { name: 'Executor', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
          ...changes,
        )
        .setTimestamp()
        .setFooter({ text: `Guild ID: ${newGuild.id}` });
      await sendLog(newGuild, 'guildUpdate', embed);
    } catch { /* silent */ }
  });

  // ── Voice State Update ────────────────────────────────────────────────────
  client.on('voiceStateUpdate', async (oldState, newState) => {
    try {
      const guild  = newState.guild;
      const member = newState.member;
      if (!member || member.user.bot) return;

      if (!oldState.channelId && newState.channelId) {
        const embed = new EmbedBuilder()
          .setColor(EVENT_COLOR.voiceJoin)
          .setTitle(EVENT_TITLE.voiceJoin)
          .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
          .addFields(
            { name: 'Member',  value: `${member} (\`${member.id}\`)`, inline: true },
            { name: 'Channel', value: `${newState.channel}`, inline: true },
          )
          .setTimestamp()
          .setFooter({ text: `User ID: ${member.id}` });
        await sendLog(guild, 'voiceJoin', embed);
      } else if (oldState.channelId && !newState.channelId) {
        const embed = new EmbedBuilder()
          .setColor(EVENT_COLOR.voiceLeave)
          .setTitle(EVENT_TITLE.voiceLeave)
          .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
          .addFields(
            { name: 'Member',  value: `${member} (\`${member.id}\`)`, inline: true },
            { name: 'Channel', value: `${oldState.channel}`, inline: true },
          )
          .setTimestamp()
          .setFooter({ text: `User ID: ${member.id}` });
        await sendLog(guild, 'voiceLeave', embed);
      } else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
        const embed = new EmbedBuilder()
          .setColor(EVENT_COLOR.voiceMove)
          .setTitle(EVENT_TITLE.voiceMove)
          .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
          .addFields(
            { name: 'Member', value: `${member} (\`${member.id}\`)`, inline: true },
            { name: 'From',   value: `${oldState.channel}`, inline: true },
            { name: 'To',     value: `${newState.channel}`, inline: true },
          )
          .setTimestamp()
          .setFooter({ text: `User ID: ${member.id}` });
        await sendLog(guild, 'voiceMove', embed);
      }
    } catch { /* silent */ }
  });

  // ── Thread Create / Delete ────────────────────────────────────────────────
  client.on('threadCreate', async (thread) => {
    try {
      if (!thread.guild) return;
      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.threadCreate)
        .setTitle(EVENT_TITLE.threadCreate)
        .addFields(
          { name: 'Thread', value: `${thread} (\`${thread.name}\`)`, inline: true },
          { name: 'Parent', value: thread.parent ? `${thread.parent}` : '_Unknown_', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `Thread ID: ${thread.id}` });
      await sendLog(thread.guild, 'threadCreate', embed);
    } catch { /* silent */ }
  });

  client.on('threadDelete', async (thread) => {
    try {
      if (!thread.guild) return;
      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.threadDelete)
        .setTitle(EVENT_TITLE.threadDelete)
        .addFields(
          { name: 'Thread', value: `\`${thread.name}\``, inline: true },
          { name: 'Parent', value: thread.parent ? `${thread.parent}` : '_Unknown_', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `Thread ID: ${thread.id}` });
      await sendLog(thread.guild, 'threadDelete', embed);
    } catch { /* silent */ }
  });

  // ── Invite Create / Delete ────────────────────────────────────────────────
  client.on('inviteCreate', async (invite) => {
    try {
      if (!invite.guild) return;
      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.inviteCreate)
        .setTitle(EVENT_TITLE.inviteCreate)
        .addFields(
          { name: 'Code',     value: `\`${invite.code}\``, inline: true },
          { name: 'Channel',  value: invite.channel ? `${invite.channel}` : '_Unknown_', inline: true },
          { name: 'Creator',  value: invite.inviter ? `${invite.inviter} (\`${invite.inviter.id}\`)` : '_Unknown_', inline: true },
          { name: 'Expires',  value: invite.maxAge ? `<t:${Math.floor((Date.now() + invite.maxAge * 1000) / 1000)}:R>` : 'Never', inline: true },
          { name: 'Max Uses', value: invite.maxUses ? `${invite.maxUses}` : 'Unlimited', inline: true },
          { name: 'Link',     value: `https://discord.gg/${invite.code}`, inline: true },
        )
        .setTimestamp()
        .setFooter({ text: 'Krazod Hub Logs' });
      await sendLog(invite.guild, 'inviteCreate', embed);
    } catch { /* silent */ }
  });

  client.on('inviteDelete', async (invite) => {
    try {
      if (!invite.guild) return;
      const embed = new EmbedBuilder()
        .setColor(EVENT_COLOR.inviteDelete)
        .setTitle(EVENT_TITLE.inviteDelete)
        .addFields(
          { name: 'Code',    value: `\`${invite.code}\``, inline: true },
          { name: 'Channel', value: invite.channel ? `${invite.channel}` : '_Unknown_', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: 'Krazod Hub Logs' });
      await sendLog(invite.guild, 'inviteDelete', embed);
    } catch { /* silent */ }
  });

  // ── Server Boost ──────────────────────────────────────────────────────────
  client.on('guildMemberUpdate', async (oldMember, newMember) => {
    try {
      const wasBoosting = !!oldMember.premiumSince;
      const nowBoosting = !!newMember.premiumSince;
      if (!wasBoosting && nowBoosting) {
        const embed = new EmbedBuilder()
          .setColor(EVENT_COLOR.boostStart)
          .setTitle(EVENT_TITLE.boostStart)
          .setAuthor({ name: newMember.user.tag, iconURL: newMember.user.displayAvatarURL() })
          .setDescription(`${newMember} is now boosting **${newMember.guild.name}**!`)
          .addFields(
            { name: 'Boost Level',  value: `${newMember.guild.premiumTier}`, inline: true },
            { name: 'Total Boosts', value: `${newMember.guild.premiumSubscriptionCount}`, inline: true },
          )
          .setTimestamp()
          .setFooter({ text: `User ID: ${newMember.id}` });
        await sendLog(newMember.guild, 'boostStart', embed);
      }
    } catch { /* silent */ }
  });

  logger.info('[LOGGING] Logging manager initialized.');
}

module.exports = { logEvent, initLoggingManager };
