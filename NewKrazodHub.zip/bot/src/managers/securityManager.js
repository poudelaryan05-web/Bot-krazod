'use strict';
/**
 * securityManager.js  —  OP Level 1 Security System
 *
 * Protections:
 *  • Anti-nuke    (mass ban, kick, channel/role delete/create, webhook abuse, permission changes)
 *  • Anti-raid    (join flood detection, account age check, min account age)
 *  • Anti-phishing (URL pattern matching + token detection)
 *  • Anti-spam    (message flood per user, per channel)
 *  • Anti-mention spam
 *  • Alt detection (new/suspicious accounts)
 *  • Bot join monitoring
 *  • Lockdown system
 *  • Unauthorized administrator permission grant detection
 *  • Dangerous bot additions
 */

const {
  EmbedBuilder, PermissionFlagsBits, AuditLogEvent, ChannelType,
} = require('discord.js');
const { getConfig: _getConfig, setConfig } = require('../database/db');
const logger = require('../utils/logger');
const { COLORS } = require('../utils/embeds');

// ─── In-memory state ───────────────────────────────────────────────────────────
// Sliding window action counters: Map<`${guildId}:${userId}:${type}`, number[]>
const actionWindows = new Map();

// Raid state: Map<guildId, { joins: {userId,ts}[], active: boolean, activatedAt: number|null }>
const raidState = new Map();

// Lockdown state
const lockdownState = new Map();

// Message flood tracking: Map<`${guildId}:${userId}`, { msgs: number[], warned: boolean }>
const floodMap = new Map();

// Audit log cache
const auditCache = new Map();
const AUDIT_TTL_MS = 1200;

// ─── Phishing & malicious URL patterns ────────────────────────────────────────
const PHISHING_REGEX = new RegExp(
  'discord[._-]?(?:gift|nitro|gifts|free)[._-]?\\w*\\.' +
  '|free[._-]?nitro\\.' +
  '|dlscord\\.' +
  '|disc0rd\\.' +
  '|discorcl\\.' +
  '|nitro\\.snipe' +
  '|claimnitro\\.' +
  '|steamc[o0]mmunity(?!\\.com(?:\\/|$))' +
  '|gift\\.discordapp' +
  '|discordapp\\.(?!com)' +
  '|discordsexzy\\.' +
  '|discordgift\\.' +
  '|discordnltrp\\.' +
  '|getdiscordnitro\\.' +
  '|discordpremium\\.',
  'i',
);

// Discord token pattern (rough — catches both legacy and new format)
const TOKEN_REGEX = /[A-Za-z0-9_-]{23,28}\.[A-Za-z0-9_-]{6,7}\.[A-Za-z0-9_-]{27,}/;

// ─── Dangerous permissions ────────────────────────────────────────────────────
const DANGEROUS_PERMS = [
  PermissionFlagsBits.Administrator,
  PermissionFlagsBits.ManageGuild,
  PermissionFlagsBits.ManageChannels,
  PermissionFlagsBits.ManageRoles,
  PermissionFlagsBits.BanMembers,
  PermissionFlagsBits.KickMembers,
  PermissionFlagsBits.ManageWebhooks,
  PermissionFlagsBits.ModerateMembers,
];

// ─── Default config ────────────────────────────────────────────────────────────
function defaultConfig() {
  return {
    enabled: false,
    level: 'medium',      // low | medium | high | extreme
    safeMode: true,
    windowMs: 10_000,     // 10s sliding window for nuke detection
    raidWindowMs: 30_000, // 30s window for raid detection
    thresholds: {
      massBan:            3,   // OP Level 1 — tighter than default
      massKick:           3,
      massChannelDelete:  2,
      massChannelCreate:  5,
      massRoleDelete:     2,
      massRoleCreate:     5,
      massWebhookDelete:  2,
      massWebhookCreate:  3,
      massEmojiDelete:    4,
      massPermChange:     3,
      antiRaidJoins:      7,   // tighter join threshold
      minAccountAgeDays:  7,
      floodMessages:      7,   // messages per 5s before flood action
      massKickChannel:    5,   // mass messages deleted in bulk before flagging
    },
    nukeAction: 'stripRoles',   // log | stripRoles | kick | ban | lockdown
    raidAction: 'kick',
    phishingAction: 'ban',
    altAction: 'kick',
    floodAction: 'timeout',     // action for message flood
    alertChannelId: null,
    trustedUsers: [],
    trustedRoles: [],
    whitelist: [],
    autoUnlockMs: 0,
    logBotJoins: true,          // alert when new bots are added
    antiToken: true,            // detect and delete Discord token leaks
    antiMentionSpam: true,      // detect mass mention attacks
    mentionThreshold: 5,        // max mentions per message
  };
}

// ─── Config helpers ────────────────────────────────────────────────────────────
function getGuildConfig(guildId) {
  const stored = _getConfig(guildId, 'security');
  if (!stored) return defaultConfig();
  const def = defaultConfig();
  return {
    ...def,
    ...stored,
    thresholds: { ...def.thresholds, ...(stored.thresholds ?? {}) },
    trustedUsers: Array.isArray(stored.trustedUsers) ? stored.trustedUsers : [],
    trustedRoles: Array.isArray(stored.trustedRoles) ? stored.trustedRoles : [],
    whitelist:    Array.isArray(stored.whitelist)    ? stored.whitelist    : [],
  };
}

function isWhitelisted(guildId, userId, memberRoleIds = []) {
  const cfg = getGuildConfig(guildId);
  if (!cfg.enabled) return true;
  if (cfg.whitelist.includes(userId))    return true;
  if (cfg.trustedUsers.includes(userId)) return true;
  if (memberRoleIds.some(r => cfg.trustedRoles.includes(r))) return true;
  return false;
}

// ─── Sliding window counter ────────────────────────────────────────────────────
function recordAction(guildId, userId, actionType, windowMs) {
  const key  = `${guildId}:${userId}:${actionType}`;
  const now  = Date.now();
  const prev = actionWindows.get(key) ?? [];
  const next = prev.filter(ts => now - ts <= windowMs);
  next.push(now);
  actionWindows.set(key, next);
  return next.length;
}

function clearActionCounter(guildId, userId, actionType) {
  actionWindows.delete(`${guildId}:${userId}:${actionType}`);
}

// ─── Audit log helper ──────────────────────────────────────────────────────────
async function getAuditExecutor(guild, auditAction, targetId, maxAgeMs = 5000) {
  const cacheKey = `${guild.id}:${auditAction}:${targetId ?? 'any'}`;
  const cached = auditCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < AUDIT_TTL_MS) return cached.executor;

  try {
    const logs  = await guild.fetchAuditLogs({ type: auditAction, limit: 5 });
    const now   = Date.now();
    const entry = logs.entries.find(e => {
      if (now - e.createdTimestamp > maxAgeMs) return false;
      if (targetId && e.target?.id !== targetId) return false;
      return true;
    });
    const executor = entry?.executor ?? null;
    auditCache.set(cacheKey, { ts: now, executor });
    setTimeout(() => auditCache.delete(cacheKey), AUDIT_TTL_MS + 200);
    return executor;
  } catch {
    return null;
  }
}

// ─── Security alert sender ─────────────────────────────────────────────────────
async function sendSecurityAlert(guild, embed) {
  try {
    const cfg = getGuildConfig(guild.id);
    if (cfg.alertChannelId) {
      const ch = guild.channels.cache.get(cfg.alertChannelId);
      if (ch?.isTextBased()) ch.send({ embeds: [embed] }).catch(() => {});
    }

    // Also log to the logging module's security channel if configured
    const logCfg = _getConfig(guild.id, 'logging');
    if (logCfg?.enabled && logCfg.securityChannelId) {
      const ch = guild.channels.cache.get(logCfg.securityChannelId);
      if (ch?.isTextBased() && logCfg.securityChannelId !== cfg.alertChannelId) {
        ch.send({ embeds: [embed] }).catch(() => {});
      }
    }
  } catch { /* never crash */ }
}

// ─── Punishment ────────────────────────────────────────────────────────────────
async function punishUser(guild, userId, action, reason) {
  if (action === 'log') return;

  const member = guild.members.cache.get(userId)
    ?? await guild.members.fetch(userId).catch(() => null);

  if (!member) {
    if (action === 'ban') {
      await guild.members.ban(userId, { reason, deleteMessageSeconds: 0 }).catch(() => {});
    }
    return;
  }
  if (member.id === guild.client.user.id) return;
  if (member.id === guild.ownerId)        return;

  const cfg = getGuildConfig(guild.id);
  let effectiveAction = action;
  if (member.permissions.has(PermissionFlagsBits.Administrator) && action !== 'ban' && cfg.safeMode) {
    effectiveAction = 'stripRoles';
  }

  try {
    switch (effectiveAction) {
      case 'stripRoles': {
        const manageable = member.roles.cache.filter(r => r.id !== guild.id && r.editable);
        if (manageable.size > 0) {
          await member.roles.remove([...manageable.keys()], reason).catch(() => {});
        }
        break;
      }
      case 'kick':
        await member.kick(reason).catch(() => {});
        break;
      case 'ban':
        await guild.members.ban(userId, { reason, deleteMessageSeconds: 0 }).catch(() => {});
        break;
      case 'timeout':
        await member.timeout(10 * 60 * 1000, reason).catch(() => {}); // 10 minutes
        break;
      case 'lockdown':
        await activateLockdown(guild, reason, guild.client.user.id);
        break;
    }
  } catch (err) {
    logger.error(`[SECURITY] punishUser error (${effectiveAction}) for ${userId}:`, err.message);
  }
}

// ─── Lockdown ─────────────────────────────────────────────────────────────────
async function activateLockdown(guild, reason = 'Security lockdown', executorId = null) {
  const existing = lockdownState.get(guild.id);
  if (existing?.active) return;

  const overwrites = new Map();

  try {
    const textChannels = guild.channels.cache.filter(c =>
      c.type === ChannelType.GuildText && c.permissionsFor(guild.id)?.has(PermissionFlagsBits.SendMessages)
    );

    for (const [, ch] of textChannels) {
      try {
        const current = ch.permissionOverwrites.cache.get(guild.id);
        overwrites.set(ch.id, current ? { allow: current.allow.bitfield, deny: current.deny.bitfield } : null);
        await ch.permissionOverwrites.edit(guild.id, { SendMessages: false }, { reason });
      } catch { /* skip */ }
    }

    lockdownState.set(guild.id, {
      active: true,
      activatedAt: Date.now(),
      reason,
      executorId,
      overwrites,
    });

    logger.warn(`[SECURITY] Lockdown activated in guild ${guild.id}: ${reason}`);

    const embed = new EmbedBuilder()
      .setColor(COLORS.error)
      .setTitle('🔒 Server Lockdown Activated')
      .setDescription(`All text channels have been locked.\n\n**Reason:** ${reason}`)
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(guild, embed);
  } catch (err) {
    logger.error('[SECURITY] Lockdown activation error:', err.message);
  }
}

async function deactivateLockdown(guild, executorId = null) {
  const state = lockdownState.get(guild.id);
  if (!state?.active) return false;

  try {
    for (const [channelId, savedOverwrite] of state.overwrites) {
      const ch = guild.channels.cache.get(channelId);
      if (!ch) continue;
      try {
        if (savedOverwrite) {
          await ch.permissionOverwrites.edit(guild.id, {
            SendMessages: null,
          }).catch(() => {});
        } else {
          const ow = ch.permissionOverwrites.cache.get(guild.id);
          if (ow) await ow.delete().catch(() => {});
        }
      } catch { /* skip */ }
    }

    lockdownState.set(guild.id, { active: false, activatedAt: null, reason: null, executorId: null, overwrites: new Map() });

    logger.info(`[SECURITY] Lockdown deactivated in guild ${guild.id}`);

    const embed = new EmbedBuilder()
      .setColor(COLORS.success)
      .setTitle('🔓 Server Lockdown Lifted')
      .setDescription('Channel permissions have been restored.')
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(guild, embed);
    return true;
  } catch (err) {
    logger.error('[SECURITY] Lockdown deactivation error:', err.message);
    return false;
  }
}

function getLockdownState(guildId) {
  return lockdownState.get(guildId) ?? { active: false };
}

// ─── Anti-phishing ────────────────────────────────────────────────────────────
async function handleAntiPhishing(message) {
  const cfg = getGuildConfig(message.guild.id);
  if (!cfg.enabled) return;

  const content = message.content;

  // Token detection
  if (cfg.antiToken !== false && TOKEN_REGEX.test(content)) {
    await message.delete().catch(() => {});
    const embed = new EmbedBuilder()
      .setColor(COLORS.error)
      .setTitle('🛡️ Discord Token Detected & Removed')
      .setDescription(`A possible Discord token was detected and deleted in ${message.channel}.`)
      .addFields(
        { name: '👤 User', value: `${message.author} (\`${message.author.id}\`)`, inline: true },
        { name: '📍 Channel', value: `${message.channel}`, inline: true },
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();
    await sendSecurityAlert(message.guild, embed);
    return;
  }

  // Phishing URL detection
  if (PHISHING_REGEX.test(content)) {
    await message.delete().catch(() => {});

    const action = cfg.phishingAction ?? 'ban';

    const embed = new EmbedBuilder()
      .setColor(COLORS.error)
      .setTitle('🎣 Phishing Link Detected')
      .setDescription(
        `A phishing link was detected and removed.\n\n` +
        `**User:** ${message.author} (\`${message.author.id}\`)\n` +
        `**Channel:** ${message.channel}\n` +
        `**Action:** \`${action}\``,
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(message.guild, embed);

    if (action !== 'delete') {
      await punishUser(message.guild, message.author.id, action, 'Krazod Hub Security: Phishing link');
    }

    const notice = await message.channel.send({
      content: `${message.author}, sending phishing links is not allowed. **Action:** \`${action}\``,
    }).catch(() => null);
    if (notice) setTimeout(() => notice.delete().catch(() => {}), 8000);
  }
}

// ─── Message flood detection ───────────────────────────────────────────────────
async function handleFloodDetection(message) {
  const cfg = getGuildConfig(message.guild.id);
  if (!cfg.enabled) return;

  const threshold = cfg.thresholds?.floodMessages ?? 7;
  const windowMs  = 5000; // 5 second window
  const key       = `${message.guild.id}:${message.author.id}`;
  const now       = Date.now();

  const data = floodMap.get(key) ?? { msgs: [], warned: false };
  data.msgs = data.msgs.filter(ts => now - ts <= windowMs);
  data.msgs.push(now);
  floodMap.set(key, data);

  if (data.msgs.length >= threshold && !data.warned) {
    data.warned = true;
    // Reset after window
    setTimeout(() => {
      const d = floodMap.get(key);
      if (d) { d.msgs = []; d.warned = false; }
    }, windowMs * 2);

    if (isWhitelisted(message.guild.id, message.author.id, [...(message.member?.roles.cache.keys() ?? [])])) return;

    const action = cfg.floodAction ?? 'timeout';

    const embed = new EmbedBuilder()
      .setColor(COLORS.warning)
      .setTitle('🌊 Message Flood Detected')
      .setDescription(
        `**${message.author.tag}** is flooding messages (${data.msgs.length} in 5s).\n\n` +
        `**Action:** \`${action}\``,
      )
      .addFields(
        { name: '👤 User', value: `${message.author} (\`${message.author.id}\`)`, inline: true },
        { name: '📍 Channel', value: `${message.channel}`, inline: true },
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(message.guild, embed);
    await punishUser(message.guild, message.author.id, action, 'Krazod Hub Security: Message flood');
  }
}

// ─── Mass mention detection ────────────────────────────────────────────────────
async function handleMentionSpam(message) {
  const cfg = getGuildConfig(message.guild.id);
  if (!cfg.enabled || cfg.antiMentionSpam === false) return;

  const threshold = cfg.mentionThreshold ?? 5;
  const total = message.mentions.users.size + message.mentions.roles.size;

  if (total >= threshold && !message.mentions.everyone) {
    if (isWhitelisted(message.guild.id, message.author.id, [...(message.member?.roles.cache.keys() ?? [])])) return;

    await message.delete().catch(() => {});

    const embed = new EmbedBuilder()
      .setColor(COLORS.error)
      .setTitle('🔔 Mass Mention Attack Detected')
      .setDescription(
        `**${message.author.tag}** mentioned **${total}** users/roles in a single message.\n\n` +
        `Message has been deleted.`,
      )
      .addFields(
        { name: '👤 User', value: `${message.author} (\`${message.author.id}\`)`, inline: true },
        { name: '📍 Channel', value: `${message.channel}`, inline: true },
        { name: '🔔 Mentions', value: `${total}`, inline: true },
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(message.guild, embed);
    await punishUser(message.guild, message.author.id, 'timeout', 'Krazod Hub Security: Mass mention spam');

    const notice = await message.channel.send({
      content: `${message.author}, mass mentioning is not allowed in this server.`,
    }).catch(() => null);
    if (notice) setTimeout(() => notice.delete().catch(() => {}), 8000);
  }

  // Everyone/here ping detection
  if (message.mentions.everyone && !message.member?.permissions.has(PermissionFlagsBits.MentionEveryone)) {
    await message.delete().catch(() => {});
    const embed = new EmbedBuilder()
      .setColor(COLORS.error)
      .setTitle('🔔 Unauthorized @everyone Ping')
      .setDescription(`**${message.author.tag}** attempted to ping @everyone/@here without permission.`)
      .addFields(
        { name: '👤 User', value: `${message.author} (\`${message.author.id}\`)`, inline: true },
        { name: '📍 Channel', value: `${message.channel}`, inline: true },
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();
    await sendSecurityAlert(message.guild, embed);
    await punishUser(message.guild, message.author.id, 'timeout', 'Krazod Hub Security: Unauthorized @everyone ping');
  }
}

// ─── Anti-raid / Alt detection ────────────────────────────────────────────────
async function handleMemberJoin(member) {
  const guildId = member.guild.id;
  const cfg     = getGuildConfig(guildId);
  if (!cfg.enabled) return;

  const now       = Date.now();
  const windowMs  = cfg.raidWindowMs ?? 30_000;
  const threshold = cfg.thresholds?.antiRaidJoins ?? 7;
  const minAge    = (cfg.thresholds?.minAccountAgeDays ?? 7) * 86400000;

  // ── Bot join monitoring ───────────────────────────────────────────────────
  if (member.user.bot && cfg.logBotJoins !== false) {
    let executor = null;
    try {
      const logs  = await member.guild.fetchAuditLogs({ type: AuditLogEvent.BotAdd, limit: 1 });
      const entry = logs.entries.first();
      if (entry && Date.now() - entry.createdTimestamp < 10000 && entry.target?.id === member.id) {
        executor = entry.executor;
      }
    } catch { /* no audit */ }

    const embed = new EmbedBuilder()
      .setColor(COLORS.warning)
      .setTitle('🤖 New Bot Added to Server')
      .setDescription(`A new bot has been added to the server.`)
      .addFields(
        { name: '🤖 Bot', value: `${member} (\`${member.id}\`)`, inline: true },
        { name: '📋 Bot Name', value: member.user.tag, inline: true },
        { name: '👤 Added By', value: executor ? `${executor} (\`${executor.id}\`)` : '_Could not determine_', inline: true },
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();
    await sendSecurityAlert(member.guild, embed);
    return; // don't apply raid/alt checks to bots
  }

  // ── Alt account detection ─────────────────────────────────────────────────
  const accountAge = now - member.user.createdTimestamp;
  if (accountAge < minAge) {
    const ageDays = Math.floor(accountAge / 86400000);
    const altAction = cfg.altAction ?? 'kick';

    const embed = new EmbedBuilder()
      .setColor(COLORS.warning)
      .setTitle('👤 New / Suspicious Account Detected')
      .setDescription(
        `**${member.user.tag}** joined with an account only **${ageDays}d** old ` +
        `(minimum: **${Math.floor(minAge / 86400000)}d**).\n\n` +
        `**Action:** \`${altAction}\``,
      )
      .addFields(
        { name: '👤 User', value: `${member} (\`${member.id}\`)`, inline: true },
        { name: '📅 Account Age', value: `${ageDays} day${ageDays !== 1 ? 's' : ''}`, inline: true },
        { name: '🏷️ Username', value: member.user.tag, inline: true },
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(member.guild, embed);

    if (altAction !== 'log') {
      await punishUser(member.guild, member.id, altAction, `Krazod Hub Security: Account too new (${ageDays}d old)`);
    }
    return;
  }

  // ── Raid detection ────────────────────────────────────────────────────────
  if (!raidState.has(guildId)) raidState.set(guildId, { joins: [], active: false, activatedAt: null });
  const state = raidState.get(guildId);

  state.joins = state.joins.filter(j => now - j.ts <= windowMs);
  state.joins.push({ userId: member.id, ts: now });

  if (state.joins.length >= threshold && !state.active) {
    state.active      = true;
    state.activatedAt = now;

    logger.warn(`[SECURITY] Raid detected in ${guildId}: ${state.joins.length} joins in ${windowMs / 1000}s`);

    const action = cfg.raidAction ?? 'kick';

    const embed = new EmbedBuilder()
      .setColor(COLORS.error)
      .setTitle('🚨 Raid Detected')
      .setDescription(
        `**${state.joins.length}** members joined in the last **${windowMs / 1000}s**.\n\n` +
        `**Response:** \`${action}\``,
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(member.guild, embed);

    for (const join of [...state.joins]) {
      const m = member.guild.members.cache.get(join.userId);
      if (!m) continue;
      if (isWhitelisted(guildId, m.id, [...m.roles.cache.keys()])) continue;
      if (m.id === member.guild.client.user.id) continue;

      if (action === 'kick') {
        m.kick('Krazod Hub Anti-Raid').catch(() => {});
      } else if (action === 'ban') {
        member.guild.members.ban(m.id, { reason: 'Krazod Hub Anti-Raid' }).catch(() => {});
      } else if (action === 'lockdown') {
        await activateLockdown(member.guild, 'Anti-Raid: Raid detected', member.guild.client.user.id);
        break;
      }
    }

    // Auto-deactivate raid mode after 2× the window
    setTimeout(() => {
      const s = raidState.get(guildId);
      if (s) { s.active = false; s.joins = []; }
    }, windowMs * 2);
  }
}

// ─── Nuke event handler (channel/role delete/create, ban, kick, etc.) ─────────
async function handleNukeAction(guild, userId, actionType, targetId = null) {
  const cfg = getGuildConfig(guild.id);
  if (!cfg.enabled) return;

  const memberRoleIds = guild.members.cache.get(userId)?.roles.cache.keys()
    ? [...guild.members.cache.get(userId).roles.cache.keys()]
    : [];

  if (isWhitelisted(guild.id, userId, memberRoleIds)) return;

  const windowMs  = cfg.windowMs ?? 10_000;
  const threshold = cfg.thresholds?.[actionType];
  if (!threshold) return;

  const count = recordAction(guild.id, userId, actionType, windowMs);
  if (count < threshold) return;

  clearActionCounter(guild.id, userId, actionType);

  logger.warn(`[SECURITY] Nuke detected in ${guild.id} — ${actionType} x${count} by ${userId}`);

  const action = cfg.nukeAction ?? 'stripRoles';

  const embed = new EmbedBuilder()
    .setColor(COLORS.error)
    .setTitle('🚨 Nuke Attempt Detected')
    .setDescription(
      `**${actionType}** threshold exceeded (**${count}** in ${windowMs / 1000}s).\n\n` +
      `**Suspect:** <@${userId}> (\`${userId}\`)\n` +
      `**Response:** \`${action}\``,
    )
    .setFooter({ text: 'Krazod Hub Security' })
    .setTimestamp();

  await sendSecurityAlert(guild, embed);
  await punishUser(guild, userId, action, `Krazod Hub Security: Nuke attempt (${actionType})`);
}

// ─── Role permission change monitoring ────────────────────────────────────────
async function handleRoleUpdate(oldRole, newRole) {
  const cfg = getGuildConfig(newRole.guild.id);
  if (!cfg.enabled) return;

  const oldAdmin = oldRole.permissions.has(PermissionFlagsBits.Administrator);
  const newAdmin = newRole.permissions.has(PermissionFlagsBits.Administrator);

  // Administrator was granted to a role
  if (!oldAdmin && newAdmin) {
    const executor = await getAuditExecutor(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id, 5000);
    if (!executor) return;

    const memberRoleIds = newRole.guild.members.cache.get(executor.id)?.roles.cache.keys()
      ? [...newRole.guild.members.cache.get(executor.id).roles.cache.keys()]
      : [];

    if (isWhitelisted(newRole.guild.id, executor.id, memberRoleIds)) return;

    logger.warn(`[SECURITY] Administrator granted to role ${newRole.name} by ${executor.id} in ${newRole.guild.id}`);

    const count = recordAction(newRole.guild.id, executor.id, 'massPermChange', cfg.windowMs ?? 10_000);

    const embed = new EmbedBuilder()
      .setColor(COLORS.error)
      .setTitle('⚠️ Unauthorized Administrator Permission Granted')
      .setDescription(
        `**${executor.tag}** granted the **Administrator** permission to role **${newRole.name}**.\n\n` +
        `This is a critical security event. Investigate immediately.`,
      )
      .addFields(
        { name: '👤 Executor', value: `${executor} (\`${executor.id}\`)`, inline: true },
        { name: '🎭 Role', value: `${newRole} (\`${newRole.name}\`)`, inline: true },
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(newRole.guild, embed);

    if (count >= (cfg.thresholds?.massPermChange ?? 3)) {
      await punishUser(newRole.guild, executor.id, cfg.nukeAction ?? 'stripRoles',
        'Krazod Hub Security: Mass dangerous permission changes');
    }
  }
}

// ─── Member role update monitoring ────────────────────────────────────────────
async function handleMemberRoleUpdate(oldMember, newMember) {
  const cfg = getGuildConfig(newMember.guild.id);
  if (!cfg.enabled) return;

  const addedRoles = [...newMember.roles.cache.values()].filter(
    r => !oldMember.roles.cache.has(r.id) && r.id !== newMember.guild.id,
  );

  const hasDangerousNew = addedRoles.some(r =>
    DANGEROUS_PERMS.some(p => r.permissions.has(p)),
  );

  if (!hasDangerousNew) return;

  const executor = await getAuditExecutor(newMember.guild, AuditLogEvent.MemberRoleUpdate, newMember.id, 5000);
  if (!executor || executor.id === newMember.guild.client.user.id) return;

  const memberRoleIds = newMember.guild.members.cache.get(executor.id)?.roles.cache.keys()
    ? [...newMember.guild.members.cache.get(executor.id).roles.cache.keys()]
    : [];

  if (isWhitelisted(newMember.guild.id, executor.id, memberRoleIds)) return;

  const dangerousRoleNames = addedRoles
    .filter(r => DANGEROUS_PERMS.some(p => r.permissions.has(p)))
    .map(r => `\`${r.name}\``)
    .join(', ');

  const count = recordAction(newMember.guild.id, executor.id, 'massPermChange', cfg.windowMs ?? 10_000);

  const embed = new EmbedBuilder()
    .setColor(COLORS.warning)
    .setTitle('⚠️ Dangerous Role Assignment Detected')
    .setDescription(
      `**${executor.tag}** assigned a dangerous role to **${newMember.user.tag}**.`,
    )
    .addFields(
      { name: '👤 Target', value: `${newMember} (\`${newMember.id}\`)`, inline: true },
      { name: '🔨 Executor', value: `${executor} (\`${executor.id}\`)`, inline: true },
      { name: '🎭 Dangerous Role(s)', value: dangerousRoleNames || '_Unknown_', inline: false },
    )
    .setFooter({ text: 'Krazod Hub Security' })
    .setTimestamp();

  await sendSecurityAlert(newMember.guild, embed);

  if (count >= (cfg.thresholds?.massPermChange ?? 3)) {
    logger.warn(`[SECURITY] Mass dangerous role assignment in ${newMember.guild.id} by ${executor.id}`);
    await punishUser(newMember.guild, executor.id, cfg.nukeAction ?? 'stripRoles',
      'Krazod Hub Security: Mass dangerous role assignments');
  }
}

// ─── Guild update monitor ──────────────────────────────────────────────────────
async function handleGuildUpdate(oldGuild, newGuild) {
  const cfg = getGuildConfig(newGuild.id);
  if (!cfg.enabled) return;

  // Check if verification level was dramatically lowered
  if (oldGuild.verificationLevel > newGuild.verificationLevel) {
    const executor = await getAuditExecutor(newGuild, AuditLogEvent.GuildUpdate, null, 5000);
    if (!executor) return;

    const memberRoleIds = newGuild.members.cache.get(executor.id)?.roles.cache.keys()
      ? [...newGuild.members.cache.get(executor.id).roles.cache.keys()]
      : [];

    if (isWhitelisted(newGuild.id, executor.id, memberRoleIds)) return;

    const embed = new EmbedBuilder()
      .setColor(COLORS.warning)
      .setTitle('⚠️ Server Verification Level Lowered')
      .setDescription(`The server verification level was lowered by **${executor.tag}**. This may facilitate a raid.`)
      .addFields(
        { name: '🔐 Old Level', value: `${oldGuild.verificationLevel}`, inline: true },
        { name: '🔐 New Level', value: `${newGuild.verificationLevel}`, inline: true },
        { name: '👤 Executor', value: `${executor} (\`${executor.id}\`)`, inline: true },
      )
      .setFooter({ text: 'Krazod Hub Security' })
      .setTimestamp();

    await sendSecurityAlert(newGuild, embed);
  }
}

// ─── initSecurityManager ──────────────────────────────────────────────────────
function initSecurityManager(client) {

  // ── guildBanAdd ───────────────────────────────────────────────────────────
  client.on('guildBanAdd', async (ban) => {
    try {
      const executor = await getAuditExecutor(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
      if (!executor || executor.id === ban.guild.client.user.id) return;
      await handleNukeAction(ban.guild, executor.id, 'massBan', ban.user.id);
    } catch (err) {
      logger.error('[SECURITY] guildBanAdd error:', err.message);
    }
  });

  // ── guildMemberRemove — kick detection ────────────────────────────────────
  client.on('guildMemberRemove', async (member) => {
    try {
      const executor = await getAuditExecutor(member.guild, AuditLogEvent.MemberKick, member.id);
      if (!executor || executor.id === member.guild.client.user.id) return;
      await handleNukeAction(member.guild, executor.id, 'massKick', member.id);
    } catch (err) {
      logger.error('[SECURITY] guildMemberRemove (kick) error:', err.message);
    }
  });

  // ── channelDelete ─────────────────────────────────────────────────────────
  client.on('channelDelete', async (channel) => {
    try {
      if (!channel.guild) return;
      const executor = await getAuditExecutor(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
      if (!executor || executor.id === channel.guild.client.user.id) return;
      await handleNukeAction(channel.guild, executor.id, 'massChannelDelete', channel.id);
    } catch (err) {
      logger.error('[SECURITY] channelDelete error:', err.message);
    }
  });

  // ── channelCreate ─────────────────────────────────────────────────────────
  client.on('channelCreate', async (channel) => {
    try {
      if (!channel.guild) return;
      const executor = await getAuditExecutor(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
      if (!executor || executor.id === channel.guild.client.user.id) return;
      await handleNukeAction(channel.guild, executor.id, 'massChannelCreate', channel.id);
    } catch (err) {
      logger.error('[SECURITY] channelCreate error:', err.message);
    }
  });

  // ── roleDelete ────────────────────────────────────────────────────────────
  client.on('roleDelete', async (role) => {
    try {
      const executor = await getAuditExecutor(role.guild, AuditLogEvent.RoleDelete, role.id);
      if (!executor || executor.id === role.guild.client.user.id) return;
      await handleNukeAction(role.guild, executor.id, 'massRoleDelete', role.id);
    } catch (err) {
      logger.error('[SECURITY] roleDelete error:', err.message);
    }
  });

  // ── roleCreate ────────────────────────────────────────────────────────────
  client.on('roleCreate', async (role) => {
    try {
      // Skip managed roles — these are integration roles created automatically by Discord
      // (e.g. the bot's own integration role when it joins a server). They are not user actions.
      if (role.managed) return;
      const executor = await getAuditExecutor(role.guild, AuditLogEvent.RoleCreate, role.id);
      if (!executor || executor.id === role.guild.client.user.id) return;
      await handleNukeAction(role.guild, executor.id, 'massRoleCreate', role.id);
    } catch (err) {
      logger.error('[SECURITY] roleCreate error:', err.message);
    }
  });

  // ── webhookCreate / webhookUpdate ─────────────────────────────────────────
  client.on('webhookUpdate', async (channel) => {
    try {
      if (!channel.guild) return;
      // Fetch recent audit entries to see if it was a creation or deletion
      try {
        const logs = await channel.guild.fetchAuditLogs({ type: AuditLogEvent.WebhookCreate, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000) {
          if (entry.executor?.id !== channel.guild.client.user.id) {
            await handleNukeAction(channel.guild, entry.executor.id, 'massWebhookCreate');
          }
        }
      } catch { /* no audit */ }

      try {
        const logs = await channel.guild.fetchAuditLogs({ type: AuditLogEvent.WebhookDelete, limit: 1 });
        const entry = logs.entries.first();
        if (entry && Date.now() - entry.createdTimestamp < 5000) {
          if (entry.executor?.id !== channel.guild.client.user.id) {
            await handleNukeAction(channel.guild, entry.executor.id, 'massWebhookDelete');
          }
        }
      } catch { /* no audit */ }
    } catch (err) {
      logger.error('[SECURITY] webhookUpdate error:', err.message);
    }
  });

  // ── guildMemberAdd — raid + alt detection + bot join monitoring ───────────
  client.on('guildMemberAdd', async (member) => {
    try {
      await handleMemberJoin(member);
    } catch (err) {
      logger.error('[SECURITY] guildMemberAdd error:', err.message);
    }
  });

  // ── roleUpdate — dangerous permission changes ─────────────────────────────
  client.on('roleUpdate', async (oldRole, newRole) => {
    try {
      await handleRoleUpdate(oldRole, newRole);
    } catch (err) {
      logger.error('[SECURITY] roleUpdate error:', err.message);
    }
  });

  // ── guildMemberUpdate — dangerous role assignment detection ───────────────
  client.on('guildMemberUpdate', async (oldMember, newMember) => {
    try {
      await handleMemberRoleUpdate(oldMember, newMember);
    } catch (err) {
      logger.error('[SECURITY] guildMemberUpdate error:', err.message);
    }
  });

  // ── guildUpdate — server settings monitor ────────────────────────────────
  client.on('guildUpdate', async (oldGuild, newGuild) => {
    try {
      await handleGuildUpdate(oldGuild, newGuild);
    } catch (err) {
      logger.error('[SECURITY] guildUpdate error:', err.message);
    }
  });

  // ── messageCreate — anti-phishing, flood, mention spam ───────────────────
  client.on('messageCreate', async (message) => {
    try {
      if (!message.guild || message.author?.bot) return;
      await handleAntiPhishing(message);
      await handleFloodDetection(message);
      await handleMentionSpam(message);
    } catch (err) {
      logger.error('[SECURITY] messageCreate error:', err.message);
    }
  });

  logger.info('[SECURITY] Security manager initialized.');
}

// ─── Legacy backward-compat wrappers ─────────────────────────────────────────
async function checkMassBan()           {}
async function checkMassChannelDelete() {}
async function checkMassRoleDelete()    {}

module.exports = {
  initSecurityManager,
  isWhitelisted,
  activateLockdown,
  deactivateLockdown,
  getLockdownState,
  sendSecurityAlert,
  // Legacy compat
  checkMassBan,
  checkMassChannelDelete,
  checkMassRoleDelete,
};
