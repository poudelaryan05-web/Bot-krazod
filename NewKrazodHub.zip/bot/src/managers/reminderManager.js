const { getDB } = require('../database/db');
const logger = require('../utils/logger');

async function startReminderScheduler(client) {
  setInterval(() => checkReminders(client), 30_000);
  logger.info('Reminder scheduler started.');
}

async function checkReminders(client) {
  const db = getDB();
  const now = Date.now();
  const due = db.prepare('SELECT * FROM reminders WHERE remind_at <= ?').all(now);

  for (const reminder of due) {
    try {
      const channel = client.channels.cache.get(reminder.channel_id);
      if (channel) {
        await channel.send({
          content: `<@${reminder.user_id}> — Reminder: **${reminder.message}**`,
          allowedMentions: { users: [reminder.user_id] },
        });
      } else {
        // Try DM
        const user = await client.users.fetch(reminder.user_id).catch(() => null);
        if (user) await user.send(`Reminder: **${reminder.message}**`).catch(() => {});
      }
    } catch (err) {
      // Silent
    }
    db.prepare('DELETE FROM reminders WHERE id = ?').run(reminder.id);
  }
}

module.exports = { startReminderScheduler };
