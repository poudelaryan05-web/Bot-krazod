const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { requirePermissions } = require('../../utils/permissions');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { getDB } = require('../../database/db');
const { logEvent } = require('../../managers/loggingManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the warning').setRequired(true)),

  async execute(interaction) {
    if (!await requirePermissions(interaction, [PermissionFlagsBits.ModerateMembers])) return;

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    getDB().prepare('INSERT INTO warnings (guild_id, user_id, moderator_id, reason, timestamp) VALUES (?, ?, ?, ?, ?)')
      .run(interaction.guild.id, target.id, interaction.user.id, reason, Date.now());

    const count = getDB().prepare('SELECT COUNT(*) as c FROM warnings WHERE guild_id = ? AND user_id = ?').get(interaction.guild.id, target.id).c;

    await interaction.reply({
      embeds: [successEmbed(`**${target.tag}** has been warned.\n**Reason:** ${reason}\n**Total warnings:** ${count}`)],
    });

    await logEvent(interaction.guild, 'warn', {
      user: target,
      description: `<@${target.id}> was warned by <@${interaction.user.id}>`,
      fields: [{ name: 'Reason', value: reason, inline: true }, { name: 'Total Warnings', value: String(count), inline: true }],
    });
  },
};
