const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { requirePermissions, checkHierarchy } = require('../../utils/permissions');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { logEvent } = require('../../managers/loggingManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction) {
    if (!await requirePermissions(interaction, [PermissionFlagsBits.KickMembers])) return;

    const target = interaction.options.getMember('user');
    if (!target) return interaction.reply({ embeds: [errorEmbed('User not found in this server.')], flags: 1 << 6 });
    if (!await checkHierarchy(interaction, target)) return;

    const reason = interaction.options.getString('reason') ?? 'No reason provided';

    try {
      await target.kick(reason);
      await interaction.reply({ embeds: [successEmbed(`**${target.user.tag}** has been kicked.\n**Reason:** ${reason}`)] });
      await logEvent(interaction.guild, 'kick', {
        user: target.user,
        description: `<@${target.id}> was kicked by <@${interaction.user.id}>`,
        fields: [{ name: 'Reason', value: reason, inline: true }],
      });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`Failed to kick: ${err.message}`)], flags: 1 << 6 });
    }
  },
};
