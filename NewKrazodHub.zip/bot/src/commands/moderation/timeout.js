const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { requirePermissions, checkHierarchy } = require('../../utils/permissions');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { logEvent } = require('../../managers/loggingManager');
const ms = require('ms');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to timeout').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 10m, 1h, 1d)').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction) {
    if (!await requirePermissions(interaction, [PermissionFlagsBits.ModerateMembers])) return;

    const target = interaction.options.getMember('user');
    if (!target) return interaction.reply({ embeds: [errorEmbed('User not found.')], flags: 1 << 6 });
    if (!await checkHierarchy(interaction, target)) return;

    const durationStr = interaction.options.getString('duration');
    const duration = ms(durationStr);
    const reason = interaction.options.getString('reason') ?? 'No reason provided';

    if (!duration || duration < 5_000 || duration > 28 * 24 * 60 * 60 * 1000) {
      return interaction.reply({ embeds: [errorEmbed('Invalid duration. Use formats like `10m`, `1h`, `1d` (max 28 days).')], flags: 1 << 6 });
    }

    try {
      await target.timeout(duration, reason);
      await interaction.reply({ embeds: [successEmbed(`**${target.user.tag}** has been timed out for **${durationStr}**.\n**Reason:** ${reason}`)] });
      await logEvent(interaction.guild, 'timeout', {
        user: target.user,
        description: `<@${target.id}> was timed out by <@${interaction.user.id}>`,
        fields: [
          { name: 'Duration', value: durationStr, inline: true },
          { name: 'Reason', value: reason, inline: true },
        ],
      });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`Failed to timeout: ${err.message}`)], flags: 1 << 6 });
    }
  },
};
