const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { requirePermissions } = require('../../utils/permissions');
const { errorEmbed, COLORS } = require('../../utils/embeds');
const { getDB } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View warnings for a user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(true))
    .addBooleanOption(o => o.setName('clear').setDescription('Clear all warnings for this user').setRequired(false)),

  async execute(interaction) {
    if (!await requirePermissions(interaction, [PermissionFlagsBits.ModerateMembers])) return;

    const target = interaction.options.getUser('user');
    const shouldClear = interaction.options.getBoolean('clear') ?? false;

    if (shouldClear) {
      getDB().prepare('DELETE FROM warnings WHERE guild_id = ? AND user_id = ?').run(interaction.guild.id, target.id);
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.success).setDescription(`All warnings cleared for **${target.tag}**.`).setTimestamp()] });
    }

    const warns = getDB().prepare('SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY timestamp DESC LIMIT 10').all(interaction.guild.id, target.id);

    if (warns.length === 0) {
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.muted).setDescription(`**${target.tag}** has no warnings.`).setTimestamp()], flags: 1 << 6 });
    }

    const embed = new EmbedBuilder()
      .setColor(COLORS.warning)
      .setTitle(`Warnings — ${target.tag}`)
      .setDescription(warns.map((w, i) => `**${i + 1}.** ${w.reason} — <t:${Math.floor(w.timestamp / 1000)}:R> by <@${w.moderator_id}>`).join('\n'))
      .setFooter({ text: `${warns.length} warning(s) shown • Krazod Hub` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
