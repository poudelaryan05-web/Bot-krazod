const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { requirePermissions, checkHierarchy } = require('../../utils/permissions');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { logEvent } = require('../../managers/loggingManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the ban').setRequired(false))
    .addIntegerOption(o => o.setName('delete_days').setDescription('Days of messages to delete (0–7)').setMinValue(0).setMaxValue(7).setRequired(false)),

  async execute(interaction) {
    if (!await requirePermissions(interaction, [PermissionFlagsBits.BanMembers])) return;

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') ?? 'No reason provided';
    const deleteDays = interaction.options.getInteger('delete_days') ?? 0;

    const member = interaction.guild.members.cache.get(target.id);
    if (member && !await checkHierarchy(interaction, member)) return;

    try {
      await interaction.guild.members.ban(target.id, { reason, deleteMessageDays: deleteDays });
      await interaction.reply({ embeds: [successEmbed(`**${target.tag}** has been banned.\n**Reason:** ${reason}`)] });
      await logEvent(interaction.guild, 'ban', {
        user: target,
        description: `<@${target.id}> was banned by <@${interaction.user.id}>`,
        fields: [{ name: 'Reason', value: reason, inline: true }],
      });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`Failed to ban: ${err.message}`)], flags: 1 << 6 });
    }
  },
};
