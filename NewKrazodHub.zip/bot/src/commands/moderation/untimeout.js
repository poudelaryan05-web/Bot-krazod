const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { requirePermissions, checkHierarchy } = require('../../utils/permissions');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Remove timeout from a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to untimeout').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction) {
    if (!await requirePermissions(interaction, [PermissionFlagsBits.ModerateMembers])) return;

    const target = interaction.options.getMember('user');
    if (!target) return interaction.reply({ embeds: [errorEmbed('User not found.')], flags: 1 << 6 });
    if (!target.isCommunicationDisabled()) {
      return interaction.reply({ embeds: [errorEmbed('This member is not currently timed out.')], flags: 1 << 6 });
    }

    const reason = interaction.options.getString('reason') ?? 'No reason provided';
    try {
      await target.timeout(null, reason);
      await interaction.reply({ embeds: [successEmbed(`Timeout removed from **${target.user.tag}**.`)] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`Failed: ${err.message}`)], flags: 1 << 6 });
    }
  },
};
