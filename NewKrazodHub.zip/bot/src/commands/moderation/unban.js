const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { requirePermissions } = require('../../utils/permissions');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { logEvent } = require('../../managers/loggingManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption(o => o.setName('user_id').setDescription('User ID to unban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction) {
    if (!await requirePermissions(interaction, [PermissionFlagsBits.BanMembers])) return;

    const userId = interaction.options.getString('user_id');
    const reason = interaction.options.getString('reason') ?? 'No reason provided';

    try {
      const ban = await interaction.guild.bans.fetch(userId).catch(() => null);
      if (!ban) return interaction.reply({ embeds: [errorEmbed('This user is not banned.')], flags: 1 << 6 });

      await interaction.guild.members.unban(userId, reason);
      await interaction.reply({ embeds: [successEmbed(`**${ban.user.tag}** has been unbanned.\n**Reason:** ${reason}`)] });
      await logEvent(interaction.guild, 'unban', {
        user: ban.user,
        description: `<@${userId}> was unbanned by <@${interaction.user.id}>`,
        fields: [{ name: 'Reason', value: reason, inline: true }],
      });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`Failed to unban: ${err.message}`)], flags: 1 << 6 });
    }
  },
};
