'use strict';
const { SlashCommandBuilder } = require('discord.js');
const {
  joinVoiceChannel,
  getVoiceConnection,
  VoiceConnectionStatus,
} = require('@discordjs/voice');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const logger = require('../../utils/logger');

// Per-guild 24/7 state
const mode247 = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('247')
    .setDescription('Toggle 24/7 mode — keep the bot in your voice channel permanently'),

  async execute(interaction) {
    const voiceChannel = interaction.member?.voice?.channel;
    if (!voiceChannel) {
      return interaction.reply({
        embeds: [errorEmbed('You must be in a voice channel to use this command.')],
        flags: 1 << 6,
      });
    }

    const guildId = interaction.guild.id;
    const current = mode247.get(guildId) ?? false;
    const enabling = !current;
    mode247.set(guildId, enabling);

    if (enabling) {
      // Join the voice channel and hold the connection
      try {
        const existing = getVoiceConnection(guildId);
        if (!existing || existing.state.status === VoiceConnectionStatus.Destroyed) {
          const connection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId,
            adapterCreator: interaction.guild.voiceAdapterCreator,
            selfDeaf: true,
            selfMute: true,
          });

          // Prevent the connection from auto-disconnecting on idle
          connection.on(VoiceConnectionStatus.Disconnected, async () => {
            if (!mode247.get(guildId)) return; // 24/7 was disabled
            logger.info(`[247] Reconnecting in guild ${guildId}...`);
            try {
              await Promise.race([
                connection.rejoin(),
                new Promise((_, reject) => setTimeout(() => reject(new Error('Rejoin timeout')), 5000)),
              ]);
            } catch {
              // If rejoin fails, try a fresh join
              try {
                joinVoiceChannel({
                  channelId: voiceChannel.id,
                  guildId,
                  adapterCreator: interaction.guild.voiceAdapterCreator,
                  selfDeaf: true,
                  selfMute: true,
                });
              } catch (err) {
                logger.error(`[247] Could not reconnect in guild ${guildId}:`, err.message);
              }
            }
          });

          logger.info(`[247] Joined voice channel "${voiceChannel.name}" in guild ${guildId}`);
        }
      } catch (err) {
        mode247.set(guildId, false);
        return interaction.reply({
          embeds: [errorEmbed(`Could not join voice channel: ${err.message}`)],
          flags: 1 << 6,
        });
      }

      return interaction.reply({
        embeds: [successEmbed(`24/7 mode **enabled**. I will stay in **${voiceChannel.name}** and reconnect automatically.`)],
      });
    } else {
      // Disable — disconnect
      try {
        const connection = getVoiceConnection(guildId);
        if (connection) {
          connection.destroy();
          logger.info(`[247] Left voice channel in guild ${guildId}`);
        }
      } catch (err) {
        logger.warn(`[247] Error leaving voice channel in guild ${guildId}:`, err.message);
      }

      return interaction.reply({
        embeds: [infoEmbed('24/7 mode **disabled**. I have left the voice channel.')],
      });
    }
  },
};

module.exports.is247     = (guildId) => mode247.get(guildId) ?? false;
module.exports.mode247Map = mode247;
