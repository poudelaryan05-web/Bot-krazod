const {
  SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { getConfig, setConfig, deleteConfig } = require('../../database/db');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');

// ─── Bot owner ────────────────────────────────────────────────────────────────
const BOT_OWNER_ID = '1477244673595805726';

// Global config key — feedback channel is a bot-owner setting, not per-guild
const GLOBAL_KEY = 'GLOBAL';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('feedback')
    .setDescription('Feedback system')
    .addSubcommand(s => s
      .setName('setup')
      .setDescription('(Bot owner only) Set up the global feedback channel')
    )
    .addSubcommand(s => s
      .setName('submit')
      .setDescription('Submit feedback')
    )
    .addSubcommand(s => s
      .setName('disable')
      .setDescription('(Bot owner only) Disable the feedback system')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    // ── disable (bot owner only) ─────────────────────────────────────────────
    if (sub === 'disable') {
      if (interaction.user.id !== BOT_OWNER_ID) {
        return interaction.reply({
          embeds: [errorEmbed('Only the **bot owner** can disable the feedback system.')],
          flags: 1 << 6,
        });
      }
      deleteConfig(GLOBAL_KEY, 'feedback');
      return interaction.reply({ embeds: [successEmbed('Feedback system disabled.')], flags: 1 << 6 });
    }

    // ── setup (bot owner only) ───────────────────────────────────────────────
    if (sub === 'setup') {
      if (interaction.user.id !== BOT_OWNER_ID) {
        return interaction.reply({
          embeds: [errorEmbed('Only the **bot owner** can configure the feedback channel.')],
          flags: 1 << 6,
        });
      }

      const current = getConfig(GLOBAL_KEY, 'feedback') ?? {};
      const embed = infoEmbed(
        `**Feedback System Setup** *(Bot Owner Only)*\n\n` +
        `Configure where member feedback and bot removal feedback are sent.\n\n` +
        `**Current Settings:**\n` +
        `Feedback Channel: ${current.channelId ? `<#${current.channelId}>` : 'Not set'}`,
        'Feedback Setup',
      );
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('setup:feedback:channel').setLabel('Set Channel').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('setup:feedback:save').setLabel('Save').setStyle(ButtonStyle.Success),
      );
      return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
    }

    // ── submit ───────────────────────────────────────────────────────────────
    if (sub === 'submit') {
      const config = getConfig(GLOBAL_KEY, 'feedback');
      if (!config?.enabled) {
        return interaction.reply({
          embeds: [errorEmbed('The feedback system is not set up yet. Please ask the bot owner to configure it first.')],
          flags: 1 << 6,
        });
      }

      const modal = new ModalBuilder()
        .setCustomId('feedback:submit')
        .setTitle('Submit Feedback');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('rating')
            .setLabel('Rating (1–5 stars)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Enter a number from 1 to 5')
            .setRequired(true)
            .setMaxLength(1),
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('message')
            .setLabel('Your Feedback')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Tell us what you think...')
            .setRequired(true)
            .setMaxLength(1000),
        ),
      );

      await interaction.showModal(modal);
    }
  },
};
