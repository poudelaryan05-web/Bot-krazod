'use strict';
const {
  SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
} = require('discord.js');
const { getConfig, setConfig, deleteConfig } = require('../../database/db');
const { successEmbed, errorEmbed, COLORS } = require('../../utils/embeds');
const {
  activateLockdown, deactivateLockdown, getLockdownState,
} = require('../../managers/securityManager');

const THRESHOLD_LABELS = {
  massBan:            'Mass Ban',
  massKick:           'Mass Kick',
  massChannelDelete:  'Mass Channel Delete',
  massChannelCreate:  'Mass Channel Create',
  massRoleDelete:     'Mass Role Delete',
  massRoleCreate:     'Mass Role Create',
  massWebhookDelete:  'Mass Webhook Delete',
  massWebhookCreate:  'Mass Webhook Create',
  massEmojiDelete:    'Mass Emoji Delete',
  massPermChange:     'Mass Permission Change',
  antiRaidJoins:      'Anti-Raid Join Count',
  minAccountAgeDays:  'Min Account Age (days)',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('security')
    .setDescription('Advanced anti-nuke, anti-raid, and server security system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    .addSubcommand(s => s
      .setName('setup')
      .setDescription('Configure the security system'))

    .addSubcommand(s => s
      .setName('disable')
      .setDescription('Disable all security protections'))

    .addSubcommand(s => s
      .setName('status')
      .setDescription('View current security configuration and state'))

    .addSubcommand(s => s
      .setName('lockdown')
      .setDescription('Manually lock all server channels')
      .addStringOption(o => o
        .setName('reason')
        .setDescription('Reason for lockdown')
        .setRequired(false)))

    .addSubcommand(s => s
      .setName('unlock')
      .setDescription('Remove server lockdown and restore channel permissions'))

    .addSubcommand(s => s
      .setName('whitelist')
      .setDescription('Manage permanently whitelisted users (bypass all security checks)')
      .addStringOption(o => o
        .setName('action')
        .setDescription('Action to perform')
        .setRequired(true)
        .addChoices(
          { name: 'add',    value: 'add'    },
          { name: 'remove', value: 'remove' },
          { name: 'list',   value: 'list'   },
        ))
      .addUserOption(o => o
        .setName('user')
        .setDescription('User to add or remove')
        .setRequired(false)))

    .addSubcommand(s => s
      .setName('trustedrole')
      .setDescription('Manage trusted roles (members with these roles bypass security checks)')
      .addStringOption(o => o
        .setName('action')
        .setDescription('Action to perform')
        .setRequired(true)
        .addChoices(
          { name: 'add',    value: 'add'    },
          { name: 'remove', value: 'remove' },
          { name: 'list',   value: 'list'   },
        ))
      .addRoleOption(o => o
        .setName('role')
        .setDescription('Role to add or remove')
        .setRequired(false)))

    .addSubcommand(s => s
      .setName('threshold')
      .setDescription('Set a detection threshold')
      .addStringOption(o => o
        .setName('action')
        .setDescription('Action type to configure')
        .setRequired(true)
        .addChoices(
          ...Object.entries(THRESHOLD_LABELS).map(([k, v]) => ({ name: v, value: k })),
        ))
      .addIntegerOption(o => o
        .setName('count')
        .setDescription('Threshold count (1–50)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(50))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    // ── disable ─────────────────────────────────────────────────────────────
    if (sub === 'disable') {
      deleteConfig(interaction.guild.id, 'security');
      return interaction.reply({
        embeds: [successEmbed('Security system has been **disabled**.')],
        flags: 1 << 6,
      });
    }

    const current = getConfig(interaction.guild.id, 'security') ?? {};

    // ── lockdown ─────────────────────────────────────────────────────────────
    if (sub === 'lockdown') {
      const state = getLockdownState(interaction.guild.id);
      if (state.active) {
        return interaction.reply({
          embeds: [errorEmbed('Server is already in lockdown. Use `/security unlock` to remove it.')],
          flags: 1 << 6,
        });
      }
      const reason = interaction.options.getString('reason') ?? 'Manual lockdown by administrator';
      await interaction.deferReply({ flags: 1 << 6 });
      await activateLockdown(interaction.guild, reason, interaction.user.id);
      return interaction.editReply({
        embeds: [successEmbed(`Server locked down. Reason: ${reason}`)],
      });
    }

    // ── unlock ──────────────────────────────────────────────────────────────
    if (sub === 'unlock') {
      const state = getLockdownState(interaction.guild.id);
      if (!state.active) {
        return interaction.reply({
          embeds: [errorEmbed('The server is not currently in lockdown.')],
          flags: 1 << 6,
        });
      }
      await interaction.deferReply({ flags: 1 << 6 });
      await deactivateLockdown(interaction.guild, interaction.user.id);
      return interaction.editReply({
        embeds: [successEmbed('Lockdown removed. Channels restored.')],
      });
    }

    // ── whitelist ────────────────────────────────────────────────────────────
    if (sub === 'whitelist') {
      const action    = interaction.options.getString('action');
      const user      = interaction.options.getUser('user');
      const whitelist = Array.isArray(current.whitelist) ? [...current.whitelist] : [];

      if (action === 'list') {
        const desc = whitelist.length
          ? whitelist.map(id => `<@${id}>`).join('\n')
          : 'No users whitelisted.';
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('Security Whitelist')
            .setDescription(desc)
            .setFooter({ text: 'Krazod Hub Security' })],
          flags: 1 << 6,
        });
      }
      if (!user) {
        return interaction.reply({ embeds: [errorEmbed('Please specify a user.')], flags: 1 << 6 });
      }
      if (action === 'add') {
        if (whitelist.includes(user.id)) {
          return interaction.reply({ embeds: [errorEmbed(`**${user.tag}** is already whitelisted.`)], flags: 1 << 6 });
        }
        whitelist.push(user.id);
        setConfig(interaction.guild.id, 'security', { ...current, whitelist });
        return interaction.reply({
          embeds: [successEmbed(`**${user.tag}** added to the whitelist.`)],
          flags: 1 << 6,
        });
      }
      if (action === 'remove') {
        const idx = whitelist.indexOf(user.id);
        if (idx === -1) {
          return interaction.reply({ embeds: [errorEmbed(`**${user.tag}** is not in the whitelist.`)], flags: 1 << 6 });
        }
        whitelist.splice(idx, 1);
        setConfig(interaction.guild.id, 'security', { ...current, whitelist });
        return interaction.reply({
          embeds: [successEmbed(`**${user.tag}** removed from the whitelist.`)],
          flags: 1 << 6,
        });
      }
    }

    // ── trustedrole ──────────────────────────────────────────────────────────
    if (sub === 'trustedrole') {
      const action       = interaction.options.getString('action');
      const role         = interaction.options.getRole('role');
      const trustedRoles = Array.isArray(current.trustedRoles) ? [...current.trustedRoles] : [];

      if (action === 'list') {
        const desc = trustedRoles.length
          ? trustedRoles.map(id => `<@&${id}>`).join('\n')
          : 'No trusted roles configured.';
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('🛡️ Trusted Roles')
            .setDescription(desc)
            .setFooter({ text: 'Krazod Hub Security' })],
          flags: 1 << 6,
        });
      }
      if (!role) {
        return interaction.reply({ embeds: [errorEmbed('Please specify a role.')], flags: 1 << 6 });
      }
      if (action === 'add') {
        if (trustedRoles.includes(role.id)) {
          return interaction.reply({ embeds: [errorEmbed(`**${role.name}** is already a trusted role.`)], flags: 1 << 6 });
        }
        trustedRoles.push(role.id);
        setConfig(interaction.guild.id, 'security', { ...current, trustedRoles });
        return interaction.reply({
          embeds: [successEmbed(`**${role.name}** added as a trusted role.`)],
          flags: 1 << 6,
        });
      }
      if (action === 'remove') {
        const idx = trustedRoles.indexOf(role.id);
        if (idx === -1) {
          return interaction.reply({ embeds: [errorEmbed(`**${role.name}** is not a trusted role.`)], flags: 1 << 6 });
        }
        trustedRoles.splice(idx, 1);
        setConfig(interaction.guild.id, 'security', { ...current, trustedRoles });
        return interaction.reply({
          embeds: [successEmbed(`**${role.name}** removed from trusted roles.`)],
          flags: 1 << 6,
        });
      }
    }

    // ── threshold ────────────────────────────────────────────────────────────
    if (sub === 'threshold') {
      const actionKey  = interaction.options.getString('action');
      const count      = interaction.options.getInteger('count');
      const thresholds = { ...(current.thresholds ?? {}), [actionKey]: count };
      setConfig(interaction.guild.id, 'security', { ...current, thresholds });
      return interaction.reply({
        embeds: [successEmbed(`**${THRESHOLD_LABELS[actionKey]}** threshold set to **${count}**.`)],
        flags: 1 << 6,
      });
    }

    // ── status ───────────────────────────────────────────────────────────────
    if (sub === 'status') {
      const cfg        = current;
      const enabled    = cfg?.enabled ?? false;
      const lockState  = getLockdownState(interaction.guild.id);
      const thresholds = cfg?.thresholds ?? {};

      const thresholdText = Object.entries(thresholds).length
        ? Object.entries(thresholds)
            .map(([k, v]) => `\`${THRESHOLD_LABELS[k] ?? k}\`: **${v}**`)
            .join('\n')
        : 'Using defaults';

      const embed = new EmbedBuilder()
        .setColor(enabled ? COLORS.success : COLORS.muted)
        .setTitle('Security System Status')
        .addFields(
          { name: 'Status',          value: enabled ? 'Enabled' : 'Disabled',                                                inline: true  },
          { name: 'Security Level',  value: cfg?.level         ?? 'medium',                                                          inline: true  },
          { name: 'Safe Mode',       value: cfg?.safeMode !== false ? 'On' : 'Off',                                            inline: true  },
          { name: 'Lockdown',        value: lockState.active ? `Active <t:${Math.floor((lockState.activatedAt ?? 0) / 1000)}:R>` : 'Inactive', inline: true },
          { name: 'Alert Channel',   value: cfg?.alertChannelId ? `<#${cfg.alertChannelId}>` : 'Not set',                            inline: true  },
          { name: 'Detection Window', value: `${(cfg?.windowMs ?? 10_000) / 1000}s`,                                                 inline: true  },
          { name: 'Nuke Response',   value: cfg?.nukeAction    ?? 'stripRoles',                                                      inline: true  },
          { name: 'Raid Response',   value: cfg?.raidAction    ?? 'kick',                                                            inline: true  },
          { name: 'Phish Response',  value: cfg?.phishingAction ?? 'ban',                                                            inline: true  },
          { name: 'Alt Response',    value: cfg?.altAction     ?? 'kick',                                                            inline: true  },
          { name: 'Trusted Users',   value: String((cfg?.trustedUsers ?? []).length),                                                inline: true  },
          { name: 'Trusted Roles',   value: String((cfg?.trustedRoles ?? []).length),                                                inline: true  },
          { name: 'Whitelisted',     value: String((cfg?.whitelist    ?? []).length),                                                inline: true  },
          { name: 'Thresholds',      value: thresholdText,                                                                           inline: false },
        )
        .setFooter({ text: 'Krazod Hub Security • Use /security setup to configure' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed], flags: 1 << 6 });
    }

    // ── setup ────────────────────────────────────────────────────────────────
    const lockState = getLockdownState(interaction.guild.id);

    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('🛡️ Security System Setup')
      .setDescription(
        `Configure Krazod Hub's advanced protection system.\n\n` +
        `**Status:** ${current?.enabled ? '🟢 Enabled' : '🔴 Disabled'}\n` +
        `**Level:** ${current?.level ?? 'medium'}\n` +
        `**Nuke Response:** ${current?.nukeAction ?? 'stripRoles'}\n` +
        `**Raid Response:** ${current?.raidAction ?? 'kick'}\n` +
        `**Phishing Response:** ${current?.phishingAction ?? 'ban'}\n` +
        `**Alt Response:** ${current?.altAction ?? 'kick'}\n` +
        `**Alert Channel:** ${current?.alertChannelId ? `<#${current.alertChannelId}>` : 'Not set'}\n` +
        `**Safe Mode:** ${current?.safeMode !== false ? 'On' : 'Off'}\n` +
        `**Lockdown:** ${lockState.active ? '🔒 Active' : 'Inactive'}\n\n` +
        `Use the buttons below to configure each setting.\n` +
        `Use \`/security whitelist\`, \`/security trustedrole\`, and \`/security threshold\` for fine-tuning.`,
      )
      .setFooter({ text: 'Krazod Hub Security Setup' });

    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('setup:security:toggle_enable')
        .setLabel(current?.enabled ? '🔴 Disable Security' : '🟢 Enable Security')
        .setStyle(current?.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('setup:security:set_level')
        .setLabel('Security Level')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('setup:security:set_nuke_action')
        .setLabel('Nuke Response')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('setup:security:set_raid_action')
        .setLabel('Raid Response')
        .setStyle(ButtonStyle.Secondary),
    );

    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('setup:security:set_alert_channel')
        .setLabel('Alert Channel')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('setup:security:set_phishing_action')
        .setLabel('Phishing Response')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('setup:security:set_alt_action')
        .setLabel('Alt Response')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('setup:security:set_window')
        .setLabel('Time Window')
        .setStyle(ButtonStyle.Secondary),
    );

    const row3 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('setup:security:toggle_safemode')
        .setLabel(`Safe Mode: ${current?.safeMode !== false ? 'ON ✓' : 'OFF'}`)
        .setStyle(current?.safeMode !== false ? ButtonStyle.Success : ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('setup:security:reset')
        .setLabel('Reset to Defaults')
        .setStyle(ButtonStyle.Danger),
    );

    return interaction.reply({ embeds: [embed], components: [row1, row2, row3], flags: 1 << 6 });
  },
};
