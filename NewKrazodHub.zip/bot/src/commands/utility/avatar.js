const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('avatar').setDescription("Get a user's avatar")
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(false)),
  async execute(interaction) {
    const user = interaction.options.getUser('user') ?? interaction.user;
    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle(`${user.username}'s Avatar`)
      .setImage(user.displayAvatarURL({ size: 4096, extension: 'png' }))
      .addFields({ name: 'Download', value: `[PNG](${user.displayAvatarURL({ size: 4096, extension: 'png' })}) | [WEBP](${user.displayAvatarURL({ size: 4096, extension: 'webp' })})`, inline: true })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
