const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { addReactionRole, removeReactionRole, getAllReactionRoles, getReactionRolesForMessage } = require('../../database/db');
const { successEmbed, errorEmbed, COLORS } = require('../../utils/embeds');

/**
 * Parse a message link or raw ID into { channelId, messageId }.
 * Supports both https://discord.com/channels/GUILD/CHANNEL/MESSAGE and raw IDs.
 */
function parseMessageRef(guildId, input) {
  // Full message link
  const linkMatch = input.match(/discord(?:app)?\.com\/channels\/\d+\/(\d+)\/(\d+)/);
  if (linkMatch) return { channelId: linkMatch[1], messageId: linkMatch[2] };

  // Raw message ID (no channel info — needs channel option)
  if (/^\d{17,20}$/.test(input.trim())) return { channelId: null, messageId: input.trim() };

  return null;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reactionrole')
    .setDescription('Manage reaction roles')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add a reaction role to a message')
        .addStringOption(o =>
          o.setName('message').setDescription('Message link or message ID').setRequired(true)
        )
        .addStringOption(o =>
          o.setName('emoji').setDescription('Emoji for the reaction (e.g. ✅ or custom emoji)').setRequired(true)
        )
        .addRoleOption(o =>
          o.setName('role').setDescription('Role to assign when reacted').setRequired(true)
        )
        .addChannelOption(o =>
          o.setName('channel').setDescription('Channel containing the message (required when using message ID)').setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove a reaction role from a message')
        .addStringOption(o =>
          o.setName('message').setDescription('Message link or message ID').setRequired(true)
        )
        .addStringOption(o =>
          o.setName('emoji').setDescription('Emoji to remove').setRequired(true)
        )
        .addChannelOption(o =>
          o.setName('channel').setDescription('Channel containing the message (required when using message ID)').setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all reaction roles in this server')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const messageInput = interaction.options.getString('message');
      const emojiInput = interaction.options.getString('emoji').trim();
      const role = interaction.options.getRole('role');
      const channelOption = interaction.options.getChannel('channel');

      // Parse message ref
      const ref = parseMessageRef(interaction.guild.id, messageInput);
      if (!ref) {
        return interaction.reply({ embeds: [errorEmbed('Invalid message link or ID. Provide a message link or a valid message ID.')], flags: 1 << 6 });
      }

      // Resolve channel
      const channelId = ref.channelId ?? channelOption?.id;
      if (!channelId) {
        return interaction.reply({
          embeds: [errorEmbed('Could not determine the channel. Please use a message link or provide the `channel` option.')],
          flags: 1 << 6,
        });
      }

      const channel = interaction.guild.channels.cache.get(channelId);
      if (!channel || !channel.isTextBased()) {
        return interaction.reply({ embeds: [errorEmbed('Channel not found or not a text channel.')], flags: 1 << 6 });
      }

      // Verify the message exists
      await interaction.deferReply({ flags: 1 << 6 });
      const msg = await channel.messages.fetch(ref.messageId).catch(() => null);
      if (!msg) {
        return interaction.editReply({ embeds: [errorEmbed('Message not found. Make sure the ID is correct and I can see that channel.')] });
      }

      // Check bot can assign this role
      const botMember = interaction.guild.members.me;
      if (botMember.roles.highest.comparePositionTo(role) <= 0) {
        return interaction.editReply({ embeds: [errorEmbed(`My role must be above **${role.name}** to assign it.`)] });
      }

      // Normalize the emoji (custom emoji stored as <:name:id>)
      const customEmojiMatch = emojiInput.match(/^<a?:[^:]+:(\d+)>$/);
      const emojiKey = customEmojiMatch ? customEmojiMatch[1] : emojiInput;

      // Add the reaction to the message
      await msg.react(emojiInput).catch(() => {});

      // Save to DB
      addReactionRole(interaction.guild.id, channelId, ref.messageId, emojiKey, role.id);

      const embed = new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle('Reaction Role Added')
        .setDescription(
          `Reacting with **${emojiInput}** on [this message](${msg.url}) will assign the **${role.name}** role.\n` +
          `Removing the reaction will remove the role.`
        )
        .setFooter({ text: 'Krazod Hub Reaction Roles' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'remove') {
      const messageInput = interaction.options.getString('message');
      const emojiInput = interaction.options.getString('emoji').trim();
      const channelOption = interaction.options.getChannel('channel');

      const ref = parseMessageRef(interaction.guild.id, messageInput);
      if (!ref) {
        return interaction.reply({ embeds: [errorEmbed('Invalid message link or ID.')], flags: 1 << 6 });
      }

      const channelId = ref.channelId ?? channelOption?.id;

      const customEmojiMatch = emojiInput.match(/^<a?:[^:]+:(\d+)>$/);
      const emojiKey = customEmojiMatch ? customEmojiMatch[1] : emojiInput;

      const result = removeReactionRole(interaction.guild.id, ref.messageId, emojiKey);

      if (result.changes === 0) {
        return interaction.reply({
          embeds: [errorEmbed(`No reaction role found for that emoji on that message.`)],
          flags: 1 << 6,
        });
      }

      // Try to remove the bot's reaction
      if (channelId) {
        const channel = interaction.guild.channels.cache.get(channelId);
        if (channel?.isTextBased()) {
          const msg = await channel.messages.fetch(ref.messageId).catch(() => null);
          if (msg) await msg.reactions.resolve(emojiKey)?.users.remove(interaction.client.user.id).catch(() => {});
        }
      }

      return interaction.reply({
        embeds: [successEmbed(`Removed the reaction role for **${emojiInput}** on that message.`)],
        flags: 1 << 6,
      });
    }

    if (sub === 'list') {
      const all = getAllReactionRoles(interaction.guild.id);

      if (!all.length) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(COLORS.muted)
              .setTitle('Reaction Roles')
              .setDescription('No reaction roles have been configured.\nUse `/reactionrole add` to set one up.')
              .setFooter({ text: 'Krazod Hub Reaction Roles' }),
          ],
          flags: 1 << 6,
        });
      }

      // Group by message
      const grouped = {};
      for (const rr of all) {
        const key = rr.message_id;
        if (!grouped[key]) grouped[key] = { channelId: rr.channel_id, entries: [] };
        grouped[key].entries.push(rr);
      }

      const lines = [];
      for (const [msgId, { channelId, entries }] of Object.entries(grouped)) {
        const channelMention = `<#${channelId}>`;
        const msgLink = `https://discord.com/channels/${interaction.guild.id}/${channelId}/${msgId}`;
        lines.push(`**[Message](${msgLink})** in ${channelMention}`);
        for (const e of entries) {
          const role = interaction.guild.roles.cache.get(e.role_id);
          const roleName = role ? role.toString() : `~~Deleted Role~~`;
          lines.push(`  ${e.emoji} → ${roleName}`);
        }
      }

      const embed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle(`${interaction.guild.name} — Reaction Roles`)
        .setDescription(lines.join('\n'))
        .setFooter({ text: `${all.length} reaction role${all.length !== 1 ? 's' : ''} • Krazod Hub` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed], flags: 1 << 6 });
    }
  },
};
