const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');
const os = require('os');

module.exports = {
  data: new SlashCommandBuilder().setName('botinfo').setDescription('View information about Krazod Hub'),
  async execute(interaction) {
    const client = interaction.client;
    const uptime = process.uptime();
    const h = Math.floor(uptime / 3600), m = Math.floor((uptime % 3600) / 60), s = Math.floor(uptime % 60);
    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('Krazod Hub')
      .setThumbnail(client.user.displayAvatarURL())
      .addFields(
        { name: 'Servers',      value: client.guilds.cache.size.toString(), inline: true },
        { name: 'Users',        value: client.guilds.cache.reduce((a, g) => a + g.memberCount, 0).toString(), inline: true },
        { name: 'Commands',     value: client.commands.size.toString(), inline: true },
        { name: 'Uptime',       value: `${h}h ${m}m ${s}s`, inline: true },
        { name: 'Ping',         value: `${client.ws.ping}ms`, inline: true },
        { name: 'Node.js',      value: process.version, inline: true },
        { name: 'Memory Usage', value: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`, inline: true },
        { name: 'Platform',     value: os.platform(), inline: true },
      )
      .setFooter({ text: 'Krazod Hub' })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
