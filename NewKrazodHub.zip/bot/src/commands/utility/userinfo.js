const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('userinfo').setDescription('View information about a user')
    .addUserOption(o => o.setName('user').setDescription('User to view').setRequired(false)),
  async execute(interaction) {
    const target = interaction.options.getMember('user') ?? interaction.member;
    const user = target.user;
    await user.fetch(true);
    const embed = new EmbedBuilder()
      .setColor(target.displayHexColor || COLORS.primary)
      .setTitle(user.tag)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .setImage(user.bannerURL({ size: 1024 }) ?? null)
      .addFields(
        { name: 'Nickname',        value: target.nickname ?? 'None', inline: true },
        { name: 'Joined Server',   value: `<t:${Math.floor(target.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Roles', value: target.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => r.toString()).join(', ').slice(0, 1024) || 'None', inline: false },
      )
      .setFooter({ text: `ID: ${user.id}` })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
