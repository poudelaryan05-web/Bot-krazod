'use strict';
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { addAutoresponder, removeAutoresponder, getAllAutoresponders, getAutoresponder } = require('../../database/db');
const { successEmbed, errorEmbed, COLORS } = require('../../utils/embeds');

// ── Build the management embed + buttons ──────────────────────────────────────
function buildListEmbed(guildId, guildName) {
  const responders = getAllAutoresponders(guildId);

  let description = 'Autoresponders reply automatically when a message contains a configured trigger word or phrase (case-insensitive).\n\n';

  if (!responders.length) {
    description += '**Configured Autoresponders:** None\n\nUse the buttons below to add your first autoresponder.';
  } else {
    description += `**Configured Autoresponders (${responders.length}):**\n`;
    for (const r of responders) {
      const resp = r.response.length > 80 ? r.response.slice(0, 77) + '…' : r.response;
      description += `• \`${r.trigger}\` → ${resp}\n`;
    }
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle('Autoresponder — Management')
    .setDescription(description)
    .setFooter({ text: `${guildName} • Krazod Hub` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('autoresponder:add')
      .setLabel('Add')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('autoresponder:edit')
      .setLabel('Edit')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(!responders.length),
    new ButtonBuilder()
      .setCustomId('autoresponder:delete')
      .setLabel('Delete')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(!responders.length),
  );

  return { embed, row };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autoresponder')
    .setDescription('Manage automatic replies triggered by specific words or phrases')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const { embed, row } = buildListEmbed(interaction.guild.id, interaction.guild.name);
    return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },

  // ── Exported so index.js can delegate button/modal interactions ──────────────
  async handleInteraction(interaction) {
    const { customId } = interaction;

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ embeds: [errorEmbed('You need the **Manage Server** permission.')], flags: 1 << 6 });
    }

    // ── Add ───────────────────────────────────────────────────────────────────
    if (customId === 'autoresponder:add') {
      const modal = new ModalBuilder()
        .setCustomId('autoresponder:modal:add')
        .setTitle('Add Autoresponder');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('trigger')
            .setLabel('Trigger word or phrase')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('e.g. website')
            .setRequired(true)
            .setMaxLength(100),
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('response')
            .setLabel('Response')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('e.g. https://example.com')
            .setRequired(true)
            .setMaxLength(1000),
        ),
      );

      return interaction.showModal(modal);
    }

    // ── Edit ──────────────────────────────────────────────────────────────────
    if (customId === 'autoresponder:edit') {
      const modal = new ModalBuilder()
        .setCustomId('autoresponder:modal:edit')
        .setTitle('Edit Autoresponder');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('trigger')
            .setLabel('Trigger to edit (exact match)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('e.g. website')
            .setRequired(true)
            .setMaxLength(100),
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('new_response')
            .setLabel('New response')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Enter the new response text')
            .setRequired(true)
            .setMaxLength(1000),
        ),
      );

      return interaction.showModal(modal);
    }

    // ── Delete ────────────────────────────────────────────────────────────────
    if (customId === 'autoresponder:delete') {
      const modal = new ModalBuilder()
        .setCustomId('autoresponder:modal:delete')
        .setTitle('Delete Autoresponder');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('trigger')
            .setLabel('Trigger to delete (exact match)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('e.g. website')
            .setRequired(true)
            .setMaxLength(100),
        ),
      );

      return interaction.showModal(modal);
    }

    // ── Modal: Add ────────────────────────────────────────────────────────────
    if (customId === 'autoresponder:modal:add') {
      const trigger  = interaction.fields.getTextInputValue('trigger').trim();
      const response = interaction.fields.getTextInputValue('response').trim();

      if (!trigger || !response) {
        return interaction.reply({ embeds: [errorEmbed('Trigger and response cannot be empty.')], flags: 1 << 6 });
      }

      addAutoresponder(interaction.guild.id, trigger, response);

      const { embed, row } = buildListEmbed(interaction.guild.id, interaction.guild.name);
      // Update the original panel in-place; fall back to a new reply if unavailable
      if (interaction.isFromMessage()) return interaction.update({ embeds: [embed], components: [row] });
      return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
    }

    // ── Modal: Edit ───────────────────────────────────────────────────────────
    if (customId === 'autoresponder:modal:edit') {
      const trigger     = interaction.fields.getTextInputValue('trigger').trim();
      const newResponse = interaction.fields.getTextInputValue('new_response').trim();

      const existing = getAutoresponder(interaction.guild.id, trigger);
      if (!existing) {
        return interaction.reply({ embeds: [errorEmbed(`No autoresponder found for trigger \`${trigger.toLowerCase()}\`.`)], flags: 1 << 6 });
      }

      addAutoresponder(interaction.guild.id, trigger, newResponse);

      const { embed, row } = buildListEmbed(interaction.guild.id, interaction.guild.name);
      // Update the original panel in-place; fall back to a new reply if unavailable
      if (interaction.isFromMessage()) return interaction.update({ embeds: [embed], components: [row] });
      return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
    }

    // ── Modal: Delete ─────────────────────────────────────────────────────────
    if (customId === 'autoresponder:modal:delete') {
      const trigger = interaction.fields.getTextInputValue('trigger').trim();
      const result  = removeAutoresponder(interaction.guild.id, trigger);

      if (result.changes === 0) {
        return interaction.reply({ embeds: [errorEmbed(`No autoresponder found for trigger \`${trigger.toLowerCase()}\`.`)], flags: 1 << 6 });
      }

      const { embed, row } = buildListEmbed(interaction.guild.id, interaction.guild.name);
      // Update the original panel in-place; fall back to a new reply if unavailable
      if (interaction.isFromMessage()) return interaction.update({ embeds: [embed], components: [row] });
      return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
    }
  },
};
