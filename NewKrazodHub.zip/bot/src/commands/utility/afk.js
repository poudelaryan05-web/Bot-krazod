const { SlashCommandBuilder } = require('discord.js');
const { getDB } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('afk').setDescription('Set your AFK status')
    .addStringOption(o => o.setName('reason').setDescription('AFK reason').setRequired(false)),
  async execute(interaction) {
    const reason = interaction.options.getString('reason') ?? 'AFK';
    const db = getDB();
    const existing = db.prepare('SELECT * FROM afk WHERE guild_id = ? AND user_id = ?').get(interaction.guild.id, interaction.user.id);
    if (existing) {
      return interaction.reply({ embeds: [errorEmbed('You are already AFK. Send a message to remove your AFK status.')], flags: 1 << 6 });
    }
    db.prepare('INSERT INTO afk (guild_id, user_id, reason, timestamp) VALUES (?, ?, ?, ?)').run(interaction.guild.id, interaction.user.id, reason, Date.now());
    await interaction.reply({ embeds: [successEmbed(`You are now AFK: **${reason}**`)] });
  },
};
