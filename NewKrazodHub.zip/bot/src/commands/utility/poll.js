const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a poll')
    .addStringOption(o => o.setName('question').setDescription('Poll question').setRequired(true))
    .addStringOption(o => o.setName('options').setDescription('Options separated by commas (max 9)').setRequired(false)),
  async execute(interaction) {
    const question = interaction.options.getString('question');
    const optRaw = interaction.options.getString('options');
    const EMOJI_NUMBERS = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];

    let description;
    let pollMsg;

    if (optRaw) {
      const opts = optRaw.split(',').map(o => o.trim()).filter(Boolean).slice(0, 9);
      description = opts.map((o, i) => `${EMOJI_NUMBERS[i]} ${o}`).join('\n');
      const embed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle(question)
        .setDescription(description)
        .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
        .setFooter({ text: 'Krazod Hub Poll' })
        .setTimestamp();
      pollMsg = await interaction.reply({ embeds: [embed], fetchReply: true });
      for (let i = 0; i < opts.length; i++) await pollMsg.react(EMOJI_NUMBERS[i]).catch(() => {});
    } else {
      const embed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle(question)
        .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
        .setFooter({ text: 'Krazod Hub Poll' })
        .setTimestamp();
      pollMsg = await interaction.reply({ embeds: [embed], fetchReply: true });
      await pollMsg.react('👍').catch(() => {});
      await pollMsg.react('👎').catch(() => {});
    }
  },
};
