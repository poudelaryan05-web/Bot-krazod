const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Check bot latency and API ping'),
  async execute(interaction) {
    const sent = await interaction.deferReply({ fetchReply: true });
    const roundtrip = sent.createdTimestamp - interaction.createdTimestamp;
    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('Pong!')
      .addFields(
        { name: 'Roundtrip', value: `${roundtrip}ms`, inline: true },
        { name: 'API Latency', value: `${interaction.client.ws.ping}ms`, inline: true },
      )
      .setFooter({ text: 'Krazod Hub' })
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
  },
};
