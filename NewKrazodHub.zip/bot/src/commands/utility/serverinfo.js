const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('View information about this server'),
  async execute(interaction) {
    const g = interaction.guild;
    await g.fetch();
    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle(g.name)
      .setThumbnail(g.iconURL({ size: 256 }))
      .setImage(g.bannerURL({ size: 1024 }) ?? null)
      .addFields(
        { name: 'Owner',        value: `<@${g.ownerId}>`, inline: true },
        { name: 'Members',      value: g.memberCount.toString(), inline: true },
        { name: 'Channels',     value: g.channels.cache.size.toString(), inline: true },
        { name: 'Roles',        value: g.roles.cache.size.toString(), inline: true },
        { name: 'Boosts',       value: (g.premiumSubscriptionCount ?? 0).toString(), inline: true },
        { name: 'Boost Level',  value: g.premiumTier.toString(), inline: true },
        { name: 'Created',      value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Verification', value: g.verificationLevel.toString(), inline: true },
      )
      .setFooter({ text: `ID: ${g.id}` })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
