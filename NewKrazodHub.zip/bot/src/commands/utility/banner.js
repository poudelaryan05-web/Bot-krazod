const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('banner').setDescription("Get a user's banner")
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(false)),
  async execute(interaction) {
    const user = interaction.options.getUser('user') ?? interaction.user;
    await user.fetch(true);
    if (!user.banner) {
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(COLORS.muted).setDescription(`**${user.username}** has no banner set.`).setTimestamp()],
        flags: 1 << 6,
      });
    }
    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle(`${user.username}'s Banner`)
      .setImage(user.bannerURL({ size: 4096 }))
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
