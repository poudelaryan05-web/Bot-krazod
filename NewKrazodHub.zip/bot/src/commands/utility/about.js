const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');
const { getDB } = require('../../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('about')
    .setDescription('View live statistics and information about Krazod Hub'),

  async execute(interaction) {
    await interaction.deferReply();

    const client = interaction.client;

    // Uptime
    const uptime = process.uptime();
    const d = Math.floor(uptime / 86400);
    const h = Math.floor((uptime % 86400) / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = Math.floor(uptime % 60);
    const uptimeStr = [
      d > 0 && `${d}d`,
      h > 0 && `${h}h`,
      m > 0 && `${m}m`,
      `${s}s`,
    ].filter(Boolean).join(' ');

    // Total users across all guilds
    const totalUsers = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);

    // DB status
    let dbStatus = 'Connected';
    try {
      getDB();
    } catch {
      dbStatus = 'Disconnected';
    }

    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('Krazod Hub')
      .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
      .setDescription('A professional all-in-one Discord bot built for reliability and performance.')
      .addFields(
        { name: 'Total Servers', value: client.guilds.cache.size.toString(), inline: true },
        { name: 'Total Users',   value: totalUsers.toString(),               inline: true },
        { name: 'Bot Status',    value: 'Online',                            inline: true },
        { name: 'Ping',          value: `${client.ws.ping}ms`,              inline: true },
        { name: 'Uptime',        value: uptimeStr,                           inline: true },
        { name: 'Database',      value: dbStatus,                            inline: true },
        { name: 'Version',       value: '1.0.0',                             inline: true },
      )
      .setFooter({ text: 'Krazod Hub' })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};
