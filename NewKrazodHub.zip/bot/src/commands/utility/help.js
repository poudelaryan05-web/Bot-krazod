'use strict';
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');

const CATEGORIES = {
  general: {
    label: 'General',
    description: 'General utility commands',
    commands: [
      '`/help` — Browse all commands',
      '`/about` — Bot statistics and info',
      '`/ping` — Check bot latency',
      '`/botinfo` — Detailed bot information',
      '`/serverinfo` — Server information',
      '`/userinfo [user]` — User information',
      '`/avatar [user]` — View a user\'s avatar',
      '`/banner [user]` — View a user\'s banner',
      '`/poll <question>` — Create a poll',
      '`/remind <time> <message>` — Set a reminder',
      '`/afk [reason]` — Set your AFK status',
    ],
  },
  moderation: {
    label: 'Moderation',
    description: 'Server moderation tools',
    commands: [
      '`/ban <user> [reason]` — Ban a member',
      '`/unban <user-id>` — Unban a user',
      '`/kick <user> [reason]` — Kick a member',
      '`/timeout <user> <duration> [reason]` — Timeout a member',
      '`/untimeout <user>` — Remove a timeout',
      '`/warn <user> <reason>` — Warn a member',
      '`/warnings <user>` — View a member\'s warnings',
      '`/clear <amount>` — Bulk delete messages',
    ],
  },
  music: {
    label: 'Music',
    description: '24/7 voice channel presence',
    commands: [
      '`/247` — Toggle 24/7 mode (keep bot in your voice channel permanently)',
    ],
  },
  tickets: {
    label: 'Tickets',
    description: 'Private support ticket system',
    commands: [
      '`/ticket setup` — Set up the ticket system (panel channel, category, support role)',
      '`/ticket disable` — Disable the ticket system',
    ],
  },
  giveaways: {
    label: 'Giveaways',
    description: 'Run and manage giveaways',
    commands: [
      '`/giveaway start` — Start a new giveaway',
      '`/giveaway end <id>` — End a giveaway early',
      '`/giveaway reroll <id>` — Reroll giveaway winners',
    ],
  },
  verification: {
    label: 'Verification',
    description: 'Member verification gate',
    commands: [
      '`/verification setup` — Set up the verification panel and roles',
      '`/verification disable` — Disable verification',
    ],
  },
  feedback: {
    label: 'Feedback',
    description: 'Server feedback collection',
    commands: [
      '`/feedback setup` — Set up the feedback channel',
      '`/feedback submit` — Submit feedback about the server',
      '`/feedback disable` — Disable the feedback system',
    ],
  },
  leveling: {
    label: 'Leveling',
    description: 'XP and leveling system',
    commands: [
      '`/levels setup` — Configure the leveling system',
      '`/levels disable` — Disable leveling',
      '`/rank [user]` — View your or another member\'s rank and XP',
      '`/leaderboard` — View the server XP leaderboard',
      '`/levelrewards` — Manage level-up role rewards',
    ],
  },
  automod: {
    label: 'AutoMod',
    description: 'Automated message moderation',
    commands: [
      '`/automod setup` — Toggle AutoMod rules (spam, caps, invites, links, bad words)',
      '`/automod status` — View current AutoMod configuration',
      '`/automod badwords <add|remove|list|clear> [word]` — Manage blocked words',
      '`/automod whitelist <add|remove|list> [domain]` — Manage allowed link domains',
      '`/automod disable` — Disable AutoMod entirely',
    ],
  },
  security: {
    label: 'Security',
    description: 'Anti-nuke, anti-raid & advanced protection',
    commands: [
      '`/security setup` — Configure the security system',
      '`/security disable` — Disable all security protections',
      '`/security status` — View current security config and state',
      '`/security lockdown [reason]` — Manually lock all server channels',
      '`/security unlock` — Remove lockdown and restore channel permissions',
      '`/security whitelist <add|remove|list> [user]` — Manage whitelisted users',
      '`/security trustedrole <add|remove|list> [role]` — Manage trusted roles',
      '`/security threshold <action> <count>` — Set detection thresholds',
    ],
  },
  logging: {
    label: 'Logging',
    description: 'Professional server event logging',
    commands: [
      '`/logging setup` — Select log categories and assign channels',
      '`/logging status` — View current logging configuration',
      '`/logging disable` — Disable all event logging',
      '',
      '**Logged Events:**',
      '• Messages: edits, deletions, bulk deletions',
      '• Members: join, leave, nickname, avatar, username changes',
      '• Voice: join, leave, move',
      '• Moderation: ban, unban, kick, timeout, warn, AutoMod actions',
      '• Server: channel, role, emoji, sticker, invite, webhook, thread, server updates',
      '• Security: anti-nuke, anti-raid, phishing, flood alerts',
    ],
  },
  autoresponder: {
    label: 'Autoresponder',
    description: 'Automatic replies based on trigger words',
    commands: [
      '`/autoresponder` — Open the autoresponder management panel',
      '',
      '**Features:**',
      '• Add triggers and responses',
      '• Edit existing autoresponders',
      '• Delete autoresponders',
      '• Triggers are matched case-insensitively',
    ],
  },
  spam: {
    label: 'Spam Protection',
    description: 'Automatic anti-spam detection and enforcement',
    commands: [
      '`/spam enable` — Enable spam protection',
      '`/spam disable` — Disable spam protection',
      '`/spam limit <count>` — Set the message count threshold (default: 5)',
      '`/spam window <seconds>` — Set the detection time window (default: 5s)',
      '`/spam admins <true|false>` — Toggle whether admins are excluded',
      '`/spam status` — View current spam protection settings',
    ],
  },
  reactionroles: {
    label: 'Reaction Roles',
    description: 'Assign roles via message reactions',
    commands: [
      '`/reactionrole add <message> <emoji> <role>` — Add a reaction role to a message',
      '`/reactionrole remove <message> <emoji>` — Remove a reaction role',
      '`/reactionrole list` — List all reaction roles in this server',
    ],
  },
  welcome: {
    label: 'Welcome & Leave',
    description: 'Animated welcome and farewell image cards',
    commands: [
      '`/welcome setup` — Set up the welcome channel',
      '`/welcome disable` — Disable welcome messages',
      '`/leave setup` — Set up the leave channel',
      '`/leave disable` — Disable leave messages',
    ],
  },
};

module.exports = {
  CATEGORIES,
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Browse all Krazod Hub commands'),

  async execute(interaction) {
    const totalCommands = Object.values(CATEGORIES).reduce(
      (acc, c) => acc + c.commands.filter(l => l.startsWith('`/')).length, 0,
    );

    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('Krazod Hub — Help')
      .setDescription(
        `Use the dropdown below to browse commands by category.\n\n` +
        `**Categories:** ${Object.keys(CATEGORIES).length}\n` +
        `**Total Commands:** ${totalCommands}`,
      )
      .addFields(
        { name: 'General',          value: 'Utility & info',                 inline: true },
        { name: 'Moderation',       value: 'Ban, kick, warn, clear',         inline: true },
        { name: 'Music',            value: '24/7 voice mode',                inline: true },
        { name: 'Tickets',          value: 'Support ticket system',          inline: true },
        { name: 'Giveaways',        value: 'Run server giveaways',           inline: true },
        { name: 'Verification',     value: 'Member verification',            inline: true },
        { name: 'Feedback',         value: 'Collect server feedback',        inline: true },
        { name: 'Leveling',         value: 'XP & rank system',               inline: true },
        { name: 'AutoMod',          value: 'Auto message moderation',        inline: true },
        { name: 'Security',         value: 'Anti-nuke & raid',               inline: true },
        { name: 'Logging',          value: 'Professional event logging',     inline: true },
        { name: 'Autoresponder',    value: 'Trigger-based auto replies',     inline: true },
        { name: 'Spam Protection',  value: 'Anti-spam enforcement',          inline: true },
        { name: 'Reaction Roles',   value: 'Role-on-reaction system',        inline: true },
        { name: 'Welcome & Leave',  value: 'Join/leave cards',               inline: true },
      )
      .setFooter({ text: 'Krazod Hub' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('setup:help:category')
        .setPlaceholder('Select a category...')
        .addOptions(
          Object.entries(CATEGORIES).map(([value, { label, description }]) => ({
            label,
            description: description.slice(0, 100),
            value,
          })),
        ),
    );

    return interaction.reply({ embeds: [embed], components: [row] });
  },
};
