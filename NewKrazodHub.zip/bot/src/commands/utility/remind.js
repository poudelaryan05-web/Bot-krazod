const { SlashCommandBuilder } = require('discord.js');
const { getDB } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const ms = require('ms');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Set a reminder')
    .addStringOption(o => o.setName('time').setDescription('Time (e.g. 10m, 1h, 2d)').setRequired(true))
    .addStringOption(o => o.setName('message').setDescription('Reminder message').setRequired(true)),
  async execute(interaction) {
    const timeStr = interaction.options.getString('time');
    const message = interaction.options.getString('message');
    const duration = ms(timeStr);

    if (!duration || duration < 1000 || duration > 30 * 24 * 60 * 60 * 1000) {
      return interaction.reply({ embeds: [errorEmbed('Invalid time. Use formats like `10m`, `1h`, `2d` (max 30 days).')], flags: 1 << 6 });
    }

    const remindAt = Date.now() + duration;
    getDB().prepare('INSERT INTO reminders (user_id, channel_id, guild_id, message, remind_at) VALUES (?, ?, ?, ?, ?)')
      .run(interaction.user.id, interaction.channel.id, interaction.guild.id, message, remindAt);

    await interaction.reply({ embeds: [successEmbed(`Reminder set! I will remind you in **${timeStr}**.\n> ${message}`)] });
  },
};
