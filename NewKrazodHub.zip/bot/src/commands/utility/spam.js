'use strict';
/**
 * spam.js — Single interactive /spam command
 *
 * Opens a management panel with buttons to:
 *   • Enable / Disable spam protection
 *   • Configure spam limit (via modal)
 *   • Configure time window (via modal)
 *   • Toggle administrator exemption
 *   • View current settings (inline in panel)
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { getConfig, setConfig } = require('../../database/db');
const { COLORS } = require('../../utils/embeds');

const DEFAULT_LIMIT  = 5;
const DEFAULT_WINDOW = 5;

// ── Build the management embed + button rows ──────────────────────────────────
function buildSpamPanel(guildId) {
  const config        = getConfig(guildId, 'spam') ?? {};
  const enabled       = config.enabled ?? false;
  const limit         = config.limit  ?? DEFAULT_LIMIT;
  const windowSec     = config.window ?? DEFAULT_WINDOW;
  const ignoreAdmins  = config.ignoreAdmins !== false;

  const embed = new EmbedBuilder()
    .setColor(enabled ? COLORS.success : COLORS.muted)
    .setTitle('Spam Protection — Management')
    .setDescription(enabled
      ? 'Spam protection is currently **enabled**.'
      : 'Spam protection is currently **disabled**.')
    .addFields(
      { name: 'Spam Limit',           value: `${limit} message${limit !== 1 ? 's' : ''}`,       inline: true },
      { name: 'Time Window',          value: `${windowSec} second${windowSec !== 1 ? 's' : ''}`, inline: true },
      { name: 'Ignore Administrators', value: ignoreAdmins ? 'Yes' : 'No',                       inline: true },
    )
    .addFields({
      name: 'How it works',
      value:
        `If a member sends more than **${limit} messages** within **${windowSec} seconds**, ` +
        `the bot will delete all detected spam messages, issue an automatic warning, and notify the channel.`,
    })
    .setFooter({ text: 'Krazod Hub Spam Protection' })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('spam:toggle')
      .setLabel(enabled ? 'Disable Spam Protection' : 'Enable Spam Protection')
      .setStyle(enabled ? ButtonStyle.Danger : ButtonStyle.Success),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('spam:set_limit')
      .setLabel('Set Spam Limit')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('spam:set_window')
      .setLabel('Set Time Window')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('spam:toggle_admins')
      .setLabel(ignoreAdmins ? 'Include Administrators' : 'Ignore Administrators')
      .setStyle(ButtonStyle.Secondary),
  );

  return { embed, components: [row1, row2] };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('spam')
    .setDescription('Configure the anti-spam protection system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  buildSpamPanel,

  async execute(interaction) {
    const { embed, components } = buildSpamPanel(interaction.guild.id);
    return interaction.reply({ embeds: [embed], components, flags: 1 << 6 });
  },

  // ── Called from index.js for button/modal interactions ───────────────────────
  async handleInteraction(interaction) {
    const { customId } = interaction;
    const guildId      = interaction.guild.id;

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(COLORS.error).setDescription('You need the **Manage Server** permission.').setTimestamp()],
        flags: 1 << 6,
      });
    }

    // ── Enable / Disable toggle ───────────────────────────────────────────────
    if (customId === 'spam:toggle') {
      const current = getConfig(guildId, 'spam') ?? {};
      setConfig(guildId, 'spam', { ...current, enabled: !current.enabled });
      const { embed, components } = buildSpamPanel(guildId);
      return interaction.update({ embeds: [embed], components });
    }

    // ── Toggle administrator exemption ────────────────────────────────────────
    if (customId === 'spam:toggle_admins') {
      const current       = getConfig(guildId, 'spam') ?? {};
      const ignoreAdmins  = current.ignoreAdmins !== false;
      setConfig(guildId, 'spam', { ...current, ignoreAdmins: !ignoreAdmins });
      const { embed, components } = buildSpamPanel(guildId);
      return interaction.update({ embeds: [embed], components });
    }

    // ── Set Spam Limit — open modal ───────────────────────────────────────────
    if (customId === 'spam:set_limit') {
      const current = getConfig(guildId, 'spam') ?? {};
      const modal = new ModalBuilder()
        .setCustomId('spam:modal:limit')
        .setTitle('Set Spam Limit');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('limit')
            .setLabel('Messages before spam is detected (2–30)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder(`Current: ${current.limit ?? DEFAULT_LIMIT}`)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(2),
        ),
      );

      return interaction.showModal(modal);
    }

    // ── Set Time Window — open modal ──────────────────────────────────────────
    if (customId === 'spam:set_window') {
      const current = getConfig(guildId, 'spam') ?? {};
      const modal = new ModalBuilder()
        .setCustomId('spam:modal:window')
        .setTitle('Set Time Window');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('window')
            .setLabel('Detection window in seconds (1–60)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder(`Current: ${current.window ?? DEFAULT_WINDOW}`)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(2),
        ),
      );

      return interaction.showModal(modal);
    }

    // ── Modal: Spam Limit submitted ───────────────────────────────────────────
    if (customId === 'spam:modal:limit') {
      const raw   = interaction.fields.getTextInputValue('limit').trim();
      const value = parseInt(raw, 10);

      if (isNaN(value) || value < 2 || value > 30) {
        return interaction.reply({
          embeds: [new EmbedBuilder().setColor(COLORS.error).setDescription('Spam limit must be a number between 2 and 30.').setTimestamp()],
          flags: 1 << 6,
        });
      }

      const current = getConfig(guildId, 'spam') ?? {};
      setConfig(guildId, 'spam', { ...current, limit: value });
      const { embed, components } = buildSpamPanel(guildId);
      // Update the original panel in-place; fall back to a new reply if unavailable
      if (interaction.isFromMessage()) return interaction.update({ embeds: [embed], components });
      return interaction.reply({ embeds: [embed], components, flags: 1 << 6 });
    }

    // ── Modal: Time Window submitted ──────────────────────────────────────────
    if (customId === 'spam:modal:window') {
      const raw   = interaction.fields.getTextInputValue('window').trim();
      const value = parseInt(raw, 10);

      if (isNaN(value) || value < 1 || value > 60) {
        return interaction.reply({
          embeds: [new EmbedBuilder().setColor(COLORS.error).setDescription('Time window must be a number between 1 and 60 seconds.').setTimestamp()],
          flags: 1 << 6,
        });
      }

      const current = getConfig(guildId, 'spam') ?? {};
      setConfig(guildId, 'spam', { ...current, window: value });
      const { embed, components } = buildSpamPanel(guildId);
      // Update the original panel in-place; fall back to a new reply if unavailable
      if (interaction.isFromMessage()) return interaction.update({ embeds: [embed], components });
      return interaction.reply({ embeds: [embed], components, flags: 1 << 6 });
    }
  },
};
