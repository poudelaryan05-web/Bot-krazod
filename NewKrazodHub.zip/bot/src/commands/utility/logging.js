'use strict';
const {
  SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder,
  ActionRowBuilder, StringSelectMenuBuilder,
} = require('discord.js');
const { getConfig, setConfig, deleteConfig } = require('../../database/db');
const { successEmbed, errorEmbed, COLORS } = require('../../utils/embeds');

// ── All log categories ────────────────────────────────────────────────────────
const LOG_CATEGORIES = [
  { value: 'messages',   label: 'Message Logs',    description: 'Edits, deletions, bulk deletes',          configKey: 'messageChannelId' },
  { value: 'members',    label: 'Member Logs',      description: 'Joins, leaves, nicknames, avatars',       configKey: 'memberChannelId' },
  { value: 'moderation', label: 'Moderation Logs',  description: 'Bans, kicks, timeouts, warns',            configKey: 'moderationChannelId' },
  { value: 'voice',      label: 'Voice Logs',        description: 'Voice channel join, leave, move',        configKey: 'voiceChannelId' },
  { value: 'roles',      label: 'Role Logs',         description: 'Role add/remove on members, role edits', configKey: 'roleChannelId' },
  { value: 'channels',   label: 'Channel Logs',      description: 'Channel create, delete, update',         configKey: 'channelLogsId' },
  { value: 'emoji',      label: 'Emoji Logs',        description: 'Emoji added or deleted',                 configKey: 'emojiChannelId' },
  { value: 'stickers',   label: 'Sticker Logs',      description: 'Sticker added or deleted',               configKey: 'stickerChannelId' },
  { value: 'invites',    label: 'Invite Logs',       description: 'Invite created or deleted',              configKey: 'inviteChannelId' },
  { value: 'server',     label: 'Server Logs',       description: 'Server name, icon, settings changes',   configKey: 'serverChannelId' },
  { value: 'boosts',     label: 'Boost Logs',        description: 'Server boosts',                          configKey: 'boostChannelId' },
  { value: 'threads',    label: 'Thread Logs',       description: 'Thread created or deleted',              configKey: 'threadChannelId' },
  { value: 'webhooks',   label: 'Webhook Logs',      description: 'Webhook created or deleted',             configKey: 'webhookChannelId' },
  { value: 'automod',    label: 'Automod Logs',      description: 'AutoMod rule triggers',                  configKey: 'automodChannelId' },
  { value: 'tickets',    label: 'Ticket Logs',       description: 'Ticket open and close events',           configKey: 'ticketsChannelId' },
  { value: 'giveaways',  label: 'Giveaway Logs',     description: 'Giveaway start and end events',          configKey: 'giveawaysChannelId' },
  { value: 'levels',     label: 'Level Logs',        description: 'Member level-up events',                 configKey: 'levelChannelId' },
  { value: 'security',   label: 'Security Logs',     description: 'Anti-nuke, anti-raid, phishing alerts',  configKey: 'securityChannelId' },
];

// ── Build a clean status description ──────────────────────────────────────────
function buildStatusDescription(config) {
  if (!config || !config.enabled) return 'Logging is **disabled**.';

  const lines = ['Logging is **enabled**.\n'];
  for (const cat of LOG_CATEGORIES) {
    const channelId = config[cat.configKey];
    lines.push(`**${cat.label}:** ${channelId ? `<#${channelId}>` : '_Not set_'}`);
  }
  return lines.join('\n');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('logging')
    .setDescription('Configure server event logging')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)

    .addSubcommand(s => s
      .setName('setup')
      .setDescription('Select which log categories to enable and assign channels'))

    .addSubcommand(s => s
      .setName('status')
      .setDescription('View current logging configuration'))

    .addSubcommand(s => s
      .setName('disable')
      .setDescription('Disable all event logging')),

  LOG_CATEGORIES,

  async execute(interaction) {
    const sub     = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    // ── disable ─────────────────────────────────────────────────────────────
    if (sub === 'disable') {
      deleteConfig(guildId, 'logging');
      return interaction.reply({
        embeds: [successEmbed('Logging has been disabled and all channel configurations cleared.')],
        flags: 1 << 6,
      });
    }

    // ── status ───────────────────────────────────────────────────────────────
    if (sub === 'status') {
      const config = getConfig(guildId, 'logging') ?? {};
      const embed  = new EmbedBuilder()
        .setColor(config.enabled ? COLORS.success : COLORS.muted)
        .setTitle('Logging System — Status')
        .setDescription(buildStatusDescription(config))
        .setFooter({ text: 'Krazod Hub Logging' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed], flags: 1 << 6 });
    }

    // ── setup ────────────────────────────────────────────────────────────────
    // Step 1: Ask which categories to enable (select menu + "Log All" option)
    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('Logging Setup — Step 1 of 2')
      .setDescription(
        'Select which log categories you want to enable.\n\n' +
        'Choose **Log All** to enable every category with a single channel, ' +
        'or select individual categories to assign them to separate channels.\n\n' +
        'You can select multiple categories at once.'
      )
      .setFooter({ text: 'Krazod Hub Logging' })
      .setTimestamp();

    const options = [
      {
        label:       'Log All',
        description: 'Enable every category — you will choose one channel for all',
        value:       'log_all',
      },
      ...LOG_CATEGORIES.map(c => ({
        label:       c.label,
        description: c.description.slice(0, 100),
        value:       c.value,
      })),
    ];

    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('setup:logging:categories')
        .setPlaceholder('Select log categories to configure…')
        .setMinValues(1)
        .setMaxValues(options.length)
        .addOptions(options),
    );

    return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },
};
