'use strict';
/**
 * lock.js — Interactive channel lock/unlock command
 *
 * /lock → shows a channel select menu
 * User selects a channel → bot removes @everyone Send Messages permission
 * Confirmation message includes an Unlock button
 * Pressing Unlock restores the permission
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  OverwriteType,
} = require('discord.js');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock or unlock a channel for @everyone')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle('Lock Channel')
      .setDescription('Select a channel to lock. The **@everyone** role will be prevented from sending messages until you unlock it.')
      .setFooter({ text: 'Krazod Hub' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('lock:select_channel')
        .setPlaceholder('Select a channel to lock...')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum),
    );

    return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },

  // ── Called from index.js for select-menu/button interactions ─────────────────
  async handleInteraction(interaction) {
    const { customId } = interaction;

    // ── Channel selected — lock it ────────────────────────────────────────────
    if (interaction.isChannelSelectMenu() && customId === 'lock:select_channel') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({
          embeds: [new EmbedBuilder().setColor(COLORS.error).setDescription('You need the **Manage Channels** permission.').setTimestamp()],
          flags: 1 << 6,
        });
      }

      const channel = interaction.channels.first();
      if (!channel) {
        return interaction.reply({
          embeds: [new EmbedBuilder().setColor(COLORS.error).setDescription('No channel selected.').setTimestamp()],
          flags: 1 << 6,
        });
      }

      // Verify bot has permission to manage the channel
      const botMember = interaction.guild.members.me;
      if (!channel.permissionsFor(botMember)?.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.error)
            .setDescription(`I do not have **Manage Channels** permission in ${channel}. Please update my role permissions and try again.`)
            .setTimestamp()],
          flags: 1 << 6,
        });
      }

      // Lock: deny SendMessages for @everyone
      try {
        await channel.permissionOverwrites.edit(interaction.guild.id, {
          SendMessages: false,
        });
      } catch {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.error)
            .setDescription(`Failed to lock ${channel}. Check my role position and channel permissions.`)
            .setTimestamp()],
          flags: 1 << 6,
        });
      }

      const embed = new EmbedBuilder()
        .setColor(COLORS.error)
        .setTitle('Channel Locked')
        .setDescription(`${channel} has been locked. Members can no longer send messages in this channel.`)
        .addFields(
          { name: 'Channel',  value: `${channel}`, inline: true },
          { name: 'Locked By', value: `${interaction.user} (\`${interaction.user.id}\`)`, inline: true },
        )
        .setFooter({ text: 'Press Unlock to restore access.' })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`lock:unlock:${channel.id}`)
          .setLabel('Unlock Channel')
          .setStyle(ButtonStyle.Success),
      );

      return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
    }

    // ── Unlock button ─────────────────────────────────────────────────────────
    if (interaction.isButton() && customId.startsWith('lock:unlock:')) {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({
          embeds: [new EmbedBuilder().setColor(COLORS.error).setDescription('You need the **Manage Channels** permission.').setTimestamp()],
          flags: 1 << 6,
        });
      }

      const channelId = customId.slice('lock:unlock:'.length);
      const channel   = interaction.guild.channels.cache.get(channelId);

      if (!channel) {
        return interaction.reply({
          embeds: [new EmbedBuilder().setColor(COLORS.error).setDescription('Channel no longer exists or is not accessible.').setTimestamp()],
          flags: 1 << 6,
        });
      }

      const botMember = interaction.guild.members.me;
      if (!channel.permissionsFor(botMember)?.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.error)
            .setDescription(`I do not have **Manage Channels** permission in ${channel}.`)
            .setTimestamp()],
          flags: 1 << 6,
        });
      }

      // Unlock: remove the explicit SendMessages deny — restores inherited permission
      try {
        await channel.permissionOverwrites.edit(interaction.guild.id, {
          SendMessages: null,
        });
      } catch {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.error)
            .setDescription(`Failed to unlock ${channel}. Check my role position and channel permissions.`)
            .setTimestamp()],
          flags: 1 << 6,
        });
      }

      const embed = new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle('Channel Unlocked')
        .setDescription(`${channel} has been unlocked. Members can send messages again.`)
        .addFields(
          { name: 'Channel',    value: `${channel}`, inline: true },
          { name: 'Unlocked By', value: `${interaction.user} (\`${interaction.user.id}\`)`, inline: true },
        )
        .setTimestamp();

      // Remove the Unlock button from the original message
      await interaction.message.edit({ components: [] }).catch(() => {});

      return interaction.reply({ embeds: [embed], flags: 1 << 6 });
    }
  },
};
