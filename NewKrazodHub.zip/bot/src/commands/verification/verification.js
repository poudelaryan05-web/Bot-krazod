const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getConfig, setConfig, deleteConfig } = require('../../database/db');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verification')
    .setDescription('Manage the verification system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup').setDescription('Set up the verification system'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable the verification system')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'disable') {
      deleteConfig(interaction.guild.id, 'verification');
      return interaction.reply({ embeds: [successEmbed('Verification system has been disabled.')], flags: 1 << 6 });
    }

    const current = getConfig(interaction.guild.id, 'verification') ?? {};
    const embed = infoEmbed(
      `**Verification System Setup**\n\n` +
      `Require members to verify before accessing the server.\n\n` +
      `**Current Settings:**\n` +
      `Panel Channel: ${current.panelChannelId ? `<#${current.panelChannelId}>` : 'Not set'}\n` +
      `Verified Role: ${current.verifiedRoleId ? `<@&${current.verifiedRoleId}>` : 'Not set'}\n` +
      `Unverified Role: ${current.unverifiedRoleId ? `<@&${current.unverifiedRoleId}>` : 'Not set'}`,
      'Verification Setup'
    );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('setup:verification:panel_channel').setLabel('Panel Channel').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('setup:verification:verified_role').setLabel('Verified Role').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('setup:verification:unverified_role').setLabel('Unverified Role').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('setup:verification:send_panel').setLabel('Send Panel').setStyle(ButtonStyle.Success),
    );

    await interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },
};
