const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Official Discord Nitro logo (Discord CDN)
const NITRO_THUMBNAIL = 'https://i.imgur.com/w9aiD6F.png';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nitro')
    .setDescription('Send a fake Nitro gift prank to a user (harmless fun)')
    .addUserOption(o => o.setName('user').setDescription('User to prank').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user');

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setAuthor({
        name: 'Discord Nitro',
        iconURL: NITRO_THUMBNAIL,
      })
      .setTitle('You received a gift subscription!')
      .setDescription(
        `**${interaction.user.username}** has sent you a gift!\n\n` +
        `> **Discord Nitro — 1 Month**\n` +
        `> Unlock better emoji, HD streaming, bigger uploads, and more.`
      )
      .setThumbnail(NITRO_THUMBNAIL)
      .addFields({
        name: 'Expires in',
        value: '48 hours',
        inline: true,
      })
      .setFooter({ text: 'Discord Nitro • Limited Time Offer' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('nitro:claim')
        .setLabel('Claim Gift')
        .setStyle(ButtonStyle.Success),
    );

    const content = target ? `${target}` : '';
    await interaction.reply({ content, embeds: [embed], components: [row] });
  },
};
