'use strict';
const {
  SlashCommandBuilder, PermissionFlagsBits,
  ActionRowBuilder, ChannelSelectMenuBuilder, ChannelType,
} = require('discord.js');
const { getConfig, setConfig, deleteConfig } = require('../../database/db');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leave')
    .setDescription('Leave / farewell system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup').setDescription('Set up the leave system'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable the leave system')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'disable') {
      deleteConfig(interaction.guild.id, 'leave');
      return interaction.reply({ embeds: [successEmbed('Leave system has been disabled.')], flags: 1 << 6 });
    }

    // sub === 'setup'
    const current = getConfig(interaction.guild.id, 'leave') ?? {};
    const embed = infoEmbed(
      `**Leave System Setup**\n\n` +
      `Sends a farewell image card when a member leaves the server.\n\n` +
      `**Current Settings:**\n` +
      `Leave Channel: ${current.channelId ? `<#${current.channelId}>` : 'Not set'}\n\n` +
      `Select a channel below to enable the leave system.`,
      'Leave Setup',
    );

    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('setup:leave:select_channel')
        .setPlaceholder('Select the leave channel...')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    );

    return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },
};
