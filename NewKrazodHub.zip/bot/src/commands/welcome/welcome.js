'use strict';
const {
  SlashCommandBuilder, PermissionFlagsBits,
  ActionRowBuilder, ChannelSelectMenuBuilder, ChannelType,
} = require('discord.js');
const { getConfig, setConfig, deleteConfig } = require('../../database/db');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('welcome')
    .setDescription('Welcome system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup').setDescription('Set up the welcome system'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable the welcome system')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'disable') {
      deleteConfig(interaction.guild.id, 'welcome');
      return interaction.reply({ embeds: [successEmbed('Welcome system has been disabled.')], flags: 1 << 6 });
    }

    // sub === 'setup'
    const current = getConfig(interaction.guild.id, 'welcome') ?? {};
    const embed = infoEmbed(
      `**Welcome System Setup**\n\n` +
      `Sends a welcome image card when a member joins the server.\n\n` +
      `**Current Settings:**\n` +
      `Welcome Channel: ${current.channelId ? `<#${current.channelId}>` : 'Not set'}\n\n` +
      `Select a channel below to enable the welcome system.`,
      'Welcome Setup',
    );

    const row = new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('setup:welcome:select_channel')
        .setPlaceholder('Select the welcome channel...')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    );

    return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },
};
