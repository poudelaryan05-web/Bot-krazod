const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { getDB } = require('../../database/db');
const { errorEmbed, successEmbed, COLORS } = require('../../utils/embeds');
const { buildGiveawayEmbed, buildGiveawayRow, endGiveaway } = require('../../managers/giveawayManager');
const ms = require('ms');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Manage giveaways')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageEvents)
    .addSubcommand(s => s
      .setName('start')
      .setDescription('Start a giveaway')
      .addStringOption(o => o.setName('prize').setDescription('Prize name').setRequired(true))
      .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 10m, 1h, 1d)').setRequired(true))
      .addIntegerOption(o => o.setName('winners').setDescription('Number of winners').setRequired(false).setMinValue(1).setMaxValue(10))
      .addRoleOption(o => o.setName('required_role').setDescription('Required role to enter').setRequired(false))
    )
    .addSubcommand(s => s
      .setName('end')
      .setDescription('End a giveaway early')
      .addIntegerOption(o => o.setName('id').setDescription('Giveaway ID').setRequired(true))
    )
    .addSubcommand(s => s
      .setName('reroll')
      .setDescription('Reroll giveaway winners')
      .addIntegerOption(o => o.setName('id').setDescription('Giveaway ID').setRequired(true))
    ),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const db = getDB();

    if (sub === 'start') {
      const prize = interaction.options.getString('prize');
      const durationStr = interaction.options.getString('duration');
      const winnerCount = interaction.options.getInteger('winners') ?? 1;
      const requiredRole = interaction.options.getRole('required_role');
      const duration = ms(durationStr);

      if (!duration || duration < 10_000) {
        return interaction.reply({ embeds: [errorEmbed('Invalid duration. Minimum is 10 seconds.')], flags: 1 << 6 });
      }

      const endTime = Date.now() + duration;
      const giveaway = { prize, winner_count: winnerCount, end_time: endTime, required_role: requiredRole?.id ?? null, entries: '[]', ended: 0 };
      const embed = buildGiveawayEmbed({ ...giveaway, id: 0 });
      const row = buildGiveawayRow(false);

      const msg = await interaction.channel.send({ embeds: [embed], components: [row] });
      const result = db.prepare('INSERT INTO giveaways (guild_id, channel_id, message_id, prize, winner_count, end_time, required_role, entries, ended, winners) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)')
        .run(interaction.guild.id, interaction.channel.id, msg.id, prize, winnerCount, endTime, requiredRole?.id ?? null, '[]', '[]');

      // Update embed with real ID
      const realGiveaway = db.prepare('SELECT * FROM giveaways WHERE id = ?').get(result.lastInsertRowid);
      await msg.edit({ embeds: [buildGiveawayEmbed(realGiveaway)], components: [row] });

      return interaction.reply({ embeds: [successEmbed(`Giveaway started! Prize: **${prize}** | Ends: <t:${Math.floor(endTime / 1000)}:R>`)], flags: 1 << 6 });
    }

    if (sub === 'end') {
      const id = interaction.options.getInteger('id');
      const g = db.prepare('SELECT * FROM giveaways WHERE id = ? AND guild_id = ?').get(id, interaction.guild.id);
      if (!g) return interaction.reply({ embeds: [errorEmbed(`Giveaway #${id} not found.`)], flags: 1 << 6 });
      if (g.ended) return interaction.reply({ embeds: [errorEmbed('This giveaway has already ended.')], flags: 1 << 6 });

      await endGiveaway(client, id);
      return interaction.reply({ embeds: [successEmbed(`Giveaway #${id} ended.`)], flags: 1 << 6 });
    }

    if (sub === 'reroll') {
      const id = interaction.options.getInteger('id');
      const g = db.prepare('SELECT * FROM giveaways WHERE id = ? AND guild_id = ?').get(id, interaction.guild.id);
      if (!g || !g.ended) return interaction.reply({ embeds: [errorEmbed(`Giveaway #${id} not found or has not ended.`)], flags: 1 << 6 });

      const entries = JSON.parse(g.entries || '[]');
      if (entries.length === 0) return interaction.reply({ embeds: [errorEmbed('No entries to reroll.')], flags: 1 << 6 });

      const newWinners = entries.sort(() => Math.random() - 0.5).slice(0, g.winner_count);
      await interaction.reply({ content: `Reroll! New winner(s): ${newWinners.map(id => `<@${id}>`).join(', ')} for **${g.prize}**!` });
    }
  },
};
