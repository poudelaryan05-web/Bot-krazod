const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUserLevel, xpForLevel } = require('../../managers/levelManager');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('rank').setDescription("View a user's rank and XP")
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),
  async execute(interaction) {
    const target = interaction.options.getUser('user') ?? interaction.user;
    const data = getUserLevel(interaction.guild.id, target.id);
    if (!data) return interaction.reply({ content: `No level data found for **${target.username}** yet.`, flags: 1 << 6 });

    const nextLevelXP = xpForLevel(data.level + 1);
    const progress = Math.min(data.xp / nextLevelXP, 1);
    const barLen = 20;
    const filled = Math.round(progress * barLen);
    const bar = '█'.repeat(filled) + '░'.repeat(barLen - filled);

    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle(`${target.username}'s Rank`)
      .setThumbnail(target.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: 'Level', value: String(data.level), inline: true },
        { name: 'XP', value: `${data.xp} / ${nextLevelXP}`, inline: true },
        { name: 'Progress', value: `\`[${bar}] ${Math.round(progress * 100)}%\``, inline: false },
      )
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
