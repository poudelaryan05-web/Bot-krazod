const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getDB } = require('../../database/db');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('leaderboard').setDescription('View the XP leaderboard for this server'),
  async execute(interaction) {
    await interaction.deferReply();
    const rows = getDB().prepare('SELECT user_id, xp, level FROM levels WHERE guild_id = ? ORDER BY level DESC, xp DESC LIMIT 10').all(interaction.guild.id);

    if (rows.length === 0) return interaction.editReply({ content: 'No leveling data yet. Start chatting to earn XP!' });

    const MEDALS = ['🥇', '🥈', '🥉'];
    const lines = await Promise.all(rows.map(async (row, i) => {
      const user = await interaction.client.users.fetch(row.user_id).catch(() => null);
      const name = user ? user.username : `Unknown (${row.user_id})`;
      const prefix = MEDALS[i] ?? `**${i + 1}.**`;
      return `${prefix} ${name} — Level ${row.level} (${row.xp} XP)`;
    }));

    const embed = new EmbedBuilder()
      .setColor(COLORS.primary)
      .setTitle(`${interaction.guild.name} — Leaderboard`)
      .setDescription(lines.join('\n'))
      .setFooter({ text: 'Top 10 members by XP • Krazod Hub' })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};
