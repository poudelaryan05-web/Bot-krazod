const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getConfig, deleteConfig, getAllLevelRewards } = require('../../database/db');
const { successEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('levels')
    .setDescription('Manage the leveling system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup').setDescription('Configure the leveling system'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable the leveling system')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'disable') {
      deleteConfig(interaction.guild.id, 'levels');
      return interaction.reply({ embeds: [successEmbed('Leveling system disabled.')], flags: 1 << 6 });
    }

    // ── setup ──────────────────────────────────────────────────────────────
    const current = getConfig(interaction.guild.id, 'levels') ?? {};

    // Count configured level rewards from the dedicated table (not from guild_configs)
    const rewards = getAllLevelRewards(interaction.guild.id);

    const embed = infoEmbed(
      `**Leveling Setup**\n\n` +
      `Configure XP and level-up notifications.\n\n` +
      `**Current Settings:**\n` +
      `Status: ${current.enabled ? '🟢 Enabled' : '🔴 Disabled'}\n` +
      `Level-up Channel: ${current.levelUpChannelId ? `<#${current.levelUpChannelId}>` : 'Same channel as message'}\n` +
      `Level Roles: ${rewards.length > 0 ? `${rewards.length} configured` : 'None'}\n\n` +
      `Use the buttons below to configure.\n` +
      `Use \`/levelrewards set\` to assign roles for reaching specific levels.`,
      'Levels Setup',
    );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('setup:levels:channel').setLabel('Level-Up Channel').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('setup:levels:save').setLabel('Enable Leveling').setStyle(ButtonStyle.Success),
    );

    await interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },
};
