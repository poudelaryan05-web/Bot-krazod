'use strict';
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { setLevelReward, removeLevelReward, getAllLevelRewards, getLevelReward } = require('../../database/db');
const { successEmbed, errorEmbed, infoEmbed, COLORS } = require('../../utils/embeds');

// ── Build the main management embed + buttons ─────────────────────────────────
function buildManagementEmbed(guild) {
  const rewards = getAllLevelRewards(guild.id);

  let description = 'Configure role rewards that are automatically assigned when members reach a level.\n\n';

  if (!rewards.length) {
    description += '**Configured Rewards:** None\n\nUse the buttons below to add your first level reward.';
  } else {
    description += `**Configured Rewards (${rewards.length}):**\n`;
    for (const r of rewards) {
      const role = guild.roles.cache.get(r.role_id);
      const roleName = role ? `<@&${r.role_id}>` : `~~Deleted Role (${r.role_id})~~`;
      description += `• **Level ${r.level}** → ${roleName}\n`;
    }
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle('Level Rewards — Management')
    .setDescription(description)
    .setFooter({ text: `${guild.name} • Krazod Hub Leveling` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('levelrewards:add')
      .setLabel('Add Reward')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('levelrewards:edit')
      .setLabel('Edit Reward')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(!rewards.length),
    new ButtonBuilder()
      .setCustomId('levelrewards:remove')
      .setLabel('Remove Reward')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(!rewards.length),
  );

  return { embed, row };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('levelrewards')
    .setDescription('View and manage role rewards for reaching specific levels')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    await interaction.guild.roles.fetch().catch(() => {});
    const { embed, row } = buildManagementEmbed(interaction.guild);
    return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },

  // ── Exported so index.js can delegate button/modal interactions ──────────────
  async handleInteraction(interaction) {
    const { customId } = interaction;
    const guild = interaction.guild;

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ embeds: [errorEmbed('You need the **Manage Server** permission.')], flags: 1 << 6 });
    }

    // ── Add Reward ────────────────────────────────────────────────────────────
    if (customId === 'levelrewards:add') {
      const modal = new ModalBuilder()
        .setCustomId('levelrewards:modal:add')
        .setTitle('Add Level Reward');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('level')
            .setLabel('Level (1–500)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('e.g. 10')
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(3),
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('role_id')
            .setLabel('Role ID')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Right-click a role → Copy ID')
            .setRequired(true)
            .setMinLength(17)
            .setMaxLength(20),
        ),
      );

      return interaction.showModal(modal);
    }

    // ── Edit Reward ───────────────────────────────────────────────────────────
    if (customId === 'levelrewards:edit') {
      const modal = new ModalBuilder()
        .setCustomId('levelrewards:modal:edit')
        .setTitle('Edit Level Reward');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('level')
            .setLabel('Level to edit')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Enter the level number')
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(3),
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('new_role_id')
            .setLabel('New Role ID')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Right-click a role → Copy ID')
            .setRequired(true)
            .setMinLength(17)
            .setMaxLength(20),
        ),
      );

      return interaction.showModal(modal);
    }

    // ── Remove Reward ─────────────────────────────────────────────────────────
    if (customId === 'levelrewards:remove') {
      const modal = new ModalBuilder()
        .setCustomId('levelrewards:modal:remove')
        .setTitle('Remove Level Reward');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('level')
            .setLabel('Level to remove reward from')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Enter the level number')
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(3),
        ),
      );

      return interaction.showModal(modal);
    }

    // ── Modal: Add ────────────────────────────────────────────────────────────
    if (customId === 'levelrewards:modal:add') {
      const levelRaw  = interaction.fields.getTextInputValue('level').trim();
      const roleIdRaw = interaction.fields.getTextInputValue('role_id').trim();

      const level = parseInt(levelRaw, 10);
      if (isNaN(level) || level < 1 || level > 500) {
        return interaction.reply({ embeds: [errorEmbed('Level must be a number between 1 and 500.')], flags: 1 << 6 });
      }

      await guild.roles.fetch().catch(() => {});
      const role = guild.roles.cache.get(roleIdRaw);
      if (!role) {
        return interaction.reply({ embeds: [errorEmbed(`Role with ID \`${roleIdRaw}\` was not found in this server.`)], flags: 1 << 6 });
      }

      const botMember = guild.members.me;
      if (botMember.roles.highest.comparePositionTo(role) <= 0) {
        return interaction.reply({
          embeds: [errorEmbed(`My role must be above **${role.name}** in the role hierarchy to assign it to members.`)],
          flags: 1 << 6,
        });
      }

      setLevelReward(guild.id, level, role.id);

      const { embed, row } = buildManagementEmbed(guild);
      embed.setDescription(embed.data.description + `\n\nAdded: **Level ${level}** → <@&${role.id}>`);
      return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
    }

    // ── Modal: Edit ───────────────────────────────────────────────────────────
    if (customId === 'levelrewards:modal:edit') {
      const levelRaw     = interaction.fields.getTextInputValue('level').trim();
      const newRoleIdRaw = interaction.fields.getTextInputValue('new_role_id').trim();

      const level = parseInt(levelRaw, 10);
      if (isNaN(level) || level < 1 || level > 500) {
        return interaction.reply({ embeds: [errorEmbed('Level must be a number between 1 and 500.')], flags: 1 << 6 });
      }

      const existing = getLevelReward(guild.id, level);
      if (!existing) {
        return interaction.reply({ embeds: [errorEmbed(`No reward configured for Level ${level}. Use "Add Reward" to create one.`)], flags: 1 << 6 });
      }

      await guild.roles.fetch().catch(() => {});
      const newRole = guild.roles.cache.get(newRoleIdRaw);
      if (!newRole) {
        return interaction.reply({ embeds: [errorEmbed(`Role with ID \`${newRoleIdRaw}\` was not found in this server.`)], flags: 1 << 6 });
      }

      const botMember = guild.members.me;
      if (botMember.roles.highest.comparePositionTo(newRole) <= 0) {
        return interaction.reply({
          embeds: [errorEmbed(`My role must be above **${newRole.name}** in the role hierarchy to assign it to members.`)],
          flags: 1 << 6,
        });
      }

      setLevelReward(guild.id, level, newRole.id);

      const { embed, row } = buildManagementEmbed(guild);
      embed.setDescription(embed.data.description + `\n\nUpdated: **Level ${level}** now rewards <@&${newRole.id}>`);
      return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
    }

    // ── Modal: Remove ─────────────────────────────────────────────────────────
    if (customId === 'levelrewards:modal:remove') {
      const levelRaw = interaction.fields.getTextInputValue('level').trim();
      const level    = parseInt(levelRaw, 10);

      if (isNaN(level) || level < 1 || level > 500) {
        return interaction.reply({ embeds: [errorEmbed('Level must be a number between 1 and 500.')], flags: 1 << 6 });
      }

      const result = removeLevelReward(guild.id, level);
      if (result.changes === 0) {
        return interaction.reply({ embeds: [errorEmbed(`No reward was configured for Level ${level}.`)], flags: 1 << 6 });
      }

      const { embed, row } = buildManagementEmbed(guild);
      embed.setDescription(embed.data.description + `\n\nRemoved reward for **Level ${level}**.`);
      return interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
    }
  },
};
