const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getConfig, setConfig, deleteConfig } = require('../../database/db');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Manage the ticket system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup').setDescription('Set up the ticket system'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable the ticket system')),

  async execute(interaction) {
    // Guard: slash commands can arrive without a guild context (e.g. DMs).
    // Without this check, interaction.guild.id throws and crashes the bot.
    if (!interaction.guild) {
      return interaction.reply({
        embeds: [errorEmbed('This command can only be used inside a server.')],
        flags: 1 << 6,
      });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'disable') {
      deleteConfig(interaction.guild.id, 'tickets');
      return interaction.reply({ embeds: [successEmbed('Ticket system has been disabled.')], flags: 1 << 6 });
    }

    const current = getConfig(interaction.guild.id, 'tickets') ?? {};
    const embed = infoEmbed(
      `**Ticket System Setup**\n\n` +
      `Create private support channels for members.\n\n` +
      `**Current Settings:**\n` +
      `Panel Channel: ${current.panelChannelId ? `<#${current.panelChannelId}>` : 'Not set'}\n` +
      `Category: ${current.categoryId ? `<#${current.categoryId}>` : 'Not set'}\n` +
      `Support Role: ${current.supportRoleId ? `<@&${current.supportRoleId}>` : 'Not set'}`,
      'Ticket Setup'
    );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('setup:tickets:panel_channel').setLabel('Panel Channel').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('setup:tickets:category').setLabel('Category').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('setup:tickets:support_role').setLabel('Support Role').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('setup:tickets:send_panel').setLabel('Send Panel').setStyle(ButtonStyle.Success),
    );

    await interaction.reply({ embeds: [embed], components: [row], flags: 1 << 6 });
  },
};
