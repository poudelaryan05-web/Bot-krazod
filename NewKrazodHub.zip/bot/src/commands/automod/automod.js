'use strict';
const {
  SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder,
} = require('discord.js');
const { getConfig, setConfig, deleteConfig } = require('../../database/db');
const { successEmbed, errorEmbed, infoEmbed, COLORS } = require('../../utils/embeds');

const ACTION_OPTIONS = [
  { label: 'Delete — Remove the message only',  value: 'delete'  },
  { label: 'Warn — Add a warning to the member', value: 'warn'    },
  { label: 'Timeout — Mute for 5 minutes',       value: 'timeout' },
  { label: 'Kick — Remove from the server',      value: 'kick'    },
  { label: 'Ban — Permanent ban',               value: 'ban'     },
];

function buildStatusEmbed(config, guildId) {
  const on  = (v) => v ? '**On**' : 'Off';
  const act = (v) => v ? `\`${v}\``   : '`delete`';

  return new EmbedBuilder()
    .setColor(config?.enabled ? COLORS.success : COLORS.muted)
    .setTitle('AutoMod Configuration')
    .setDescription(config?.enabled ? 'AutoMod is **enabled**.' : 'AutoMod is **disabled**.')
    .addFields(
      { name: 'Anti-Spam',          value: `${on(config?.antiSpam)} — Action: ${act(config?.antiSpamAction)}`,          inline: false },
      { name: 'Anti-Mention Spam',  value: `${on(config?.antiMentionSpam)} — Max mentions: ${config?.maxMentions ?? 5} — Action: ${act(config?.antiMentionSpamAction)}`, inline: false },
      { name: 'Anti-Caps',          value: `${on(config?.antiCaps)} — Action: ${act(config?.antiCapsAction)}`,           inline: false },
      { name: 'Anti-Invites',       value: `${on(config?.antiInvites)} — Action: ${act(config?.antiInvitesAction)}`,     inline: false },
      { name: 'Anti-Links',         value: `${on(config?.antiLinks)} — Action: ${act(config?.antiLinksAction)}`,         inline: false },
      { name: 'Bad Words Filter',   value: `${on(config?.badWords)} — Action: ${act(config?.badWordsAction)}`,           inline: false },
    )
    .setFooter({ text: 'Krazod Hub AutoMod' })
    .setTimestamp();
}

function buildSetupRow(config) {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('automod:toggle:antiSpam')
      .setLabel(config?.antiSpam ? 'Anti-Spam ON' : 'Anti-Spam OFF')
      .setStyle(config?.antiSpam ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('automod:toggle:antiMentionSpam')
      .setLabel(config?.antiMentionSpam ? 'Anti-Mention ON' : 'Anti-Mention OFF')
      .setStyle(config?.antiMentionSpam ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('automod:toggle:antiCaps')
      .setLabel(config?.antiCaps ? 'Anti-Caps ON' : 'Anti-Caps OFF')
      .setStyle(config?.antiCaps ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('automod:toggle:antiInvites')
      .setLabel(config?.antiInvites ? 'Anti-Invites ON' : 'Anti-Invites OFF')
      .setStyle(config?.antiInvites ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('automod:toggle:antiLinks')
      .setLabel(config?.antiLinks ? 'Anti-Links ON' : 'Anti-Links OFF')
      .setStyle(config?.antiLinks ? ButtonStyle.Success : ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('automod:toggle:badWords')
      .setLabel(config?.badWords ? 'Bad Words ON' : 'Bad Words OFF')
      .setStyle(config?.badWords ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('automod:toggle:enabled')
      .setLabel(config?.enabled ? 'Disable AutoMod' : 'Enable AutoMod')
      .setStyle(config?.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
  );

  return [row1, row2];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Automated message moderation system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)

    .addSubcommand(s => s
      .setName('setup')
      .setDescription('Configure AutoMod rules and actions'))

    .addSubcommand(s => s
      .setName('status')
      .setDescription('View current AutoMod configuration'))

    .addSubcommand(s => s
      .setName('badwords')
      .setDescription('Manage the blocked words list')
      .addStringOption(o => o
        .setName('action')
        .setDescription('What to do')
        .setRequired(true)
        .addChoices(
          { name: 'add',   value: 'add'   },
          { name: 'remove', value: 'remove' },
          { name: 'list',  value: 'list'  },
          { name: 'clear', value: 'clear' },
        ))
      .addStringOption(o => o
        .setName('word')
        .setDescription('The word to add or remove')
        .setRequired(false)))

    .addSubcommand(s => s
      .setName('whitelist')
      .setDescription('Manage link whitelist (domains that are always allowed)')
      .addStringOption(o => o
        .setName('action')
        .setDescription('What to do')
        .setRequired(true)
        .addChoices(
          { name: 'add',   value: 'add'   },
          { name: 'remove', value: 'remove' },
          { name: 'list',  value: 'list'  },
        ))
      .addStringOption(o => o
        .setName('domain')
        .setDescription('Domain to add/remove (e.g. youtube.com)')
        .setRequired(false)))

    .addSubcommand(s => s
      .setName('disable')
      .setDescription('Disable AutoMod')),

  async execute(interaction) {
    const sub     = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    // ── disable ──────────────────────────────────────────────────────────────
    if (sub === 'disable') {
      deleteConfig(guildId, 'automod');
      return interaction.reply({
        embeds: [successEmbed('AutoMod has been disabled and all configuration cleared.')],
        flags: 1 << 6,
      });
    }

    // ── status ───────────────────────────────────────────────────────────────
    if (sub === 'status') {
      const config = getConfig(guildId, 'automod');
      return interaction.reply({ embeds: [buildStatusEmbed(config, guildId)], flags: 1 << 6 });
    }

    // ── badwords ─────────────────────────────────────────────────────────────
    if (sub === 'badwords') {
      const action = interaction.options.getString('action');
      const word   = interaction.options.getString('word')?.toLowerCase().trim();
      const config = getConfig(guildId, 'automod') ?? {};
      let words    = JSON.parse(config.badWordsList ?? '[]');

      if (action === 'list') {
        if (!words.length) return interaction.reply({ embeds: [infoEmbed('The bad words list is currently empty.', 'Bad Words List')], flags: 1 << 6 });
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('🤬 Bad Words List')
            .setDescription(`||${words.join('||, ||')}||`)
            .setFooter({ text: `${words.length} word${words.length !== 1 ? 's' : ''}` })],
          flags: 1 << 6,
        });
      }

      if (action === 'clear') {
        setConfig(guildId, 'automod', { ...config, badWordsList: '[]', badWords: false });
        return interaction.reply({ embeds: [successEmbed('Bad words list cleared.')], flags: 1 << 6 });
      }

      if (!word) return interaction.reply({ embeds: [errorEmbed('Please provide a word.')], flags: 1 << 6 });

      if (action === 'add') {
        if (words.includes(word)) return interaction.reply({ embeds: [errorEmbed(`\`${word}\` is already in the list.`)], flags: 1 << 6 });
        words.push(word);
        setConfig(guildId, 'automod', { ...config, badWordsList: JSON.stringify(words) });
        return interaction.reply({ embeds: [successEmbed(`Added \`${word}\` to the bad words list.`)], flags: 1 << 6 });
      }

      if (action === 'remove') {
        const before = words.length;
        words = words.filter(w => w !== word);
        if (words.length === before) return interaction.reply({ embeds: [errorEmbed(`\`${word}\` was not found in the list.`)], flags: 1 << 6 });
        setConfig(guildId, 'automod', { ...config, badWordsList: JSON.stringify(words) });
        return interaction.reply({ embeds: [successEmbed(`Removed \`${word}\` from the bad words list.`)], flags: 1 << 6 });
      }
    }

    // ── whitelist ────────────────────────────────────────────────────────────
    if (sub === 'whitelist') {
      const action = interaction.options.getString('action');
      const domain = interaction.options.getString('domain')?.toLowerCase().trim();
      const config = getConfig(guildId, 'automod') ?? {};
      let domains  = JSON.parse(config.linkWhitelist ?? '[]');

      if (action === 'list') {
        if (!domains.length) return interaction.reply({ embeds: [infoEmbed('The link whitelist is currently empty.', 'Link Whitelist')], flags: 1 << 6 });
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.primary)
            .setTitle('Link Whitelist')
            .setDescription(domains.map(d => `\`${d}\``).join('\n'))
            .setFooter({ text: `${domains.length} domain${domains.length !== 1 ? 's' : ''}` })],
          flags: 1 << 6,
        });
      }

      if (!domain) return interaction.reply({ embeds: [errorEmbed('Please provide a domain.')], flags: 1 << 6 });

      if (action === 'add') {
        if (domains.includes(domain)) return interaction.reply({ embeds: [errorEmbed(`\`${domain}\` is already whitelisted.`)], flags: 1 << 6 });
        domains.push(domain);
        setConfig(guildId, 'automod', { ...config, linkWhitelist: JSON.stringify(domains) });
        return interaction.reply({ embeds: [successEmbed(`Added \`${domain}\` to the link whitelist.`)], flags: 1 << 6 });
      }

      if (action === 'remove') {
        const before = domains.length;
        domains = domains.filter(d => d !== domain);
        if (domains.length === before) return interaction.reply({ embeds: [errorEmbed(`\`${domain}\` was not found in the whitelist.`)], flags: 1 << 6 });
        setConfig(guildId, 'automod', { ...config, linkWhitelist: JSON.stringify(domains) });
        return interaction.reply({ embeds: [successEmbed(`Removed \`${domain}\` from the link whitelist.`)], flags: 1 << 6 });
      }
    }

    // ── setup ────────────────────────────────────────────────────────────────
    const config = getConfig(guildId, 'automod') ?? {};
    const embed  = buildStatusEmbed(config, guildId);
    const rows   = buildSetupRow(config);

    return interaction.reply({ embeds: [embed], components: rows, flags: 1 << 6 });
  },
};
