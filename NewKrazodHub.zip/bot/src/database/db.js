'use strict';
/**
 * db.js — SQLite database layer (better-sqlite3)
 */

const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');
const logger   = require('../utils/logger');

let db;

// ── SQLITE_FULL error detection ───────────────────────────────────────────────
const DISK_FULL_CODES    = new Set([13, 522, 778]);
const DISK_FULL_MESSAGES = ['database or disk is full', 'disk i/o error', 'no space left'];

function isDiskFull(err) {
  if (!err) return false;
  const msg = (err.message || '').toLowerCase();
  if (DISK_FULL_MESSAGES.some(m => msg.includes(m))) return true;
  if (err.code && DISK_FULL_CODES.has(Number(err.code))) return true;
  return false;
}

function handleDiskFull(err) {
  logger.error(
    '━━━ DISK FULL / QUOTA EXCEEDED ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
    '  SQLite cannot write: ' + err.message + '\n' +
    '  Possible causes:\n' +
    '    • Hosting platform disk quota reached (check your plan limits)\n' +
    '    • The SQLite WAL file (krazodhub.db-wal) has grown too large\n' +
    '    • Old data in the warnings/giveaways tables is consuming space\n' +
    '  Attempting automatic recovery (WAL checkpoint + incremental vacuum)…\n' +
    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
  );
  try {
    if (db) {
      db.pragma('wal_checkpoint(TRUNCATE)');
      db.pragma('incremental_vacuum(1000)');
      logger.info('Disk-full recovery: WAL checkpointed and incremental vacuum completed.');
      return true;
    }
  } catch (e2) {
    logger.error('Disk-full recovery attempt also failed:', e2.message);
  }
  return false;
}

// ── initDB ────────────────────────────────────────────────────────────────────
function initDB() {
  const dbPath = process.env.DB_PATH || './data/krazodhub.db';
  const dir    = path.dirname(dbPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  try {
    db = new Database(dbPath);
  } catch (err) {
    if (isDiskFull(err)) {
      logger.error(
        'FATAL: Cannot open SQLite database — disk is full.\n' +
        '  Free up disk space or increase your hosting quota, then restart the bot.\n' +
        '  Database path: ' + dbPath
      );
      process.exit(1);
    }
    throw err;
  }

  db.pragma('temp_store = MEMORY');
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('wal_autocheckpoint = 100');
  db.pragma('journal_size_limit = 67108864');

  try {
    db.pragma('wal_checkpoint(TRUNCATE)');
    logger.info('SQLite WAL checkpointed and truncated on startup.');
  } catch (err) {
    logger.warn('WAL checkpoint on startup failed (non-fatal):', err.message);
  }

  try {
    const current = db.pragma('auto_vacuum', { simple: true });
    if (current === 0) {
      logger.info('SQLite: enabling incremental auto_vacuum (one-time VACUUM, may take a moment)…');
      db.pragma('auto_vacuum = INCREMENTAL');
      db.exec('VACUUM');
      logger.info('SQLite: incremental auto_vacuum enabled.');
    }
  } catch (err) {
    logger.warn('Could not enable incremental auto_vacuum (non-fatal):', err.message);
  }

  createTables();
  logger.info(`SQLite database connected: ${dbPath}`);

  try {
    const stat = fs.statSync(dbPath);
    const walPath = dbPath + '-wal';
    const walSize = fs.existsSync(walPath) ? fs.statSync(walPath).size : 0;
    const totalMB = ((stat.size + walSize) / 1048576).toFixed(2);
    logger.info(`Database size: ${(stat.size / 1048576).toFixed(2)} MB  |  WAL: ${(walSize / 1048576).toFixed(2)} MB  |  Total: ${totalMB} MB`);
  } catch { /* non-fatal */ }
}

// ── createTables ──────────────────────────────────────────────────────────────
function createTables() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS guild_configs (
      guild_id TEXT NOT NULL,
      module TEXT NOT NULL,
      config TEXT NOT NULL DEFAULT '{}',
      PRIMARY KEY (guild_id, module)
    );

    CREATE TABLE IF NOT EXISTS warnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      moderator_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      timestamp INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      claimed_by TEXT,
      transcript TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS giveaways (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      message_id TEXT NOT NULL,
      prize TEXT NOT NULL,
      winner_count INTEGER NOT NULL DEFAULT 1,
      end_time INTEGER NOT NULL,
      required_role TEXT,
      entries TEXT NOT NULL DEFAULT '[]',
      ended INTEGER NOT NULL DEFAULT 0,
      winners TEXT NOT NULL DEFAULT '[]'
    );

    CREATE TABLE IF NOT EXISTS levels (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      xp INTEGER NOT NULL DEFAULT 0,
      level INTEGER NOT NULL DEFAULT 0,
      last_message INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (guild_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS afk (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      reason TEXT NOT NULL DEFAULT 'AFK',
      timestamp INTEGER NOT NULL,
      PRIMARY KEY (guild_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS reminders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      guild_id TEXT NOT NULL,
      message TEXT NOT NULL,
      remind_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reaction_roles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      message_id TEXT NOT NULL,
      emoji TEXT NOT NULL,
      role_id TEXT NOT NULL,
      UNIQUE(guild_id, message_id, emoji)
    );

    CREATE TABLE IF NOT EXISTS level_rewards (
      guild_id TEXT NOT NULL,
      level INTEGER NOT NULL,
      role_id TEXT NOT NULL,
      PRIMARY KEY (guild_id, level)
    );

    CREATE TABLE IF NOT EXISTS autoresponders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      trigger TEXT NOT NULL,
      response TEXT NOT NULL,
      UNIQUE(guild_id, trigger)
    );

    -- Indexes to speed up frequent lookups and reduce I/O
    CREATE INDEX IF NOT EXISTS idx_warnings_guild        ON warnings (guild_id);
    CREATE INDEX IF NOT EXISTS idx_warnings_user         ON warnings (guild_id, user_id);
    CREATE INDEX IF NOT EXISTS idx_tickets_guild         ON tickets (guild_id, status);
    CREATE INDEX IF NOT EXISTS idx_giveaways_active      ON giveaways (ended, end_time);
    CREATE INDEX IF NOT EXISTS idx_reminders_time        ON reminders (remind_at);
    CREATE INDEX IF NOT EXISTS idx_autoresponders_guild  ON autoresponders (guild_id);
  `);
}

// ── getDB ─────────────────────────────────────────────────────────────────────
function getDB() {
  if (!db) throw new Error('Database not initialized. Call initDB() first.');
  return db;
}

// ── Config helpers ─────────────────────────────────────────────────────────────
function getConfig(guildId, module) {
  const row = getDB().prepare('SELECT config FROM guild_configs WHERE guild_id = ? AND module = ?').get(guildId, module);
  return row ? JSON.parse(row.config) : null;
}

function setConfig(guildId, module, config) {
  try {
    getDB().prepare(`
      INSERT INTO guild_configs (guild_id, module, config)
      VALUES (?, ?, ?)
      ON CONFLICT(guild_id, module) DO UPDATE SET config = excluded.config
    `).run(guildId, module, JSON.stringify(config));
  } catch (err) {
    if (isDiskFull(err)) {
      handleDiskFull(err);
    }
    throw err;
  }
}

function deleteConfig(guildId, module) {
  getDB().prepare('DELETE FROM guild_configs WHERE guild_id = ? AND module = ?').run(guildId, module);
}

// ── Reaction Role Helpers ─────────────────────────────────────────────────────
function addReactionRole(guildId, channelId, messageId, emoji, roleId) {
  getDB().prepare(`
    INSERT INTO reaction_roles (guild_id, channel_id, message_id, emoji, role_id)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(guild_id, message_id, emoji) DO UPDATE SET role_id = excluded.role_id, channel_id = excluded.channel_id
  `).run(guildId, channelId, messageId, emoji, roleId);
}

function removeReactionRole(guildId, messageId, emoji) {
  return getDB().prepare('DELETE FROM reaction_roles WHERE guild_id = ? AND message_id = ? AND emoji = ?').run(guildId, messageId, emoji);
}

function getReactionRole(guildId, messageId, emoji) {
  return getDB().prepare('SELECT * FROM reaction_roles WHERE guild_id = ? AND message_id = ? AND emoji = ?').get(guildId, messageId, emoji);
}

function getReactionRolesForMessage(guildId, messageId) {
  return getDB().prepare('SELECT * FROM reaction_roles WHERE guild_id = ? AND message_id = ?').all(guildId, messageId);
}

function getAllReactionRoles(guildId) {
  return getDB().prepare('SELECT * FROM reaction_roles WHERE guild_id = ? ORDER BY message_id, emoji').all(guildId);
}

// ── Level Reward Helpers ──────────────────────────────────────────────────────
function setLevelReward(guildId, level, roleId) {
  getDB().prepare(`
    INSERT INTO level_rewards (guild_id, level, role_id)
    VALUES (?, ?, ?)
    ON CONFLICT(guild_id, level) DO UPDATE SET role_id = excluded.role_id
  `).run(guildId, level, roleId);
}

function removeLevelReward(guildId, level) {
  return getDB().prepare('DELETE FROM level_rewards WHERE guild_id = ? AND level = ?').run(guildId, level);
}

function getLevelReward(guildId, level) {
  return getDB().prepare('SELECT * FROM level_rewards WHERE guild_id = ? AND level = ?').get(guildId, level);
}

function getAllLevelRewards(guildId) {
  return getDB().prepare('SELECT * FROM level_rewards WHERE guild_id = ? ORDER BY level ASC').all(guildId);
}

// ── Autoresponder Helpers ─────────────────────────────────────────────────────
function addAutoresponder(guildId, trigger, response) {
  getDB().prepare(`
    INSERT INTO autoresponders (guild_id, trigger, response)
    VALUES (?, ?, ?)
    ON CONFLICT(guild_id, trigger) DO UPDATE SET response = excluded.response
  `).run(guildId, trigger.toLowerCase(), response);
}

function removeAutoresponder(guildId, trigger) {
  return getDB().prepare('DELETE FROM autoresponders WHERE guild_id = ? AND trigger = ?').run(guildId, trigger.toLowerCase());
}

function getAutoresponder(guildId, trigger) {
  return getDB().prepare('SELECT * FROM autoresponders WHERE guild_id = ? AND trigger = ?').get(guildId, trigger.toLowerCase());
}

function getAllAutoresponders(guildId) {
  return getDB().prepare('SELECT * FROM autoresponders WHERE guild_id = ? ORDER BY trigger ASC').all(guildId);
}

// ── Periodic maintenance ──────────────────────────────────────────────────────
function performMaintenance() {
  if (!db) return;

  try {
    db.pragma('wal_checkpoint(TRUNCATE)');
    db.pragma('incremental_vacuum(1000)');

    const cutoff30d = Date.now() - 30 * 24 * 60 * 60 * 1000;
    const cutoff90d = Date.now() - 90 * 24 * 60 * 60 * 1000;

    const prune = db.transaction(() => {
      const ga = db.prepare('DELETE FROM giveaways WHERE ended = 1 AND end_time < ?').run(cutoff30d);
      const wa = db.prepare('DELETE FROM warnings WHERE timestamp < ?').run(cutoff90d);
      const ti = db.prepare("DELETE FROM tickets WHERE status != 'open' AND created_at < ?").run(cutoff30d);
      return { giveaways: ga.changes, warnings: wa.changes, tickets: ti.changes };
    });

    const pruned = prune();

    const dbPath   = process.env.DB_PATH || './data/krazodhub.db';
    const walPath  = dbPath + '-wal';
    const dbSize   = fs.existsSync(dbPath)  ? fs.statSync(dbPath).size  : 0;
    const walSize  = fs.existsSync(walPath) ? fs.statSync(walPath).size : 0;
    const totalMB  = ((dbSize + walSize) / 1048576).toFixed(2);

    logger.info(
      `DB maintenance complete — ` +
      `pruned: ${pruned.giveaways} giveaways, ${pruned.warnings} warnings, ${pruned.tickets} tickets | ` +
      `DB: ${(dbSize / 1048576).toFixed(2)} MB  WAL: ${(walSize / 1048576).toFixed(2)} MB  Total: ${totalMB} MB`
    );
  } catch (err) {
    if (isDiskFull(err)) {
      handleDiskFull(err);
    } else {
      logger.error('DB maintenance error (non-fatal):', err.message);
    }
  }
}

function startMaintenanceScheduler() {
  performMaintenance();
  setInterval(performMaintenance, 6 * 60 * 60 * 1000);
  logger.info('DB maintenance scheduler started (runs every 6 hours).');
}

module.exports = {
  initDB,
  getDB,
  getConfig,
  setConfig,
  deleteConfig,
  addReactionRole,
  removeReactionRole,
  getReactionRole,
  getReactionRolesForMessage,
  getAllReactionRoles,
  setLevelReward,
  removeLevelReward,
  getLevelReward,
  getAllLevelRewards,
  addAutoresponder,
  removeAutoresponder,
  getAutoresponder,
  getAllAutoresponders,
  performMaintenance,
  startMaintenanceScheduler,
  isDiskFull,
  handleDiskFull,
};
