'use strict';
const { EmbedBuilder } = require('discord.js');

const COLORS = {
  primary: '#5865F2',   // Discord blurple
  success: '#57F287',   // Discord green
  error:   '#ED4245',   // Discord red
  warning: '#FEE75C',   // Discord yellow
  muted:   '#36393F',   // Dark grey
  red:     '#ED4245',   // Alias for error
};

/**
 * @param {string} description
 * @returns {EmbedBuilder}
 */
function successEmbed(description) {
  return new EmbedBuilder()
    .setColor(COLORS.success)
    .setDescription(description)
    .setTimestamp();
}

/**
 * @param {string} description
 * @returns {EmbedBuilder}
 */
function errorEmbed(description) {
  return new EmbedBuilder()
    .setColor(COLORS.error)
    .setDescription(description)
    .setTimestamp();
}

/**
 * @param {string} description
 * @param {string} [title]
 * @returns {EmbedBuilder}
 */
function infoEmbed(description, title) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setDescription(description)
    .setTimestamp();
  if (title) embed.setTitle(title);
  return embed;
}

/**
 * @param {string} description
 * @returns {EmbedBuilder}
 */
function warningEmbed(description) {
  return new EmbedBuilder()
    .setColor(COLORS.warning)
    .setDescription(description)
    .setTimestamp();
}

module.exports = { COLORS, successEmbed, errorEmbed, infoEmbed, warningEmbed };
