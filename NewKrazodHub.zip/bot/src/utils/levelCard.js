'use strict';
/**
 * levelCard.js
 *
 * Generates a level-up card image (700×200 px) as a PNG Buffer using the
 * `canvas` package (Cairo-backed, already in package.json).
 *
 * Exported: buildLevelCard({ username, avatarURL, level, currentXP, requiredXP })
 */

const { createCanvas, loadImage } = require('canvas');

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Safe rounded-rectangle path — avoids relying on ctx.roundRect() availability. */
function tracePill(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y,     x + w, y + rr);
  ctx.lineTo(x + w,     y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr,   y + h);
  ctx.quadraticCurveTo(x,     y + h, x,           y + h - rr);
  ctx.lineTo(x,         y + rr);
  ctx.quadraticCurveTo(x,     y,     x + rr,       y);
  ctx.closePath();
}

/** Draw a circular avatar (clip + optional fallback). */
async function drawAvatar(ctx, url, x, y, diameter) {
  const r = diameter / 2;
  const cx = x + r;
  const cy = y + r;

  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();

  try {
    const img = await loadImage(url);
    ctx.drawImage(img, x, y, diameter, diameter);
  } catch {
    ctx.fillStyle = '#2d2d3d';
    ctx.fill();
  }

  ctx.restore();
}

/** Draw a ring around the avatar. */
function drawAvatarRing(ctx, x, y, diameter, color, lineWidth = 3) {
  const r = diameter / 2;
  ctx.beginPath();
  ctx.arc(x + r, y + r, r + lineWidth / 2 + 1, 0, Math.PI * 2);
  ctx.strokeStyle = color;
  ctx.lineWidth = lineWidth;
  ctx.stroke();
}

// ─── Main export ──────────────────────────────────────────────────────────────

/**
 * @param {object} opts
 * @param {string} opts.username    - Member display name
 * @param {string} opts.avatarURL   - Full avatar URL (PNG preferred)
 * @param {number} opts.level       - Level just reached
 * @param {number} opts.currentXP   - XP accumulated inside the new level
 * @param {number} opts.requiredXP  - XP required to reach the next level
 * @returns {Promise<Buffer>}       - PNG buffer ready to attach to a message
 */
async function buildLevelCard({ username, avatarURL, level, currentXP, requiredXP }) {
  const W = 700;
  const H = 200;
  const ACCENT      = '#ed4245';   // Krazod Hub red
  const ACCENT2     = '#a855f7';   // purple accent (progress bar tail)
  const BG_DARK     = '#0d1117';
  const BG_MID      = '#161b22';
  const TEXT_PRIMARY   = '#ffffff';
  const TEXT_MUTED     = 'rgba(255,255,255,0.55)';
  const AVATAR_D    = 118;
  const AVATAR_X    = 36;
  const AVATAR_Y    = (H - AVATAR_D) / 2;

  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext('2d');

  // ── 1. Background ───────────────────────────────────────────────────────────
  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0,   BG_DARK);
  bgGrad.addColorStop(0.6, BG_MID);
  bgGrad.addColorStop(1,   '#1a1a2e');
  tracePill(ctx, 0, 0, W, H, 20);
  ctx.fillStyle = bgGrad;
  ctx.fill();

  // Subtle left-side accent stripe
  const stripe = ctx.createLinearGradient(0, 0, 6, 0);
  stripe.addColorStop(0, ACCENT);
  stripe.addColorStop(1, 'transparent');
  ctx.fillStyle = stripe;
  ctx.fillRect(0, 20, 5, H - 40);

  // ── 2. Avatar glow ──────────────────────────────────────────────────────────
  ctx.save();
  ctx.shadowColor  = ACCENT;
  ctx.shadowBlur   = 22;
  ctx.beginPath();
  ctx.arc(AVATAR_X + AVATAR_D / 2, AVATAR_Y + AVATAR_D / 2, AVATAR_D / 2, 0, Math.PI * 2);
  ctx.fillStyle = 'transparent';
  ctx.fill();   // glow-only pass
  ctx.restore();

  // ── 3. Avatar ───────────────────────────────────────────────────────────────
  await drawAvatar(ctx, avatarURL, AVATAR_X, AVATAR_Y, AVATAR_D);
  drawAvatarRing(ctx, AVATAR_X, AVATAR_Y, AVATAR_D, ACCENT, 3);

  // ── 4. Text column ──────────────────────────────────────────────────────────
  const TX = AVATAR_X + AVATAR_D + 28;   // text column left edge
  const TW = W - TX - 30;                // text column width

  // "LEVEL UP!" label
  ctx.font      = 'bold 12px sans-serif';
  ctx.fillStyle = ACCENT;
  ctx.letterSpacing = '2px';
  ctx.fillText('✦  LEVEL UP  ✦', TX, 46);
  ctx.letterSpacing = '0px';

  // Username (truncate if needed)
  ctx.font      = 'bold 26px sans-serif';
  ctx.fillStyle = TEXT_PRIMARY;
  let name = username;
  const maxNameW = TW - 110; // leave room for the level badge
  while (ctx.measureText(name).width > maxNameW && name.length > 2) {
    name = name.slice(0, -1);
  }
  if (name !== username) name += '…';
  ctx.fillText(name, TX, 82);

  // Level badge (right-aligned on the same baseline)
  const lvlLabel = `Level ${level}`;
  ctx.font      = 'bold 20px sans-serif';
  const lvlW    = ctx.measureText(lvlLabel).width + 22;
  const lvlX    = W - 28 - lvlW;
  const lvlY    = 64;

  // Badge pill background
  tracePill(ctx, lvlX, lvlY, lvlW, 26, 13);
  const badgeGrad = ctx.createLinearGradient(lvlX, 0, lvlX + lvlW, 0);
  badgeGrad.addColorStop(0, ACCENT);
  badgeGrad.addColorStop(1, ACCENT2);
  ctx.fillStyle = badgeGrad;
  ctx.fill();

  // Badge text
  ctx.font      = 'bold 14px sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.fillText(lvlLabel, lvlX + lvlW / 2, lvlY + 17);
  ctx.textAlign = 'left';

  // ── 5. Progress bar ─────────────────────────────────────────────────────────
  const BAR_X = TX;
  const BAR_Y = 100;
  const BAR_W = TW;
  const BAR_H = 16;
  const BAR_R = BAR_H / 2;
  const progress = requiredXP > 0 ? Math.min(currentXP / requiredXP, 1) : 0;
  const fillW    = Math.max(BAR_H, BAR_W * progress);   // min = pill height so it stays round

  // Track
  tracePill(ctx, BAR_X, BAR_Y, BAR_W, BAR_H, BAR_R);
  ctx.fillStyle = 'rgba(255,255,255,0.07)';
  ctx.fill();

  // Fill
  if (progress > 0) {
    tracePill(ctx, BAR_X, BAR_Y, fillW, BAR_H, BAR_R);
    const barGrad = ctx.createLinearGradient(BAR_X, 0, BAR_X + BAR_W, 0);
    barGrad.addColorStop(0, ACCENT);
    barGrad.addColorStop(1, ACCENT2);
    ctx.fillStyle = barGrad;
    ctx.fill();
  }

  // Track border
  tracePill(ctx, BAR_X, BAR_Y, BAR_W, BAR_H, BAR_R);
  ctx.strokeStyle = 'rgba(255,255,255,0.1)';
  ctx.lineWidth   = 1;
  ctx.stroke();

  // ── 6. XP labels ────────────────────────────────────────────────────────────
  ctx.font      = '13px sans-serif';
  ctx.fillStyle = TEXT_MUTED;

  ctx.textAlign = 'left';
  ctx.fillText(`${currentXP} / ${requiredXP} XP`, BAR_X, BAR_Y + BAR_H + 22);

  ctx.textAlign = 'right';
  ctx.fillText(`${Math.floor(progress * 100)}%`, BAR_X + BAR_W, BAR_Y + BAR_H + 22);

  // ── 7. Watermark ────────────────────────────────────────────────────────────
  ctx.font      = '10px sans-serif';
  ctx.fillStyle = 'rgba(255,255,255,0.15)';
  ctx.textAlign = 'right';
  ctx.fillText('Krazod Hub', W - 14, H - 10);
  ctx.textAlign = 'left';

  return canvas.toBuffer('image/png');
}

module.exports = { buildLevelCard };
