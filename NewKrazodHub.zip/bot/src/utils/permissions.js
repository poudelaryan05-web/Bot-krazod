'use strict';
const { errorEmbed } = require('./embeds');

/**
 * Check that the interaction member has all required permissions.
 * Sends an ephemeral error reply if not.
 * @param {import('discord.js').ChatInputCommandInteraction} interaction
 * @param {bigint[]} permissions
 * @returns {Promise<boolean>}
 */
async function requirePermissions(interaction, permissions) {
  const missing = permissions.filter(p => !interaction.member.permissions.has(p));
  if (missing.length > 0) {
    await interaction.reply({
      embeds: [errorEmbed('You do not have the required permissions to use this command.')],
      flags: 1 << 6,
    });
    return false;
  }
  return true;
}

/**
 * Verify the bot can act on the target (bot role higher, and executor role higher).
 * Sends an ephemeral error reply if the check fails.
 * @param {import('discord.js').ChatInputCommandInteraction} interaction
 * @param {import('discord.js').GuildMember} target
 * @returns {Promise<boolean>}
 */
async function checkHierarchy(interaction, target) {
  if (target.id === interaction.guild.ownerId) {
    await interaction.reply({
      embeds: [errorEmbed('You cannot perform this action on the server owner.')],
      flags: 1 << 6,
    });
    return false;
  }

  const botMember = interaction.guild.members.me;
  if (botMember.roles.highest.comparePositionTo(target.roles.highest) <= 0) {
    await interaction.reply({
      embeds: [errorEmbed("My highest role is not above the target's highest role. Please move my role higher.")],
      flags: 1 << 6,
    });
    return false;
  }

  if (
    interaction.user.id !== interaction.guild.ownerId &&
    interaction.member.roles.highest.comparePositionTo(target.roles.highest) <= 0
  ) {
    await interaction.reply({
      embeds: [errorEmbed('You cannot perform this action on a member with an equal or higher role than yours.')],
      flags: 1 << 6,
    });
    return false;
  }

  return true;
}

module.exports = { requirePermissions, checkHierarchy };
