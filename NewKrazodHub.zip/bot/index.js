'use strict';
require('dotenv').config();

const {
  Client, Collection, GatewayIntentBits, Partials,
  REST, Routes, Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  AuditLogEvent, ChannelSelectMenuBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const fs   = require('fs');
const path = require('path');

const logger = require('./src/utils/logger');
const { errorEmbed, successEmbed, infoEmbed, COLORS } = require('./src/utils/embeds');

// ─── Bot owner ────────────────────────────────────────────────────────────────
const BOT_OWNER_ID = '1477244673595805726';

// ─── Validate environment ──────────────────────────────────────────────────────
const REQUIRED_ENV = ['DISCORD_TOKEN', 'CLIENT_ID'];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    logger.error(`Missing required environment variable: ${key}`);
    logger.error('Copy .env.example to .env and fill in your values.');
    process.exit(1);
  }
}

// ─── Database ─────────────────────────────────────────────────────────────────
const {
  initDB, getDB, getConfig, setConfig,
  startMaintenanceScheduler, isDiskFull, handleDiskFull,
  getAllAutoresponders,
} = require('./src/database/db');
initDB();

// ─── Managers ─────────────────────────────────────────────────────────────────
const { initSecurityManager }                   = require('./src/managers/securityManager');
const { startGiveawayScheduler,
        buildGiveawayEmbed }                    = require('./src/managers/giveawayManager');
const { startReminderScheduler }                = require('./src/managers/reminderManager');
const { handleXP }                              = require('./src/managers/levelManager');
const { applyAutoMod }                          = require('./src/managers/automodManager');
const { sendWelcomeMessage, sendLeaveMessage }  = require('./src/managers/welcomeManager');
const { initLoggingManager }                    = require('./src/managers/loggingManager');
const { checkSpam }                             = require('./src/managers/spamManager');

// ─── Handlers ─────────────────────────────────────────────────────────────────
const { handleSecuritySetup }     = require('./src/handlers/securitySetupHandler');
const { handleVerificationSetup } = require('./src/handlers/verificationHandler');
const { handleTickets }           = require('./src/handlers/ticketsHandler');
const { handleFeedback }          = require('./src/handlers/feedbackHandler');
const { handleLoggingSetup }      = require('./src/handlers/loggingSetupHandler');
const { handleAutomodSetup }      = require('./src/handlers/automodSetupHandler');
const { handlePrefix }            = require('./src/handlers/prefixHandler');

// ─── Command modules with custom interaction handlers ─────────────────────────
const levelRewardsCommand   = require('./src/commands/levels/levelrewards');
const autoresponderCommand  = require('./src/commands/utility/autoresponder');
const spamCommand           = require('./src/commands/utility/spam');
const lockCommand           = require('./src/commands/utility/lock');

// ─── Discord client ────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildInvites,
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.Reaction,
    Partials.User,
    Partials.GuildMember,
  ],
});

// ─── Command loading ───────────────────────────────────────────────────────────
client.commands = new Collection();

function loadCommandsFromDir(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      loadCommandsFromDir(fullPath);
    } else if (entry.name.endsWith('.js')) {
      try {
        const command = require(fullPath);
        if (command?.data && command?.execute) {
          client.commands.set(command.data.name, command);
          logger.info(`Loaded command: ${command.data.name}`);
        }
      } catch (err) {
        logger.error(`Failed to load command at ${fullPath}:`, err.message);
      }
    }
  }
}

loadCommandsFromDir(path.join(__dirname, 'src', 'commands'));
logger.info(`Total commands loaded: ${client.commands.size}`);

// ─── Slash command registration ────────────────────────────────────────────────
async function registerSlashCommands() {
  const commands = client.commands.map(cmd => cmd.data.toJSON());
  const rest     = new REST().setToken(process.env.DISCORD_TOKEN);

  if (!process.env.DEV_GUILD_ID) {
    logger.warn('━━━ WARNING ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    logger.warn('  DEV_GUILD_ID is not set in your .env file.');
    logger.warn('  Slash commands will be registered GLOBALLY and may take up to 1 hour to appear.');
    logger.warn('  To fix: add  DEV_GUILD_ID=your_server_id  to your .env file.');
    logger.warn('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  }

  try {
    // Clear any stale guild-scoped commands that may cause duplicates
    if (process.env.DEV_GUILD_ID) {
      await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.DEV_GUILD_ID),
        { body: [] },
      );
    }
    // Register globally (works across all servers)
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands },
    );
    logger.info(`[Commands] Registered ${commands.length} global commands.`);
    logger.info(`[Commands] Registered: ${commands.map(c => c.name).join(', ')}`);
  } catch (err) {
    logger.error('[Commands] Failed to register slash commands:', err.message);
    if (err.status)    logger.error('[Commands] HTTP status:', err.status);
    if (err.rawError)  logger.error('[Commands] Discord API error:', JSON.stringify(err.rawError));
  }
}

// ─── Ready ─────────────────────────────────────────────────────────────────────
client.once(Events.ClientReady, async (c) => {
  logger.info(`Logged in as ${c.user.tag} (${c.user.id})`);
  logger.info(`Serving ${c.guilds.cache.size} guild(s).`);

  await registerSlashCommands();

  try {
    initSecurityManager(c);
    logger.info('Security manager initialized.');
  } catch (err) {
    logger.error('Failed to initialize security manager:', err.message);
  }

  try {
    initLoggingManager(c);
    logger.info('Logging manager initialized.');
  } catch (err) {
    logger.error('Failed to initialize logging manager:', err.message);
  }

  await startGiveawayScheduler(c);
  await startReminderScheduler(c);
  startMaintenanceScheduler();

  // ── Rotating presence ──────────────────────────────────────────────────────
  let presenceIndex = 0;

  function updatePresence() {
    const totalServers = c.guilds.cache.size;
    const totalUsers   = c.guilds.cache.reduce((acc, g) => acc + (g.memberCount ?? 0), 0);

    const statuses = [
      { name: 'KrazodHub | /help or ,help✨', type: 0 /* Playing  */ },
      { name: `Users: ${totalUsers} | Servers: ${totalServers}`, type: 3 /* Watching */ },
      { name: 'Made with ❤️ by Krazod',       type: 0 /* Playing  */ },
    ];

    const status = statuses[presenceIndex % statuses.length];
    c.user.setActivity(status.name, { type: status.type });
    presenceIndex++;
  }

  updatePresence();
  setInterval(updatePresence, 15_000);

  logger.info('Krazod Hub is online and ready!');
});

// ─── Interaction handling ──────────────────────────────────────────────────────
client.on(Events.InteractionCreate, async (interaction) => {
  try {
    const cid = interaction.customId ?? '';

    // ── DM-only: feedback from bot removal notification ─────────────────────
    if (!interaction.guild && interaction.isButton() && cid.startsWith('dm:feedback:')) {
      const guildId = cid.slice('dm:feedback:'.length);

      const modal = new ModalBuilder()
        .setCustomId(`dm:feedback:submit:${guildId}`)
        .setTitle('Share Your Feedback');

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('feedback_text')
            .setLabel('Your Feedback')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('What could we do better? Why did you remove the bot?')
            .setRequired(true)
            .setMaxLength(1000),
        ),
      );

      return interaction.showModal(modal);
    }

    if (!interaction.guild && interaction.isModalSubmit() && cid.startsWith('dm:feedback:submit:')) {
      const guildId      = cid.slice('dm:feedback:submit:'.length);
      const feedbackText = interaction.fields.getTextInputValue('feedback_text');
      const guildName    = client.guilds.cache.get(guildId)?.name ?? null;
      const config       = getConfig('GLOBAL', 'feedback');

      if (!config?.enabled || !config?.channelId) {
        return interaction.reply({
          content: 'Thank you for your feedback! (The feedback channel has not been configured yet.)',
          flags: 1 << 6,
        });
      }

      const feedbackChannel = client.channels.cache.get(config.channelId);
      if (!feedbackChannel?.isTextBased()) {
        return interaction.reply({
          content: 'Thank you for your feedback! (The feedback channel is no longer accessible.)',
          flags: 1 << 6,
        });
      }

      const feedbackEmbed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle('Bot Removal Feedback')
        .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
        .addFields(
          { name: 'User',         value: `<@${interaction.user.id}> (\`${interaction.user.id}\`)`,                   inline: true },
          { name: 'Removed From', value: guildName ? `${guildName} (\`${guildId}\`)` : `Server ID: \`${guildId}\``, inline: true },
          { name: 'Feedback',     value: feedbackText },
        )
        .setFooter({ text: `User ID: ${interaction.user.id}` })
        .setTimestamp();

      await feedbackChannel.send({ embeds: [feedbackEmbed] }).catch(() => {});

      return interaction.reply({
        content: 'Thank you for your feedback! We genuinely appreciate you taking the time to share your thoughts.',
        flags: 1 << 6,
      });
    }

    // ── Security setup ──────────────────────────────────────────────────────
    if (
      (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isModalSubmit() || interaction.isChannelSelectMenu()) &&
      cid.startsWith('setup:security:')
    ) {
      return await handleSecuritySetup(interaction);
    }

    // ── Verification setup & verify action ─────────────────────────────────
    if (
      (interaction.isButton() || interaction.isModalSubmit() || interaction.isChannelSelectMenu() || interaction.isRoleSelectMenu()) &&
      (cid.startsWith('setup:verification:') || cid.startsWith('verify:'))
    ) {
      return await handleVerificationSetup(interaction);
    }

    // ── Ticket system ───────────────────────────────────────────────────────
    if (
      (interaction.isButton() || interaction.isModalSubmit() || interaction.isChannelSelectMenu() || interaction.isRoleSelectMenu()) &&
      (cid.startsWith('setup:tickets:') || cid.startsWith('ticket:'))
    ) {
      return await handleTickets(interaction);
    }

    // ── Feedback system ─────────────────────────────────────────────────────
    if (
      (interaction.isButton() || interaction.isModalSubmit() || interaction.isChannelSelectMenu()) &&
      (cid.startsWith('setup:feedback:') || cid === 'feedback:submit')
    ) {
      return await handleFeedback(interaction);
    }

    // ── Logging setup ───────────────────────────────────────────────────────
    if (
      (interaction.isButton() || interaction.isChannelSelectMenu() || interaction.isStringSelectMenu()) &&
      cid.startsWith('setup:logging:')
    ) {
      return await handleLoggingSetup(interaction);
    }

    // ── AutoMod setup ───────────────────────────────────────────────────────
    if (
      (interaction.isButton() || interaction.isStringSelectMenu()) &&
      (cid.startsWith('automod:toggle:') || cid.startsWith('automod:action:'))
    ) {
      return await handleAutomodSetup(interaction);
    }

    // ── Level Rewards interactions (buttons + modals) ────────────────────────
    if (
      (interaction.isButton() || interaction.isModalSubmit()) &&
      cid.startsWith('levelrewards:')
    ) {
      return await levelRewardsCommand.handleInteraction(interaction);
    }

    // ── Autoresponder interactions (buttons + modals) ────────────────────────
    if (
      (interaction.isButton() || interaction.isModalSubmit()) &&
      cid.startsWith('autoresponder:')
    ) {
      return await autoresponderCommand.handleInteraction(interaction);
    }

    // ── Spam management panel interactions (buttons + modals) ────────────────
    if (
      (interaction.isButton() || interaction.isModalSubmit()) &&
      cid.startsWith('spam:')
    ) {
      return await spamCommand.handleInteraction(interaction);
    }

    // ── Lock / Unlock channel interactions ────────────────────────────────────
    if (
      (interaction.isButton() || interaction.isChannelSelectMenu()) &&
      (cid.startsWith('lock:'))
    ) {
      return await lockCommand.handleInteraction(interaction);
    }

    // ── Welcome channel select ──────────────────────────────────────────────
    if (interaction.isChannelSelectMenu() && cid === 'setup:welcome:select_channel') {
      if (!interaction.member.permissions.has(0x20n)) {
        return interaction.reply({ embeds: [errorEmbed('You need the **Manage Server** permission.')], flags: 1 << 6 });
      }
      const channel = interaction.channels.first();
      if (!channel) return interaction.reply({ embeds: [errorEmbed('No channel selected.')], flags: 1 << 6 });
      const current = getConfig(interaction.guild.id, 'welcome') ?? {};
      setConfig(interaction.guild.id, 'welcome', { ...current, channelId: channel.id, enabled: true });
      return interaction.reply({
        embeds: [successEmbed(`Welcome system enabled. Cards will be sent to <#${channel.id}>.`)],
        flags: 1 << 6,
      });
    }

    // ── Leave channel select ────────────────────────────────────────────────
    if (interaction.isChannelSelectMenu() && cid === 'setup:leave:select_channel') {
      if (!interaction.member.permissions.has(0x20n)) {
        return interaction.reply({ embeds: [errorEmbed('You need the **Manage Server** permission.')], flags: 1 << 6 });
      }
      const channel = interaction.channels.first();
      if (!channel) return interaction.reply({ embeds: [errorEmbed('No channel selected.')], flags: 1 << 6 });
      setConfig(interaction.guild.id, 'leave', { channelId: channel.id, enabled: true });
      return interaction.reply({
        embeds: [successEmbed(`Leave system enabled. Farewell cards will be sent to <#${channel.id}>.`)],
        flags: 1 << 6,
      });
    }

    // ── Levels setup: set level-up channel button ───────────────────────────
    if (interaction.isButton() && cid === 'setup:levels:channel') {
      if (!interaction.member.permissions.has(0x20n)) {
        return interaction.reply({ embeds: [errorEmbed('You need the **Manage Server** permission.')], flags: 1 << 6 });
      }
      const row = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('setup:levels:select_channel')
          .setPlaceholder('Select the level-up announcement channel...')
          .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
      );
      return interaction.reply({
        embeds: [infoEmbed(
          'Select the channel where level-up announcements will be posted.\n\n' +
          'If you skip this, announcements will appear in the same channel the user sent a message in.',
          'Level-Up Channel',
        )],
        components: [row],
        flags: 1 << 6,
      });
    }

    // ── Levels setup: channel selected ─────────────────────────────────────
    if (interaction.isChannelSelectMenu() && cid === 'setup:levels:select_channel') {
      if (!interaction.member.permissions.has(0x20n)) {
        return interaction.reply({ embeds: [errorEmbed('You need the **Manage Server** permission.')], flags: 1 << 6 });
      }
      const channel = interaction.channels.first();
      if (!channel) return interaction.reply({ embeds: [errorEmbed('No channel selected.')], flags: 1 << 6 });
      const current = getConfig(interaction.guild.id, 'levels') ?? {};
      setConfig(interaction.guild.id, 'levels', { ...current, levelUpChannelId: channel.id, enabled: true });
      return interaction.reply({
        embeds: [successEmbed(`Level-up channel set to <#${channel.id}>. The leveling system is now **enabled**.`)],
        flags: 1 << 6,
      });
    }

    // ── Levels setup: save & enable ─────────────────────────────────────────
    if (interaction.isButton() && cid === 'setup:levels:save') {
      if (!interaction.member.permissions.has(0x20n)) {
        return interaction.reply({ embeds: [errorEmbed('You need the **Manage Server** permission.')], flags: 1 << 6 });
      }
      const current = getConfig(interaction.guild.id, 'levels') ?? {};
      setConfig(interaction.guild.id, 'levels', { ...current, enabled: true });
      return interaction.reply({
        embeds: [successEmbed(
          'Leveling system is now **enabled**. Members will earn XP by chatting.\n\n' +
          `Level-up announcements will appear in ${current.levelUpChannelId ? `<#${current.levelUpChannelId}>` : 'the same channel as the message'}.`,
        )],
        flags: 1 << 6,
      });
    }

    // ── Giveaway entry button ────────────────────────────────────────────────
    if (interaction.isButton() && cid === 'giveaway:enter') {
      const db      = getDB();
      const footer  = interaction.message.embeds[0]?.footer?.text ?? '';
      const idMatch = footer.match(/Giveaway ID: (\d+)/);
      if (!idMatch) return interaction.reply({ embeds: [errorEmbed('Could not find giveaway data.')], flags: 1 << 6 });

      const giveawayId = parseInt(idMatch[1], 10);
      const giveaway   = db.prepare('SELECT * FROM giveaways WHERE id = ?').get(giveawayId);
      if (!giveaway) return interaction.reply({ embeds: [errorEmbed('Giveaway not found.')], flags: 1 << 6 });
      if (giveaway.ended) return interaction.reply({ embeds: [errorEmbed('This giveaway has already ended.')], flags: 1 << 6 });

      if (giveaway.required_role) {
        if (!interaction.member.roles.cache.has(giveaway.required_role)) {
          return interaction.reply({
            embeds: [errorEmbed(`You need the <@&${giveaway.required_role}> role to enter this giveaway.`)],
            flags: 1 << 6,
          });
        }
      }

      const entries = JSON.parse(giveaway.entries || '[]');
      const idx     = entries.indexOf(interaction.user.id);

      if (idx !== -1) {
        entries.splice(idx, 1);
        db.prepare('UPDATE giveaways SET entries = ? WHERE id = ?').run(JSON.stringify(entries), giveawayId);
        await interaction.message.edit({ embeds: [buildGiveawayEmbed({ ...giveaway, entries: JSON.stringify(entries) })], components: interaction.message.components });
        return interaction.reply({ embeds: [errorEmbed('You have left the giveaway.')], flags: 1 << 6 });
      }

      entries.push(interaction.user.id);
      db.prepare('UPDATE giveaways SET entries = ? WHERE id = ?').run(JSON.stringify(entries), giveawayId);
      await interaction.message.edit({ embeds: [buildGiveawayEmbed({ ...giveaway, entries: JSON.stringify(entries) })], components: interaction.message.components });
      return interaction.reply({ embeds: [successEmbed('You have entered the giveaway! Good luck! 🎉')], flags: 1 << 6 });
    }

    // ── Nitro prank claim button ─────────────────────────────────────────────
    if (interaction.isButton() && cid === 'nitro:claim') {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xED4245)
            .setTitle('Invalid Gift')
            .setDescription('This gift link has already been redeemed or is no longer valid.\n\n*(This was a prank — no real Nitro was gifted!)*')
            .setTimestamp(),
        ],
        flags: 1 << 6,
      });
    }

    // ── Help category select ─────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && cid === 'setup:help:category') {
      const { CATEGORIES } = require('./src/commands/utility/help');
      const selected  = interaction.values[0];
      const category  = CATEGORIES[selected];
      if (!category) return;

      const embed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle(`${category.label} Commands`)
        .setDescription(category.commands.join('\n'))
        .setFooter({ text: 'Krazod Hub • /help' })
        .setTimestamp();

      return interaction.update({ embeds: [embed], components: interaction.message.components });
    }

    // ── Slash commands ───────────────────────────────────────────────────────
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) {
      return interaction.reply({ embeds: [errorEmbed(`Unknown command: \`/${interaction.commandName}\``)], flags: 1 << 6 });
    }

    await command.execute(interaction, client);
  } catch (err) {
    logger.error(`InteractionCreate error (${interaction.customId ?? interaction.commandName}):`, err);
    const errPayload = { embeds: [errorEmbed(`An unexpected error occurred: \`${err.message}\``)], flags: 1 << 6 };
    try {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errPayload);
      } else {
        await interaction.reply(errPayload);
      }
    } catch {
      // Interaction may have expired
    }
  }
});

// ─── Message events ────────────────────────────────────────────────────────────
client.on(Events.MessageCreate, async (message) => {
  if (!message.guild || message.author.bot) return;

  // ── Prefix commands — handled before anything else ───────────────────────────
  if (message.content.startsWith(',')) {
    try {
      await handlePrefix(message, client);
    } catch (err) {
      logger.error('handlePrefix error:', err.message);
    }
    // Prefix commands do NOT block XP, automod, or autoresponder intentionally —
    // but spam detection still runs so prefix-command spam is caught too.
  }

  // ── Spam protection — runs before XP; skips further processing on spam ────────
  try {
    const wasSpam = await checkSpam(message);
    if (wasSpam) return;
  } catch (err) {
    logger.error('checkSpam error:', err.message);
  }

  // ── XP ──────────────────────────────────────────────────────────────────────
  try {
    await handleXP(message);
  } catch (err) {
    if (isDiskFull(err)) {
      handleDiskFull(err);
    } else {
      logger.error('handleXP error:', err.message);
    }
  }

  // ── Auto-mod ─────────────────────────────────────────────────────────────────
  try {
    const automodConfig = getConfig(message.guild.id, 'automod');
    if (automodConfig?.enabled) {
      await applyAutoMod(message, automodConfig, client);
    }
  } catch (err) {
    logger.error('applyAutoMod error:', err.message);
  }

  // ── Autoresponder — case-insensitive trigger matching ─────────────────────────
  try {
    const responders = getAllAutoresponders(message.guild.id);
    if (responders.length > 0) {
      const content = message.content.toLowerCase();
      for (const r of responders) {
        if (content.includes(r.trigger.toLowerCase())) {
          await message.channel.send(r.response).catch(() => {});
          break; // Only one autoresponder fires per message
        }
      }
    }
  } catch (err) {
    logger.error('Autoresponder error:', err.message);
  }

  // ── AFK return detection ──────────────────────────────────────────────────────
  try {
    const db  = getDB();
    const afk = db.prepare('SELECT * FROM afk WHERE guild_id = ? AND user_id = ?').get(message.guild.id, message.author.id);
    if (afk) {
      db.prepare('DELETE FROM afk WHERE guild_id = ? AND user_id = ?').run(message.guild.id, message.author.id);
      const welcome = await message.reply({ embeds: [successEmbed(`Welcome back, ${message.author}! Your AFK status has been removed.`)] });
      setTimeout(() => welcome.delete().catch(() => {}), 5000);
    }

    // Notify message author if mentioned user is AFK
    if (message.mentions.users.size > 0) {
      for (const [, user] of message.mentions.users) {
        if (user.bot) continue;
        const afkEntry = db.prepare('SELECT * FROM afk WHERE guild_id = ? AND user_id = ?').get(message.guild.id, user.id);
        if (!afkEntry) continue;
        const mins = Math.floor((Date.now() - afkEntry.timestamp) / 60_000);
        await message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(COLORS.muted)
              .setDescription(`**${user.username}** is AFK: **${afkEntry.reason}** (${mins < 1 ? 'just now' : `${mins}m ago`})`)
              .setTimestamp(),
          ],
        }).catch(() => {});
      }
    }
  } catch (err) {
    logger.error('AFK handler error:', err.message);
  }
});

// ─── Member join / leave ───────────────────────────────────────────────────────
client.on(Events.GuildMemberAdd, async (member) => {
  const welcomeConfig = getConfig(member.guild.id, 'welcome');

  try {
    const verifyConfig = getConfig(member.guild.id, 'verification');
    if (verifyConfig?.unverifiedRoleId) {
      const role = member.guild.roles.cache.get(verifyConfig.unverifiedRoleId);
      if (role) await member.roles.add(role).catch(() => {});
    }
  } catch (err) {
    logger.error('GuildMemberAdd (unverified role) error:', err.message);
  }

  if (welcomeConfig?.channelId) {
    try {
      await sendWelcomeMessage(member, welcomeConfig, client);
    } catch (err) {
      logger.error('sendWelcomeMessage error:', err.message);
    }
  }
});

client.on(Events.GuildMemberRemove, async (member) => {
  const leaveConfig   = getConfig(member.guild.id, 'leave');
  const welcomeConfig = getConfig(member.guild.id, 'welcome');
  const config        = leaveConfig?.channelId ? leaveConfig : welcomeConfig;

  if (!config?.channelId) return;

  try {
    await sendLeaveMessage(member, config, client);
  } catch (err) {
    logger.error('sendLeaveMessage error:', err.message);
  }
});

// ─── Guild create (bot added to a new server) ─────────────────────────────────
client.on(Events.GuildCreate, async (guild) => {
  try {
    const supportServerUrl = process.env.SUPPORT_SERVER_URL ?? 'https://discord.gg/RNJWRPZAcW';

    await new Promise(resolve => setTimeout(resolve, 3000));

    let inviter = null;

    try {
      const auditLogs = await guild.fetchAuditLogs({ type: AuditLogEvent.BotAdd, limit: 5 });
      const entry = auditLogs.entries.find(e => e.target?.id === client.user.id);
      if (entry?.executor?.id) {
        inviter = await client.users.fetch(entry.executor.id).catch(() => null);
      }
    } catch {
      // Audit log fetch failed
    }

    if (!inviter && guild.ownerId) {
      inviter = await client.users.fetch(guild.ownerId).catch(() => null);
    }

    if (!inviter) return;

    const dmEmbed = new EmbedBuilder()
      .setColor(COLORS.red ?? 0xED4245)
      .setAuthor({ name: 'Krazod Hub', iconURL: client.user.displayAvatarURL() })
      .setTitle('Thanks for adding Krazod Hub!')
      .setDescription(
        `Hey **${inviter.username}**, thank you for inviting **Krazod Hub** to **${guild.name}**!\n\n` +
        `Krazod Hub is your all-in-one Discord bot — featuring moderation, welcome cards, tickets, ` +
        `giveaways, leveling, security, AutoMod, logging, autoresponder, spam protection, channel locking, and much more.\n\n` +
        `Head to your server and run \`/help\` or \`,help\` to browse all available commands and get started.`,
      )
      .addFields(
        { name: 'Get Started', value: '`/help` or `,help` — Browse all commands\n`/about` or `,about` — Bot info & stats', inline: true },
        { name: 'Need Help?', value: 'Join our support server for assistance, updates, and news.', inline: true },
      )
      .setFooter({ text: `Krazod Hub • Successfully added to ${guild.name}` })
      .setTimestamp();

    const dmRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('Join Support Server')
        .setStyle(ButtonStyle.Link)
        .setURL(supportServerUrl),
    );

    await inviter.send({ embeds: [dmEmbed], components: [dmRow] }).catch(() => {});
  } catch {
    // Never crash the bot on a DM failure
  }
});

// ─── Guild delete (bot removed from a server) ─────────────────────────────────
client.on(Events.GuildDelete, async (guild) => {
  if (guild.available === false) return;

  try {
    const inviteUrl = process.env.BOT_INVITE_URL
      ?? 'https://discord.com/oauth2/authorize?client_id=1517881130232184954';

    let remover = null;
    try {
      const logs  = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberKick, limit: 5 });
      const now   = Date.now();
      const entry = logs.entries.find(e =>
        e.target?.id === client.user.id && now - e.createdTimestamp < 15_000,
      );
      if (entry?.executor) {
        remover = await client.users.fetch(entry.executor.id).catch(() => null);
      }
    } catch {
      // Bot no longer has access
    }

    if (!remover && guild.ownerId) {
      remover = await client.users.fetch(guild.ownerId).catch(() => null);
    }

    if (!remover) return;

    const removalEmbed = new EmbedBuilder()
      .setColor(COLORS.red ?? 0xED4245)
      .setAuthor({ name: 'Krazod Hub', iconURL: client.user.displayAvatarURL() })
      .setTitle('Krazod Hub was removed from your server')
      .setDescription(
        `Krazod Hub has been removed from **${guild.name}**.\n\n` +
        `We're sorry to see the bot go! If there's anything we could improve, ` +
        `please share your feedback using the button below — it helps us make Krazod Hub better for everyone.`,
      )
      .addFields({ name: 'Server', value: guild.name, inline: true })
      .setFooter({ text: `Server ID: ${guild.id} • Krazod Hub` })
      .setTimestamp();

    const removalRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`dm:feedback:${guild.id}`)
        .setLabel('Share Your Feedback')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setLabel('Reinvite Bot')
        .setStyle(ButtonStyle.Link)
        .setURL(inviteUrl),
    );

    await remover.send({ embeds: [removalEmbed], components: [removalRow] }).catch(() => {});
  } catch {
    // Never crash the bot
  }
});

// ─── Reaction roles ────────────────────────────────────────────────────────────
client.on(Events.MessageReactionAdd, async (reaction, user) => {
  if (user.bot) return;
  try {
    if (reaction.partial) await reaction.fetch();
    if (reaction.message.partial) await reaction.message.fetch();

    const { getReactionRole } = require('./src/database/db');
    const emoji  = reaction.emoji.id ?? reaction.emoji.name;
    const rr     = getReactionRole(reaction.message.guild?.id, reaction.message.id, emoji);
    if (!rr) return;

    const guild  = reaction.message.guild;
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    const role = guild.roles.cache.get(rr.role_id);
    if (!role) return;
    await member.roles.add(role).catch(() => {});
  } catch (err) {
    logger.error('MessageReactionAdd error:', err.message);
  }
});

client.on(Events.MessageReactionRemove, async (reaction, user) => {
  if (user.bot) return;
  try {
    if (reaction.partial) await reaction.fetch();
    if (reaction.message.partial) await reaction.message.fetch();

    const { getReactionRole } = require('./src/database/db');
    const emoji  = reaction.emoji.id ?? reaction.emoji.name;
    const rr     = getReactionRole(reaction.message.guild?.id, reaction.message.id, emoji);
    if (!rr) return;

    const guild  = reaction.message.guild;
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    const role = guild.roles.cache.get(rr.role_id);
    if (!role) return;
    await member.roles.remove(role).catch(() => {});
  } catch (err) {
    logger.error('MessageReactionRemove error:', err.message);
  }
});

// ─── Error handling ────────────────────────────────────────────────────────────
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err);
  process.exit(1);
});

// ─── Login ─────────────────────────────────────────────────────────────────────
client.login(process.env.DISCORD_TOKEN).catch((err) => {
  logger.error('Failed to log in to Discord:', err.message);
  process.exit(1);
});
